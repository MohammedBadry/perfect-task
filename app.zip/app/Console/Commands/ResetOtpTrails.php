<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\User;
use App\Traits\GeneralTrait;

class ResetOtpTrails extends Command
{
    use GeneralTrait;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'otptrails:reset';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Reset OTP trails to be 0 every day';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $users = User::where('otp_trails', '>', 2)->where('otp_date', date('Y-m-d'))->get();
        foreach ($users as $user) {
            $user->otp_trails = 0;
            $user->save();
        }
    }

}
