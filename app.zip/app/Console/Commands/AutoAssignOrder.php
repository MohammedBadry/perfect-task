<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\Order;
use App\Models\User;
use App\Models\Setting;
use App\Models\AutoAssignment;
use App\Events\NewDeliveriesOrderNotification;
use App\Services\AutoAssignmentService;
use App\Http\Resources\OrderItems\NotificationOrderItemsResource;
use App\Traits\GeneralTrait;
use Carbon\Carbon;

class AutoAssignOrder extends Command
{
    use GeneralTrait;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'order:autoassign';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Find driver to assign order to';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {

        $settings = Setting::first();

        //get orders with status pending
        $orders = Order::where('status_id', 1)
            ->whereNull('delivery_id')
            ->whereDate('created_at', Carbon::today())
            ->where('created_at', '>', Carbon::now()->subMinutes(5)->toDateTimeString())
            ->limit(20)->get();

        foreach ($orders as $order) {
            event(new NewDeliveriesOrderNotification($order));
        }
    }

}
