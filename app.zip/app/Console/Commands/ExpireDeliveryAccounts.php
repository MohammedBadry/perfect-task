<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\User;
use App\Traits\GeneralTrait;

class ExpireDeliveryAccounts extends Command
{
    use GeneralTrait;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'deliveryacounts:expire';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Delete package from delivery expired accounts';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $users = User::where([
            'type' => 'delivery',
            'approved' => 1,
            'payment_status' => 'paid',
            'expire_date' => date('Y-m-d'),
        ])->limit(10000)->get();

        foreach ($users as $user) {
            $user->payment_status = 'pending';
            $user->package_id = null;
            $user->save();
        }
    }

}
