<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;


class ShortenUrlService
{
    public function __constuct()
    {
        //
    }

    public function shortenUrl($url)
    {
        $apiKey = "2tTb8vK5ONiCNw79M9msrmwRWkKUk7wcij5Ji3KU5KWRLlsHsHhE5Dx80pQvNpLG";
        $domainId = 1;
        
        $curl = curl_init();

        curl_setopt_array($curl, array(
          CURLOPT_URL => 'https://c0t.co/api/v1/links',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => array('url' => $url,'domain_id' => $domainId),
          CURLOPT_HTTPHEADER => array(
            'Accept: application/json',
            'Authorization: Bearer '.$apiKey
          ),
        ));
        
        $response = curl_exec($curl);
        $decoded_response = json_decode($response);
        
        curl_close($curl);

        
        if(isset($decoded_response->data)) {
          return $decoded_response->data->short_url;
        } else {
            return false;
        }
        
      }

}
