<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;


class OTPService
{
    public function __constuct()
    {
        //
    }

    public function sendOTP($user,$message)
    {
        $apiKey = env("MESAGAT_API_KEY");
        
        $mobile = ltrim($user->mobile, "0");

        if(strlen($mobile)<12) {
            $mobile = "966".$mobile;
        }

        $curl = curl_init();
        
        curl_setopt_array($curl, array(
          CURLOPT_URL => 'https://www.msegat.com/gw/sendsms.php',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS =>'{
          "userName":"MAWAD",
          "numbers": "'.$mobile.'",
          "userSender":"MAWAD",
          "apiKey":"'.$apiKey.'",
          "msg": "'.$message.'"
        }',
          CURLOPT_HTTPHEADER => array(
            'Content-Type: text/plain',
            'Cookie: userCurrency=SAR; SERVERID=MBE1; userLang=En'
          ),
        ));
        
        $response = curl_exec($curl);
        
        curl_close($curl);
        logger($response);
    }

    public function sendCustomMessage($mobile,$message)
    {
        $apiKey = env("MESAGAT_API_KEY");
        
        $mobile = ltrim($mobile, "0");
        if(strlen($mobile)<12) {
            $mobile = "966".$mobile;
        }

        $curl = curl_init();
        
        curl_setopt_array($curl, array(
          CURLOPT_URL => 'https://www.msegat.com/gw/sendsms.php',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS =>'{
          "userName":"zelter-2",
          "numbers": "'.$mobile.'",
          "userSender":"Plans",
          "apiKey":"'.$apiKey.'",
          "msg": "'.$message.'"
        }',
          CURLOPT_HTTPHEADER => array(
            'Content-Type: text/plain',
            'Cookie: userCurrency=SAR; SERVERID=MBE1; userLang=En'
          ),
        ));
        
        $response = curl_exec($curl);
        
        curl_close($curl);
        logger($response);
    }

    public function verifyOTP($user,$code)
    {
        $apiKey = env("MESAGAT_API_KEY");
        $mobile = trim($user->mobile, "+");

        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, "https://www.msegat.com/gw/sendOTPCode.php");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_HEADER, TRUE);

        curl_setopt($ch, CURLOPT_POST, TRUE);

        $fields = [
            "lang" => "En",
            "userName" => "Lama alshareef",
            "numbers" => $mobile,
            "code" => $code,
            "id" => "OTP",
            "userSender" => "OTP",
            "apiKey" => $apiKey,
        ];
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);

        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            "Content-Type: application/json"
        ));

        $response = curl_exec($ch);
        $info = curl_getinfo($ch);
        curl_close($ch);

        //var_dump($info["http_code"]);
        logger($response);

        if (isset($response['message'])) {
            return $decodeOutput['message'];
        } else{
            return 0;
        }
    }

}
