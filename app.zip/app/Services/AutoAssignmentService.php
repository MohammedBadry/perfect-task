<?php

namespace App\Services;
use App\Models\User;
use App\Models\MobileNotification;
use Lang;

class AutoAssignmentService
{
    public function __constuct()
    {
        //
    }

    function sendNotification($user, $title, $message, $type, $target_id = null, $image= null)
    {
        if($type=='order_status' || $type=='new_order' || $type=='accept_order') {
            $translated_title = Lang::get($title,[],$user->lang);
            $translated_message = Lang::get($message,[],$user->lang);
        } else {
            $translated_title = trans($title);
            $translated_message = trans($message);
        }

        $notification = array(
            'title' => $translated_title,
            'body' => $translated_message,
        );
        $data = array(
            'title' => $translated_title,
            'body' => $translated_message,
            'type' => $type,
            'target_id'    => $target_id,
            'sound' => 'default',
            'click_action' => 'FLUTTER_NOTIFICATION_CLICK'
            //'image' => $image,
        );
        
        //Save notification in db
        MobileNotification::create([
            'user_id' => $user->id,
            'title' => $title,
            'body' => $message,
            'type' => $type,
            'target_id' => $target_id,
        ]);

        $url = 'https://fcm.googleapis.com/fcm/send';
        $server_key = env('FIREBASE_API_ACCESS_KEY');

        if($user->device_type == "android"){
            $fields = array(
                'to' => $user->fcm_token,
                'notification' => $notification,
                'data' => $data
            );
        } else {
            $fields = array(
                'to' => $user->fcm_token,
                'notification' => $notification,
                'data' => $data,
                'priority' => 'high'
            );
        }
        $headers = array('Authorization: key=' .$server_key, 'Content-Type: application/json', 'priority:10,Accept:*/*, Accept-Encoding:gzip, Connection:keep-alive');

        $url = 'https://fcm.googleapis.com/fcm/send';

        // var_dump($fields);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
        $result = curl_exec($ch);
        curl_close($ch);

        logger($result);

        return json_encode($result, true);

    }

    function sendGeneralNotification($user, $title, $message, $type, $order = null, $image= null)
    {
        $translated_title = Lang::get($title,[],$user->lang);
        $translated_message = Lang::get($message,[],$user->lang);
        $notification = array(
            'title' => $translated_title,
            'body' => $translated_message,
        );
        $data = array(
            'title' => $translated_title,
            'body' => $translated_message,
            'type' => $type,
            'sound' => 'default',
            'click_action' => 'FLUTTER_NOTIFICATION_CLICK'
            //'image' => $image,
        );
        //Save notification in db
        MobileNotification::create([
            'user_id' => $user->id,
            'title' => $title,
            'body' => $message,
            'type' => $type,
        ]);

        $url = 'https://fcm.googleapis.com/fcm/send';
        $server_key = env('FIREBASE_API_ACCESS_KEY');

        if($user->device_type == "android"){
                $fields = array(
                    'to' => $user->fcm_token,
                    'notification' => $notification,
                    'data' => $data
                );
        } else {
                $fields = array(
                    'to' => $user->fcm_token,
                    'priority'=>'high',
                    'notification' => $data
                );
        }
        $headers = array('Authorization: key=' .$server_key, 'Content-Type: application/json', 'priority:10,Accept:*/*, Accept-Encoding:gzip, Connection:keep-alive');

        $url = 'https://fcm.googleapis.com/fcm/send';

        // var_dump($fields);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
        $result = curl_exec($ch);
        curl_close($ch);

        logger($result);

        return json_encode($result, true);

    }

    function sendNotificationToTopic($topic, $title, $message, $type)
    {

        if($topic=='ez_client') {
            foreach(User::where('type', 'user')->get() as $user) {
                //Save notification in db
                MobileNotification::create([
                    'user_id' => $user->id,
                    'title' => $title,
                    'body' => $message,
                    'type' => $type,
                    'target_id' => 1,
                ]);
            }
        } else {
            foreach(User::where(['type' => 'delivery'])->get() as $user) {
                //Save notification in db
                MobileNotification::create([
                    'user_id' => $user->id,
                    'title' => $title,
                    'body' => $message,
                    'type' => $type,
                    'target_id' => 1,
                ]);
            }
        }

        $notification = array(
            'title' => $title,
            'body' => $message,
        );
        $data = array(
            'title' => $title,
            'body' => $message,
            'type' => $type,
            'sound' => 'default',
            'click_action' => 'FLUTTER_NOTIFICATION_CLICK'
            //'image' => $image,
        );

        $url = 'https://fcm.googleapis.com/fcm/send';
        $server_key = env('FIREBASE_API_ACCESS_KEY');

        $fields = array(
            'to' => '/topics/'.$topic,
            'notification' => $notification,
            'data' => $data
        );
        $headers = array('Authorization: key=' .$server_key, 'Content-Type: application/json', 'priority:10,Accept:*/*, Accept-Encoding:gzip, Connection:keep-alive');

        $url = 'https://fcm.googleapis.com/fcm/send';

        // var_dump($fields);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
        $result = curl_exec($ch);
        curl_close($ch);

        logger($result);

        return json_encode($result, true);

    }

}
