<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Carbon\Carbon;
use App\Models\Area;
use App\Http\Controllers\Validations\AreasRequest;

class Areas extends Controller
{

	public function __construct() {

		$this->middleware('AdminRole:areas_show', [
			'only' => ['index', 'show'],
		]);
		$this->middleware('AdminRole:areas_add', [
			'only' => ['create', 'store'],
		]);
		$this->middleware('AdminRole:areas_edit', [
			'only' => ['edit', 'update'],
		]);
		$this->middleware('AdminRole:areas_delete', [
			'only' => ['destroy', 'multi_delete'],
		]);
	}
    /**
     *
     * Display a listing of the resource.
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $areas = Area::paginate();
        return view('admin.areas.index', ['title' => 'المناطق', 'areas' => $areas]);
    }

    /**
     *
     * Show the form for creating a new resource.
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.areas.create', ['title' => trans('admin.create')]);
    }

    /**
     *
     * Store a newly created resource in storage.
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response Or Redirect
     */
    public function store(AreasRequest $request)
    {
        $data = $request->except("_token", "_method");
        $areas = Area::create($data);
        $redirect = isset($request["add_back"]) ? "/create" : "";
        return redirectWithSuccess(aurl('areas/' . $redirect), trans('admin.added'));
    }

    /**
     *
     * edit the form for creating a new resource.
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $areas = Area::findOrFail($id);
        return is_null($areas) || empty($areas) ?
            backWithError(trans("admin.undefinedRecord"), aurl("areas")) :
            view('admin.areas.edit', [
                'title' => trans('admin.edit'),
                'areas' => $areas,
            ]);
    }


    /**
     *
     * update a newly created resource in storage.
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function updateFillableColumns()
    {
        $fillableCols = [];
        foreach (array_keys((new AreasRequest)->attributes()) as $fillableUpdate) {
            if (!is_null(request($fillableUpdate))) {
                $fillableCols[$fillableUpdate] = request($fillableUpdate);
            }
        }
        return $fillableCols;
    }

    public function update(AreasRequest $request, $id)
    {
        $data = $this->updateFillableColumns();
        $area = Area::where('id', $id)->first();
        $area->update($data);
        $redirect = isset($request["save_back"]) ? "/" . $id . "/edit" : "";
        return redirectWithSuccess(aurl("areas/"), trans('admin.updated'));
    }
    /**
     *
     * destroy a newly created resource in storage.
     * @param  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $areas = Area::find($id);
        if (is_null($areas) || empty($areas)) {
            return backWithSuccess(trans('admin.undefinedRecord'), aurl("areas"));
        }
        $areas->delete();
        return redirectWithSuccess(aurl("areas"), trans('admin.deleted'));
    }

}
