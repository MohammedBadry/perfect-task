<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Events\OrderNotification;
use App\Models\Setting;
use App\Models\Order;
use Illuminate\Http\Request;

class Orders extends Controller {

	public function __construct() {

		$this->middleware('AdminRole:orders_show', [
			'only' => ['index', 'show'],
		]);
		$this->middleware('AdminRole:orders_add', [
			'only' => ['create', 'store'],
		]);
		$this->middleware('AdminRole:orders_edit', [
			'only' => ['edit', 'update'],
		]);
		$this->middleware('AdminRole:orders_delete', [
			'only' => ['destroy', 'multi_delete'],
		]);
	}

	public function index() {
	    $payment_status = request()->payment_status;
        if(admin()->user()->is_vendor==1) {
            $orders = Order::query()
            ->where('vendor_id', admin()->user()->id)
            ->when($payment_status, function($quenry) use ($payment_status) {
                $quenry->where('payment_status', $payment_status);
            })
            ->orderBy('id', 'asc')
            ->paginate();
                //mark all order notifications as read
                foreach(Order::where(['vendor_id' => admin()->user()->id, 'read' => 0])->get() as $order) {
                    $order->read = 1;
                    $order->save();
                }
        } else {
            $orders = Order::query()
            ->when($payment_status, function($quenry) use ($payment_status) {
                $quenry->where('payment_status', $payment_status);
            })
            ->orderBy('id', 'asc')
            ->paginate();
                //mark all order notifications as read
                foreach(Order::where(['read' => 0])->get() as $order) {
                    $order->read = 1;
                    $order->save();
                }
        }
        return view('admin.orders.index', ['title'=>trans('admin.orders'), 'orders' => $orders]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $orders =  Order::find($id);
            //mark order notifications as read
            $orders->read = 1;
            $orders->save();
        return is_null($orders) || empty($orders) ?
            backWithError(trans("admin.undefinedRecord"), url(request()->segment(1)."/orders")) :
            view('admin.orders.show', [
                'title' => trans('admin.show'),
                'orders' => $orders
            ]);
    }

    public function changeStatus($id, $status)
    {
        // Check Record Exists
        $orders =  Order::find($id);
        if (is_null($orders) || empty($orders)) {
            return backWithError(trans("admin.undefinedRecord"), url(request()->segment(1)."/orders"));
        }
        Order::where('id', $id)->update(['status' => $status]);
        $redirect = isset($request["save_back"]) ? "/" . $id . "/edit" : "";
        return redirectWithSuccess(url(request()->segment('1') . '/orders' . $redirect), trans('admin.updated'));
    }

    /**
     *
     * destroy a newly created resource in storage.
     * @param  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $orders = Order::find($id);
        if (is_null($orders) || empty($orders)) {
            return backWithSuccess(trans('admin.undefinedRecord'), url(request()->segment(1)."/orders"));
        }

        it()->delete('order', $id);
        $orders->delete();
        return redirectWithSuccess(url(request()->segment(1)."/orders"), trans('admin.deleted'));
    }

	public function markAllAsRead() {
		$orders = Order::where('read', 0)->get();
		foreach($orders as $order) {
            $order->read = 1;
            $order->save();
        }
	}

    public function assignOrderAsPaid($id, Request $request)
    {
        $order = Order::find($id);
        if(is_null($order) || empty($order)){
            return backWithSuccess(trans('admin.undefinedRecord'), url(request()->segment(1)."/orders/".$id));
        }

        if($order->status_id== 3 || $order->status_id== 4 || $order->payment_status== 'totally_paid') {
            return backWithSuccess(trans('auth.notAllowed'), url(request()->segment(1)."/orders/".$id));
        }
        
        if(!$request->payment_status || !in_array($request->payment_status, ['partially_paid', 'totally_paid'])) {
            return backWithSuccess('اختر حالة الدفع بشكل صحيح', url(request()->segment(1)."/orders/".$id));
        }
        
        $order->payed_amount += $order->rest_amount;
        $order->rest_amount = 0;
        $order->payment_status = $request->payment_status;
        $order->save();

        return backWithSuccess(trans('auth.order_paid'), url(request()->segment(1)."/orders/".$id));

    }

    public function locationPreview(Request $request) {

        $latitude = $request->latitude;
        $longitude = $request->longitude;
        return view('admin.orders.location-preview', ['title'=> "معاينة الموقع", 'latitude' => $latitude, 'longitude' => $longitude]);
    }
}
