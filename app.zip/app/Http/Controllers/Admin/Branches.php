<?php
namespace App\Http\Controllers\Admin;
use App\DataTables\AdminsDataTable;
use App\Http\Controllers\Controller;
use App\Http\Controllers\Validations\BranchesRequest;
use App\Services\AutoAssignmentService;
use App\Models\User;
use App\Models\VendorRating;

class Branches extends Controller {

	public function __construct() {

		$this->middleware('AdminRole:branches_show', [
			'only' => ['index', 'show'],
		]);
		$this->middleware('AdminRole:branches_add', [
			'only' => ['create', 'store'],
		]);
		$this->middleware('AdminRole:branches_edit', [
			'only' => ['edit', 'update'],
		]);
		$this->middleware('AdminRole:branches_delete', [
			'only' => ['destroy', 'multi_delete'],
		]);
	}

	/**
	 * Display a listing of the resource.
	 * @return \Illuminate\Http\Response
	 */
	public function index() {
		if(admin()->user()->is_vendor==1) {
			$branches = User::where(['type' => 'branch', 'vendor_id' => admin()->user()->id])->paginate();
		} else {
			$branches = User::where(['type' => 'branch'])->paginate();
		}
		return view('admin.branches.index', ['title' => 'الفروع', 'branches' => $branches]);
	}

	/**
	 * Show the form for creating a new resource.
	 * @return \Illuminate\Http\Response
	 */
	public function create() {
		return view('admin.branches.create', ['title' => trans('admin.create')]);
	}

	/**
	 * Store a newly created resource in storage.
	 * @param  \Illuminate\Http\Request  $request
	 * @return \Illuminate\Http\Response Or Redirect
	 */
	public function store(BranchesRequest $request) {
		$data = $request->except("_token", "_method");
		if (request()->hasFile('photo_profile')) {
			$data['photo_profile'] = it()->upload('photo_profile', 'users');
		} else {
			$data['photo_profile'] = "";
		}

		$data['type'] = 'branch';
		$data['password'] = bcrypt(request('password'));

		User::create($data);
		return redirectWithSuccess(url(request()->segment('1').'/branches'), trans('admin.added'));
	}

	/**
	 * Display the specified resource.
	 * @param  int  $id
	 * @return \Illuminate\Http\Response
	 */
	public function show($id) {
		$branches = User::find($id);
		return is_null($branches) || empty($branches) ?
		backWithError(trans("admin.undefinedRecord")) :
		view('admin.branches.show', [
			'title' => trans('admin.show'),
			'branches' => $branches,
		]);
	}

	/**
	 * edit the form for creating a new resource.
	 * @return \Illuminate\Http\Response
	 */
	public function edit($id) {
		$branches = User::find($id);
		return is_null($branches) || empty($branches) ?
		backWithError(trans("admin.undefinedRecord")) :
		view('admin.branches.edit', [
			'title' => trans('admin.edit'),
			'branches' => $branches,
		]);
	}

	/**
	 * update a newly created resource in storage.
	 * @param  \Illuminate\Http\Request  $request
	 * @return \Illuminate\Http\Response
	 */
	public function updateFillableColumns() {
		$fillableCols = [];
		foreach (array_keys((new BranchesRequest)->attributes()) as $fillableUpdate) {
			if (!is_null(request($fillableUpdate))) {
				$fillableCols[$fillableUpdate] = request($fillableUpdate);
			}
		}
		return $fillableCols;
	}

	public function update(BranchesRequest $request, $id) {
		// Check Record Exists

		if(admin()->user()->is_vendor==1) {
			$users = User::where(['id' => $id, 'vendor_id' => admin()->user()->id])->first();
		} else {
			$users = User::where(['id' => $id])->first();
		}
		if (is_null($users) || empty($users)) {
			return backWithError(trans("admin.undefinedRecord"));
		}
		$data = $this->updateFillableColumns();

		if (!empty(request('password'))) {
			$data['password'] = bcrypt(request('password'));
		}

		$data['status'] = request('status');

		if (request()->hasFile('photo_profile')) {
			it()->delete($users->photo_profile);
			$data['photo_profile'] = it()->upload('photo_profile', 'users');
		}
		User::where('id', $id)->update($data);
		return redirectWithSuccess(url(request()->segment('1').'/branches'), trans('admin.updated'));
	}

	/**
	 * destroy a newly created resource in storage.
	 * @param  $id
	 * @return \Illuminate\Http\Response
	 */
	public function destroy($id) {
		if(admin()->user()->is_vendor==1) {
			$branches = User::where(['id' => $id, 'vendor_id' => admin()->user()->id])->paginate();
		} else {
			$branches = User::find($id);
		}
		if (is_null($branches) || empty($branches)) {
			return backWithError(trans('admin.undefinedRecord'));
		}
		if (!empty($branches->photo_profile)) {
			it()->delete($branches->photo_profile);
		}

		$branches->delete();
		return backWithSuccess(trans('admin.deleted'));

	}

	public function multi_delete() {
		$data = request('selected_data');
		if (is_array($data)) {
			foreach ($data as $id) {
				$users = User::find($id);
				if (is_null($users) || empty($users)) {
					return backWithError(trans('admin.undefinedRecord'));
				}
				if (!empty($users->photo_profile)) {
					it()->delete($users->photo_profile);
				}

				$users->delete();

			}
			return backWithSuccess(trans('admin.deleted'));
		} else {
			$users = User::find($data);
			if (is_null($users) || empty($users)) {
				return backWithError(trans('admin.undefinedRecord'));
			}

			if (!empty($users->photo_profile)) {
				it()->delete($users->photo_profile);
			}

			$users->delete();
			return backWithSuccess(trans('admin.deleted'));
		}
	}

	public function branchRatings($id) {
		$branches = User::find($id);
		$ratings = VendorRating::where('vendor_id', admin()->user()->id)->where('branch_id', $id)->paginate();
		return is_null($branches) || empty($branches) ?
		backWithError(trans("admin.undefinedRecord")) :
		view('admin.branches.ratings', [
			'title' => trans('admin.show'),
			'branches' => $branches,
			'ratings' => $ratings,
		]);
	}

	public function createNotification() {
		return view('admin.branches.notification', ['title' => 'إرسال إشعار']);
	}

	public function sendNotification() {
        if(!request()->has('topic') || request()->topic=='') {
            return backWithError('لم يتم اختيار المرسل إليه');
        }
        if(!request()->has('title') || request()->title=='') {
            return backWithError('لم يتم كتابة عنون الإشعار');
        }
        if(!request()->has('message') || request()->message=='') {
            return backWithError('لم يتم كتابة تفاصيل الإشعار');
        }
        $not = new AutoAssignmentService();
        $not->sendNotificationToTopic(request()->topic, request()->title, request()->message, 'general');
		return redirectWithSuccess(aurl('push-notifications/send'), 'تم الإرسال بتجاح');
    }

}
