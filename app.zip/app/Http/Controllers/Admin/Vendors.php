<?php
namespace App\Http\Controllers\Admin;
use App\DataTables\AdminsDataTable;
use App\Http\Controllers\Controller;
use App\Http\Controllers\Validations\VendorsRequest;
use App\Models\Admin;
use App\Models\Category;
use App\Models\Order;
use App\Models\VendorWithdrawalRequest;

class Vendors extends Controller {

	public function __construct() {

		$this->middleware('AdminRole:vendors_show', [
			'only' => ['index', 'show'],
		]);
		$this->middleware('AdminRole:vendors_add', [
			'only' => ['create', 'store'],
		]);
		$this->middleware('AdminRole:vendors_edit', [
			'only' => ['edit', 'update'],
		]);
		$this->middleware('AdminRole:vendors_delete', [
			'only' => ['destroy', 'multi_delete'],
		]);
	}

	/**
	 * Display a listing of the resource.
	 * @return \Illuminate\Http\Response
	 */
	public function index(AdminsDataTable $admins) {
		$admins = Admin::vendors()->paginate();
                //mark all order notifications as read
                foreach(Admin::where(['is_vendor' => 1, 'read' => 0])->get() as $vendor) {
                    $vendor->read = 1;
                    $vendor->save();
                }
		return view('admin.vendors.index', ['title' => trans('admin.vendors'), 'admins' => $admins]);
	}

	/**
	 * Show the form for creating a new resource.
	 * @return \Illuminate\Http\Response
	 */
	public function create() {
		$categories = Category::main()->get();
		return view('admin.vendors.create', ['title' => trans('admin.create'), 'categories' => $categories]);
	}

	/**
	 * Store a newly created resource in storage.
	 * @param  \Illuminate\Http\Request  $request
	 * @return \Illuminate\Http\Response Or Redirect
	 */
	public function store(VendorsRequest $request) {
		$data = $request->except("_token", "_method");
		if (request()->hasFile('photo_profile')) {
			$data['photo_profile'] = it()->upload('photo_profile', 'admins');
		} else {
			$data['photo_profile'] = "";
		}

		$data['password'] = bcrypt(request('password'));
		$data['group_id'] = 2;

		Admin::create($data);
		return redirectWithSuccess(url(request()->segment('1').'/vendors'), trans('admin.added'));
	}

	/**
	 * Display the specified resource.
	 * @param  int  $id
	 * @return \Illuminate\Http\Response
	 */
	public function show($id) {
		$admins = Admin::vendors()->findOrFail($id);
		
		$orders = Order::where(['vendor_id' => $id, 'status_id' => 3])->paginate(20);
		$transactions = VendorWithdrawalRequest::where(['vendor_id' => $id, 'status' => 'completed'])->paginate(20);

		return is_null($admins) || empty($admins) ?
		backWithError(trans("admin.undefinedRecord")) :
		view('admin.vendors.show', [
			'title' => trans('admin.show'),
			'admins' => $admins,
			'orders' => $orders,
			'transactions' => $transactions,
		]);
	}

	/**
	 * edit the form for creating a new resource.
	 * @return \Illuminate\Http\Response
	 */
	public function edit($id) {
		$admins = Admin::find($id);
		$categories = Category::main()->get();
		return is_null($admins) || empty($admins) ?
		backWithError(trans("admin.undefinedRecord")) :
		view('admin.vendors.edit', [
			'title' => trans('admin.edit'),
			'admins' => $admins,
			'categories' => $categories,
		]);
	}

	/**
	 * update a newly created resource in storage.
	 * @param  \Illuminate\Http\Request  $request
	 * @return \Illuminate\Http\Response
	 */
	public function updateFillableColumns() {
		$fillableCols = [];
		foreach (array_keys((new VendorsRequest)->attributes()) as $fillableUpdate) {
			if (!is_null(request($fillableUpdate))) {
				$fillableCols[$fillableUpdate] = request($fillableUpdate);
			}
		}
		return $fillableCols;
	}

	public function update(VendorsRequest $request, $id) {
		// Check Record Exists
		$admins = Admin::find($id);
		if (is_null($admins) || empty($admins)) {
			return backWithError(trans("admin.undefinedRecord"));
		}
		$data = $this->updateFillableColumns();

		if (!empty(request('password'))) {
			$data['password'] = bcrypt(request('password'));
		}

		$data['status'] = request('status');

		if (request()->hasFile('photo_profile')) {
			it()->delete($admins->photo_profile);
			$data['photo_profile'] = it()->upload('photo_profile', 'admins');
		}
		Admin::where('id', $id)->update($data);
		return redirectWithSuccess(url(request()->segment('1').'/vendors'), trans('admin.updated'));
	}

	/**
	 * destroy a newly created resource in storage.
	 * @param  $id
	 * @return \Illuminate\Http\Response
	 */
	public function destroy($id) {
		$admins = Admin::vendors()->findOrFail($id);
		if (is_null($admins) || empty($admins)) {
			return backWithError(trans('admin.undefinedRecord'));
		}
		if (!empty($admins->photo_profile)) {
			it()->delete($admins->photo_profile);
		}
		/*		
        $banners = \App\Models\Banner::where(['type' => 'vendor', 'target_id' =>$id])->get();
        foreach($banners as $ban) {
            $ban->delete();
        }
        
        $favourites = \App\Models\Favourite::where(['type' => 'vendor', 'target_id' =>$id])->get();
        foreach($favourites as $fav) {
            $fav->delete();
        }
		*/
		$admins->delete();
		return backWithSuccess(trans('admin.deleted'));

	}

    public function withdrawVendorBalance($id)
    {
		$vendor = Admin::vendors()->findOrFail($id);
		if (is_null($vendor) || empty($vendor)) {
			return backWithError(trans('admin.undefinedRecord'));
		}

        if(empty($vendor->account_name) || empty($vendor->bank_name) || empty($vendor->account_number) || empty($vendor->iban)) {
			return backWithError('بيانات الحساب البنكي غير متوفرة');
        }

        VendorWithdrawalRequest::create([
            'vendor_id' => $id,
            'account_name' => $vendor->account_name,
            'bank_name' => $vendor->bank_name,
            'account_number' => $vendor->account_number,
            'iban' => $vendor->iban,
            'amount' => $vendor->wallet_balance,
            'status' => 'completed'
            ]);

        $vendor->wallet_balance = 0;
        $vendor->save();


        return redirectWithSuccess(aurl('withdrawal-requests').'?status='.request('status'), trans('admin.updated'));
    }

}
