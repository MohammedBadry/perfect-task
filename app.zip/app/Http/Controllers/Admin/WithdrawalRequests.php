<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\DataTables\CategoriesDataTable;
use Carbon\Carbon;
use App\Models\WithdrawalRequest;
use App\Models\Setting;

use App\Http\Controllers\Validations\VendorCategoriesRequest;

class withdrawalRequests extends Controller
{

    public function __construct()
    {

        $this->middleware('AdminRole:withdrawalrequests_show', [
            'only' => ['index', 'show'],
        ]);
        $this->middleware('AdminRole:withdrawalrequests_add', [
            'only' => ['create', 'store'],
        ]);
        $this->middleware('AdminRole:withdrawalrequests_edit', [
            'only' => ['edit', 'update'],
        ]);
        $this->middleware('AdminRole:withdrawalrequests_delete', [
            'only' => ['destroy', 'multi_delete'],
        ]);
    }



    /**
     *
     * Display a listing of the resource.
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $status = request('status');
            if($status=='pending') {
                $title = "طلبات السحب قيد المراجعة";
            } elseif($status=='completed') {
                $title = "طلبات السحب المكتملة";
            } elseif($status=='cancelled') {
                $title = "طلبات السحب الملغاة";
            } else {
                $title = "طلبات السحب";
            }
        if (admin()->user()->is_vendor == 1) {
            $withdrawal_requests = WithdrawalRequest::query()
			->whereIn('delivery_id', function($query) { 
			    $query->select('delivery_id')->from('branch_deliveries')->where('vendor_id', admin()->user()->id); 
			})
            ->when($status, function($query) use ($status) {
                $query->where('status', $status);
            })
            ->paginate();
        } else {
            $withdrawal_requests = WithdrawalRequest::query()
            ->when($status, function($query) use ($status) {
                $query->where('status', $status);
            })
            ->paginate();
        }     
        
        //Update notification to be read
        foreach(WithdrawalRequest::get() as $request) {
            $request->read = 1;
            $request->save();
        }
        return view('admin.withdrawal_requests.index', ['title' => $title, 'withdrawal_requests' => $withdrawal_requests]);
    }

    public function acceptRequest(WithdrawalRequest $withdrawalRequest)
    {
        if($withdrawalRequest->status!='pending') {
            return backWithError("لا يمكن تنفيذ هذا الإجراء", aurl("withdrawal-requests"));
        }
        //return $withdrawalRequest->delivery->wallet_balance;

        $delivery = $withdrawalRequest->delivery;
        $delivery->wallet_balance -= $withdrawalRequest->amount;
        $delivery->save();

        $withdrawalRequest->status = 'completed';
        $withdrawalRequest->save();

        $balance_per_vendor = OrderItem::where(['delivery_id' => $withdrawalRequest->delivery_id, 'vendor_id' => $withdrawalRequest->vendor_id, 'status_id' => 'completed', 'paid_status' => 0])->get();
        foreach($balance_per_vendor as $b_p_v) {
            $b_p_v->paid_status = 1;
            $b_p_v->save();
        }

        return redirectWithSuccess(aurl('withdrawal-requests').'?status='.request('status'), trans('admin.updated'));
    }

    public function cancelRequest(WithdrawalRequest $withdrawalRequest)
    {

        if($withdrawalRequest->status!='pending') {
            return backWithError("لا يمكن تنفيذ هذا الإجراء", aurl("withdrawal-requests"));
        }

        $withdrawalRequest->status = 'cancelled';
        $withdrawalRequest->save();

        return redirectWithSuccess(aurl('withdrawal-requests').'?status='.$status, trans('admin.updated'));
    }

}
