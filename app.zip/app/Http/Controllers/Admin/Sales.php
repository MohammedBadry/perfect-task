<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\Sale;
use App\Models\SaleItem;
use App\Models\User;
use App\Http\Controllers\Validations\SalesRequest;
use Illuminate\Http\Request;

class Sales extends Controller {

	public function __construct() {

		$this->middleware('AdminRole:orders_show', [
			'only' => ['index', 'show'],
		]);
		$this->middleware('AdminRole:orders_add', [
			'only' => ['create', 'store'],
		]);
		$this->middleware('AdminRole:orders_edit', [
			'only' => ['edit', 'update'],
		]);
		$this->middleware('AdminRole:orders_delete', [
			'only' => ['destroy', 'multi_delete'],
		]);
	}

	public function index() {
	    $name = request()->name;
        $sales = Sale::with('user', 'items')
        ->when($name, function($query) use ($name) {
            $query->whereIn('user_id', function($q) use ($name) {
                $q->select('id')->from('users')->where('name', 'LIKE', '%'.$name.'%');
            });
        })
        ->orderBy('id', 'asc')
        ->paginate()->withQueryString();

        $all = Sale::get();
        return view('admin.sales.index', ['title'=>"المبيعات", 'sales' => $sales, 'salesCount' => $all->count(), 'subTotal' => $all->sum('sub_total'), 'taxes' => $all->sum('tax_value'), 'total' => $all->sum('total')]);
    }

	public function index0() {
        $all = Sale::get();
        dd($all->sum('sub_total'));
	    $name = request()->name;
        $sales = Sale::with('user', 'items')
        ->when($name, function($query) use ($name) {
            $query->whereIn('user_id', function($q) use ($name) {
                $q->select('id')->from('users')->where('name', 'LIKE', '%'.$name.'%');
            });
        })
        ->orderBy('id', 'asc')
        ->paginate()->withQueryString();

    }

	public function userSales($user_id) {
        $user = User::findOrFail($user_id);
        $sales = Sale::with('user', 'items')
        ->where('user_id', $user->id)
        ->orderBy('id', 'asc')
        ->paginate();
        
        $all = Sale::where('user_id', $user->id)->get();

        return view('admin.sales.user_sales', ['title'=>"المبيعات", 'sales' => $sales, 'salesCount' => $all->count(), 'subTotal' => $all->sum('sub_total'), 'taxes' => $all->sum('tax_value'), 'total' => $all->sum('total'), 'user' => $user]);
    }

    public function create($user_id)
    {
        $user = User::findOrFail($user_id);
        return view('admin.sales.create', ['title' => trans('admin.create'), 'user' =>$user]);
    }

    /**
     * Store a newly created resource in storage.
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response Or Redirect
     */
    public function store(SalesRequest $request)
    {
        $user = User::findOrFail($request->user_id);

        $data = $request->except("_token", "_method");
        
        $sale = Sale::create($data);
        $sub_total = 0;
        $tax_value = 0;
        $total = 0;
        if($request->product_id!=[]) {
            for ($i = 0; $i < count($request->product_id); $i++) {
                $total = $request->price[$i]*$request->quantity[$i];
                SaleItem::create([
                    'sale_id' => $sale->id,
                    'product_id' => $request->product_id[$i],
                    'price' => $request->price[$i],
                    'quantity' => $request->quantity[$i],
                    'total' => $total,
                ]);
            }
        }
        $tax_value = $request->tax_value;
        $total = $sale->sale_total()+$tax_value;
        $sale->sub_total = $sale->sale_total();
        $sale->tax_value = $tax_value;
        $sale->total = $total;
        $sale->save();
        
        $redirect = isset($request["add_back"]) ? "/create/".$user->id : "";
        return redirectWithSuccess(aurl('sales/'.$user->id.'/user' . $redirect), trans('admin.added'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $sale =  Sale::find($id);
        return is_null($sale) || empty($sale) ?
            backWithError(trans("admin.undefinedRecord"), aurl("sales/".$sale->user_id)) :
            view('admin.sales.show', [
                'title' => trans('admin.show'),
                'sale' => $sale
            ]);
    }

    public function import(Request $request)
    {
        if ($file = $request->file('excel_file')) {
           /*$validator=validator()->make($request->all(),[
             'excel_file'=>'required|max:50000|mimes:xlsx,application/csv,application/excel,
              application/vnd.ms-excel, application/vnd.msexcel,
              text/csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
           ]);
          if ($validator->fails()) {
             return back()
                        ->with('error', 'هذا الملف غير مسموح به');
           }*/
            \Maatwebsite\Excel\Facades\Excel::import(new \App\Imports\SalesImport, $request->file('excel_file'));

            return redirectWithSuccess(aurl('sales'), 'جاري الاستيراد يرجى الانتظار قليلا');
        } else {
            return redirect()->back()->with('error', 'خطأ في الملف المرفوع!');
        }
    }

    /**
     *
     * destroy a newly created resource in storage.
     * @param  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $segment = request()->segment(4);
        $sale = Sale::find($id);
        if (is_null($sale) || empty($sale)) {
            if($segment==4) {
                return backWithSuccess(trans('admin.undefinedRecord'), aurl("sales/".$sale->user_id."/user"));
            }
            return backWithSuccess(trans('admin.undefinedRecord'), aurl("sales"));
        }
        $sale->delete();
        if($segment==4) {
            return redirectWithSuccess(aurl("sales/".$sale->user_id."/user"), trans('admin.deleted'));
        }
        return redirectWithSuccess(aurl('sales'), trans('admin.deleted'));
    }
}
