<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\DataTables\CategoriesDataTable;
use Carbon\Carbon;
use App\Models\Category;
use App\Http\Controllers\Validations\CategoriesRequest;
use App\Http\Controllers\Validations\CategoriesSubRequest;

class Categories extends Controller
{

    public function __construct()
    {

        $this->middleware('AdminRole:categories_show', [
            'only' => ['index', 'show'],
        ]);
        $this->middleware('AdminRole:categories_add', [
            'only' => ['create', 'store'],
        ]);
        $this->middleware('AdminRole:categories_edit', [
            'only' => ['edit', 'update'],
        ]);
        $this->middleware('AdminRole:categories_delete', [
            'only' => ['destroy', 'multi_delete'],
        ]);
    }



    /**
     *
     * Display a listing of the resource.
     * @return \Illuminate\Http\Response
     */
    public function index(CategoriesDataTable $categories)
    {
        $categories = Category::main()->paginate();
        return view('admin.categories.index', ['title' => trans('admin.categories'), 'categories' => $categories]);
    }

    /**
     *
     * Display a listing of the resource.
     * @return \Illuminate\Http\Response
     */
    public function index2(CategoriesDataTable $categories)
    {
        $categories = Category::where('parent_id','!=', '')->paginate();
        return view('admin.categories.index_2', ['title' => 'الأقسام الفرعية', 'categories' => $categories]);
    }


    /**
     *
     * Show the form for creating a new resource.
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $categories = Category::main()->get();
        return view('admin.categories.create', ['title' => trans('admin.create'), 'categories' => $categories]);
    }

    /**
     *
     * Store a newly created resource in storage.
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response Or Redirect
     */
    public function store(CategoriesRequest $request)
    {
        $data = $request->except("_token", "_method");
        $categories = Category::create($data);
        if(request()->hasFile('image')){
            $categories->image = it()->upload('image','categories/'.$categories->id);
            $categories->save();
        }
        $redirect = isset($request["add_back"]) ? "/create" : "";
        if($request->parent_id!='') {
            return redirectWithSuccess(url(request()->segment('1') . '/categories/'.$request->parent_id . $redirect), trans('admin.added'));
        } else {
            return redirectWithSuccess(url(request()->segment('1') . '/categories' . $redirect), trans('admin.added'));
        }
    }

    public function subStore(CategoriesSubRequest $request)
    {
        $data = $request->except("_token", "_method");
        $categories = Category::create($data);
        $redirect = isset($request["add_back"]) ? "/create" : "";
        return redirectWithSuccess(url(request()->segment('1') . '/categories/'.$request->parent_id . $redirect), trans('admin.added'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $categories =  Category::find($id);
        if($categories->parent_id=='') {
            $title = 'الأقسام الفرعية لقسم > '. $categories->name_ar;
        } elseif($categories->parent_id!='') {
            if($categories->parent->parent) {
                $title = 'الأقسام الفرعية لقسم > ' .$categories->parent->parent->name_ar. ' > ' .$categories->parent->name_ar. ' > '. $categories->name_ar;
            } else {
                $title = 'الأقسام الفرعية لقسم > ' .$categories->parent->name_ar. ' > '. $categories->name_ar;
            }
        }
        return is_null($categories) || empty($categories) ?
            backWithError(trans("admin.undefinedRecord"), aurl("categories")) :
            view('admin.categories.show', [
                'title' => $title,
                'categories' => $categories
            ]);
    }

    /**
     *
     * edit the form for creating a new resource.
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $categories =  Category::find($id);
        $main_categories = Category::main()->get();
        return is_null($categories) || empty($categories) ?
            backWithError(trans("admin.undefinedRecord"), aurl("categories")) :
            view('admin.categories.edit', [
                'title' => trans('admin.edit'),
                'categories' => $categories,
                'main_categories' => $main_categories
            ]);
    }


    /**
     *
     * update a newly created resource in storage.
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function updateFillableColumns()
    {
        $fillableCols = [];
        foreach (array_keys((new CategoriesRequest)->attributes()) as $fillableUpdate) {
            if (!is_null(request($fillableUpdate))) {
                $fillableCols[$fillableUpdate] = request($fillableUpdate);
            }
        }
        return $fillableCols;
    }

    public function update(CategoriesRequest $request, $id)
    {
        // Check Record Exists
        $categories =  Category::find($id);
        if (is_null($categories) || empty($categories)) {
            return backWithError(trans("admin.undefinedRecord"), aurl("categories"));
        }
        $data = $this->updateFillableColumns();
        if(request()->hasFile('image')){
            it()->delete($categories->image);
            $data['image'] = it()->upload('image','categories');
        }
        Category::where('id', $id)->update($data);
        $redirect = isset($request["save_back"]) ? "/" . $id . "/edit" : "";
        if($categories->parent_id>0) {
            return redirectWithSuccess(url(request()->segment('1') . '/categories/sub/all' . $redirect), trans('admin.updated'));
        } 
        return redirectWithSuccess(url(request()->segment('1') . '/categories' . $redirect), trans('admin.updated'));
    }

    /**
     *
     * destroy a newly created resource in storage.
     * @param  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $categories = Category::find($id);
        if (is_null($categories) || empty($categories)) {
            return backWithSuccess(trans('admin.undefinedRecord'), aurl("categories"));
        }
        $sub = Category::where('parent_id', $id)->get()->count();
        $prods = \App\Models\Product::where('category_id', $id)->get()->count();
        if($sub>0 || $prods>0) {
			return backWithError('عذرا, هذا القسم يحتوي أقسام فرعية أو منتجات لا يمكن حذفه', aurl("categories"));
        }
        if($categories->subcategories) {
            foreach($categories->subcategories as $sub) {
                if($sub->subcategories) {
                    foreach($sub->subcategories as $sub2) {
                        foreach(\App\Models\Product::where('category_id', $sub2->id)->get() as $pro) {
                            $pro->delete();
                        }
                        $sub2->delete();
                    }
                }
                $sub->delete();
            }
        }

        it()->delete('category', $id);
        $categories->delete();
        return redirectWithSuccess(aurl("categories"), trans('admin.deleted'));
    }

}
