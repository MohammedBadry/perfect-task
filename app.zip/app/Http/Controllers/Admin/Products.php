<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\DataTables\ProductsDataTable;
use Carbon\Carbon;
use App\Models\Product;
use App\Models\ProductImage;
use App\Models\ProductFeature;
use App\Models\ProductCarLoad;
use App\Models\Car;
use App\Models\Category;
use App\Models\Setting;
use Illuminate\Http\Request;

use App\Http\Controllers\Validations\ProductsRequest;

class Products extends Controller
{
    public function __construct()
    {

        $this->middleware('AdminRole:products_show', [
            'only' => ['index', 'show'],
        ]);
        $this->middleware('AdminRole:products_add', [
            'only' => ['create', 'store'],
        ]);
        $this->middleware('AdminRole:products_edit', [
            'only' => ['edit', 'update'],
        ]);
        $this->middleware('AdminRole:products_delete', [
            'only' => ['destroy', 'multi_delete'],
        ]);
    }



    /**
     * Display a listing of the resource.
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $name = request()->name;
        $import = Setting::first()->import;
        if (admin()->user()->is_vendor == 0) {
            $products = Product::query()
            ->when($name, function($query) use ($name) {
                $query->where('name_ar', 'LIKE', '%'.$name.'%');
                $query->orWhere('name_en', 'LIKE', '%'.$name.'%');
            })
            ->paginate()->withQueryString();
        } else {
            $products = Product::where('vendor_id', admin()->user()->id)
            ->when($name, function($query) use ($name) {
                $query->where(function($q) use ($name) {
                    $q->where('name_ar', 'LIKE', '%'.$name.'%');
                    $q->orWhere('name_en', 'LIKE', '%'.$name.'%');
                });
            })
            ->paginate()->withQueryString();
        }
        return view('admin.products.index', ['title' => trans('admin.products'), 'products' => $products, 'import' => $import]);
    }


    /**
     * Show the form for creating a new resource.
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $cars = Car::get();
        return view('admin.products.create', ['title' => trans('admin.create'), 'cars' =>$cars]);
    }

    /**
     * Store a newly created resource in storage.
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response Or Redirect
     */
    public function store(ProductsRequest $request)
    {
        $data = $request->except("_token", "_method");
        $data['image'] = "";

        $products = Product::create($data);
        if (request()->hasFile('image')) {
            $products->image = it()->upload('image', 'products/' . $products->id);
            $products->save();
        }
        if ($request->images!=[]) {
            for ($i = 0; $i < count($request->images); $i++) {
                ProductImage::create([
                    'image' => it()->upload($request->images[$i], 'products'),
                    'product_id' => $products->id,
                ]);
            }
        }
        if($request->feature_name_ar!=[]) {
            for ($i = 0; $i < count($request->feature_name_ar); $i++) {
                ProductFeature::create([
                    'name_ar' => $request->feature_name_ar[$i],
                    'name_en' => $request->feature_name_en[$i],
                    'name_urdu' => $request->feature_name_urdu[$i],
                    'product_id' => $products->id,
                ]);
            }
        }
        if($request->from!=[]) {
            for ($i = 0; $i < count($request->from); $i++) {
                ProductCarLoad::create([
                    'car_id' => $request->car_id[$i],
                    'from' => $request->from[$i],
                    'to' => $request->to[$i],
                    'product_id' => $products->id,
                ]);
            }
        }
        $redirect = isset($request["add_back"]) ? "/create" : "";
        return redirectWithSuccess(url(request()->segment('1') . '/products' . $redirect), trans('admin.added'));
    }

    /**
     * Display the specified resource.
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        if (admin()->user()->is_vendor == 0) {
            $products =  Product::find($id);
        } else {
            $products =  Product::where('vendor_id', admin()->user()->id)->find($id);
        }
        return is_null($products) || empty($products) ?
            backWithError(trans("admin.undefinedRecord"), url(request()->segment(1)."/products")) :
            view('admin.products.show', [
                'title' => trans('admin.show'),
                'products' => $products
            ]);
    }


    /**
     * edit the form for creating a new resource.
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if (admin()->user()->is_vendor == 0) {
            $products =  Product::find($id);
        } else {
            $products =  Product::where('vendor_id', admin()->user()->id)->find($id);
        }
        $cars = Car::get();

        return is_null($products) || empty($products) ?
            backWithError(trans("admin.undefinedRecord"), url(request()->segment(1)."/products")) :
            view('admin.products.edit', [
                'title' => trans('admin.edit'),
                'products' => $products,
                'cars' =>$cars
            ]);
    }


    /**
     * update a newly created resource in storage.
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function updateFillableColumns()
    {
        $fillableCols = [];
        foreach (array_keys((new ProductsRequest)->attributes()) as $fillableUpdate) {
            if (!is_null(request($fillableUpdate))) {
                $fillableCols[$fillableUpdate] = request($fillableUpdate);
            }
        }
        return $fillableCols;
    }

    public function update(ProductsRequest $request, $id)
    {
        // Check Record Exists
        if (admin()->user()->is_vendor == 0) {
            $products =  Product::find($id);
        } else {
            $products =  Product::where('vendor_id', admin()->user()->id)->find($id);
        }
        if (is_null($products) || empty($products)) {
            return backWithError(trans("admin.undefinedRecord"), url(request()->segment(1)."/products"));
        }
        $data = $this->updateFillableColumns();
        if (request()->hasFile('image')) {
            it()->delete($products->image);
            $data['image'] = it()->upload('image', 'products');
        }
        Product::where('id', $id)->update($data);

        if ($request->images) {
            for ($i = 0; $i < count($request->images); $i++) {
                ProductImage::create([
                    'image' => it()->upload($request->images[$i], 'products'),
                    'product_id' => $products->id,
                ]);
            }
        }
        if($request->feature_name_ar) {
            //ProductFeature::where('product_id', $id)->delete();
            for ($i = 0; $i < count($request->feature_name_ar); $i++) {
                ProductFeature::create([
                    'name_ar' => $request->feature_name_ar[$i],
                    'name_en' => $request->feature_name_en[$i],
                    'name_urdu' => $request->feature_name_urdu[$i],
                    'product_id' => $id,
                ]);
            }
        }
        if($request->from!=[]) {
            for ($i = 0; $i < count($request->from); $i++) {
                $p_car_load = ProductCarLoad::where([
                    'car_id' => $request->car_id[$i],
                    'product_id' => $products->id,
                ])->first();
                $p_car_load->from = $request->from[$i];
                $p_car_load->to = $request->to[$i];
                $p_car_load->save();
            }
        }
        $redirect = isset($request["save_back"]) ? "/" . $id . "/edit" : "";
        return redirectWithSuccess(url(request()->segment('1') . '/products' . $redirect), trans('admin.updated'));
    }

    /**
     * destroy a newly created resource in storage.
     * @param  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $products = Product::find($id);
        if (is_null($products) || empty($products)) {
            return backWithSuccess(trans('admin.undefinedRecord'), url(request()->segment(1)."/products"));
        }

        foreach($products->features as $feature) {
            $feature->delete();
        }
        
        $favourites = \App\Models\Favourite::where(['type' => 'product', 'target_id' =>$id])->get();
        foreach($favourites as $fav) {
            $fav->delete();
        }
        
        it()->delete('product', $id);
        $products->delete();
        return redirectWithSuccess(url(request()->segment(1)."/products"), trans('admin.deleted'));
    }

    public function deleteFeature($id)
    {
        $feature = ProductFeature::find($id);
        $product = Product::find($feature->product_id);
        if (is_null($feature) || empty($feature)) {
            return errorResponseJson(['error' => 'invalid-record', 'message' => trans('admin.undefinedRecord')]);
        }

        $feature->delete();
        return redirectWithSuccess(url(request()->segment(1)."/products/".$product->id."/edit"), trans('admin.deleted'));
    }

    public function getSub($category_id)
    {
        $category = Category::find($category_id);
        echo '<option value="">اختر القسم</option>';
        foreach ($category->subcategories as $category) {
        ?>
            <option value="<?=$category->id;?>" <?php if(request()->has('selected_id') && $category->id==request()->selected_id) { ?>selected <?php } ?>><?=$category->name_ar;?></option>
        <?php
        }
    }    

    public function import(Request $request)
    {
        if ($file = $request->file('excel_file')) {
           /*$validator=validator()->make($request->all(),[
             'excel_file'=>'required|max:50000|mimes:xlsx,application/csv,application/excel,
              application/vnd.ms-excel, application/vnd.msexcel,
              text/csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
           ]);
          if ($validator->fails()) {
             return back()
                        ->with('error', 'هذا الملف غير مسموح به');
           }*/
            \Maatwebsite\Excel\Facades\Excel::import(new \App\Imports\ProductsImport, $request->file('excel_file'));

            return redirectWithSuccess(aurl('products'), 'جاري الاستيراد يرجى الانتظار قليلا');
        } else {
            return redirect()->back()->with('error', 'خطأ في الملف المرفوع!');
        }
    }
}
