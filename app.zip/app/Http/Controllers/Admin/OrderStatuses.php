<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Carbon\Carbon;
use App\Models\OrderStatus;

use App\Http\Controllers\Validations\OrderStatusesRequest;

class OrderStatuses extends Controller
{

    public function __construct()
    {

        $this->middleware('AdminRole:orderstatuses_show', [
            'only' => ['index', 'show'],
        ]);
        $this->middleware('AdminRole:orderstatuses_add', [
            'only' => ['create', 'store'],
        ]);
        $this->middleware('AdminRole:orderstatuses_edit', [
            'only' => ['edit', 'update'],
        ]);
        $this->middleware('AdminRole:orderstatuses_delete', [
            'only' => ['destroy', 'multi_delete'],
        ]);
    }



    /**
     *
     * Display a listing of the resource.
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $orderstatuses = OrderStatus::paginate();
        return view('admin.order_statuses.index', ['title' => trans('admin.orderstatuses'), 'orderstatuses' => $orderstatuses]);
    }


    /**
     *
     * Show the form for creating a new resource.
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

        return view('admin.order_statuses.create', ['title' => trans('admin.create')]);
    }

    /**
     *
     * Store a newly created resource in storage.
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response Or Redirect
     */
    public function store(OrderStatusesRequest $request)
    {
        $data = $request->except("_token", "_method");
        $orderstatuses = OrderStatus::create($data);
        if(request()->hasFile('image')){
            $orderstatuses->image = it()->upload('image','order-statuses/'.$orderstatuses->id);
            $orderstatuses->save();
        }
            $redirect = isset($request["add_back"]) ? "/create" : "";
        return redirectWithSuccess(url(request()->segment('1') . '/order-statuses' . $redirect), trans('admin.added'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $orderstatuses =  OrderStatus::find($id);
        return is_null($orderstatuses) || empty($orderstatuses) ?
            backWithError(trans("admin.undefinedRecord"), aurl("order-statuses")) :
            view('admin.order_statuses.show', [
                'title' => trans('admin.show'),
                'orderstatuses' => $orderstatuses
            ]);
    }


    /**
     *
     * edit the form for creating a new resource.
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $orderstatuses =  OrderStatus::find($id);
        return is_null($orderstatuses) || empty($orderstatuses) ?
            backWithError(trans("admin.undefinedRecord"), aurl("order-statuses")) :
            view('admin.order_statuses.edit', [
                'title' => trans('admin.edit'),
                'orderstatuses' => $orderstatuses
            ]);
    }


    /**
     *
     * update a newly created resource in storage.
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function updateFillableColumns()
    {
        $fillableCols = [];
        foreach (array_keys((new OrderStatusesRequest)->attributes()) as $fillableUpdate) {
            if (!is_null(request($fillableUpdate))) {
                $fillableCols[$fillableUpdate] = request($fillableUpdate);
            }
        }
        return $fillableCols;
    }

    public function update(OrderStatusesRequest $request, $id)
    {
        // Check Record Exists
        $orderstatuses =  OrderStatus::find($id);
        if (is_null($orderstatuses) || empty($orderstatuses)) {
            return backWithError(trans("admin.undefinedRecord"), aurl("order-statuses"));
        }
        $data = $this->updateFillableColumns();
        OrderStatus::where('id', $id)->update($data);
        $redirect = isset($request["save_back"]) ? "/" . $id . "/edit" : "";
        return redirectWithSuccess(url(request()->segment('1') . '/order-statuses' . $redirect), trans('admin.updated'));
    }

    /**
     *
     * destroy a newly created resource in storage.
     * @param  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $orderstatuses = OrderStatus::find($id);
        if (is_null($orderstatuses) || empty($orderstatuses)) {
            return backWithSuccess(trans('admin.undefinedRecord'), aurl("order-statuses"));
        }

        $orderstatuses->delete();
        return redirectWithSuccess(aurl("order-statuses"), trans('admin.deleted'));
    }


    public function multi_delete()
    {
        $data = request('selected_data');
        if (is_array($data)) {
            foreach ($data as $id) {
                $orderstatuses = OrderStatus::find($id);
                if (is_null($orderstatuses) || empty($orderstatuses)) {
                    return backWithError(trans('admin.undefinedRecord'), aurl("order-statuses"));
                }

                it()->delete('category', $id);
                $orderstatuses->delete();
            }
            return redirectWithSuccess(aurl("order-statuses"), trans('admin.deleted'));
        } else {
            $orderstatuses = OrderStatus::find($data);
            if (is_null($orderstatuses) || empty($orderstatuses)) {
                return backWithError(trans('admin.undefinedRecord'), aurl("order-statuses"));
            }

            it()->delete('category', $data);
            $orderstatuses->delete();
            return redirectWithSuccess(aurl("order-statuses"), trans('admin.deleted'));
        }
    }
}
