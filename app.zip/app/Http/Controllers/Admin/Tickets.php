<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Carbon\Carbon;
use App\Models\Ticket;

class Tickets extends Controller
{

    public function __construct()
    {

        $this->middleware('AdminRole:withdrawalrequests_show', [
            'only' => ['index', 'show'],
        ]);
        $this->middleware('AdminRole:withdrawalrequests_add', [
            'only' => ['create', 'store'],
        ]);
        $this->middleware('AdminRole:withdrawalrequests_edit', [
            'only' => ['edit', 'update'],
        ]);
        $this->middleware('AdminRole:withdrawalrequests_delete', [
            'only' => ['destroy', 'multi_delete'],
        ]);
    }

    /**
     *
     * Display a listing of the resource.
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(request()->has('type') && request('type')!='') {
            if(request('type')=='user') {
                $title = "رسائل العملاء";
            } elseif(request('type')=='delivery') {
                $title = "رسائل الديلفري";
            }
            $tickets = Ticket::where('type', request('type'))->paginate();
        } else {
            $title = "الرسائل";
            $tickets = Ticket::paginate();
        }
        //Update notification to be read
        foreach(Ticket::get() as $request) {
            $request->read = 1;
            $request->save();
        }
        return view('admin.tickets.index', ['title' => $title, 'tickets' => $tickets]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $tickets =  Ticket::with('user')->find($id);
            //mark order notifications as read
            $tickets->read = 1;
            $tickets->save();
        return is_null($tickets) || empty($tickets) ?
            backWithError(trans("admin.undefinedRecord"), url(request()->segment(1)."/tickets")) :
            view('admin.tickets.show', [
                'title' => trans('admin.show'),
                'tickets' => $tickets
            ]);
    }

	/**
	 * destroy a newly created resource in storage.
	 * @param  $id
	 * @return \Illuminate\Http\Response
	 */
	public function destroy($id) {
		$tickets = Ticket::find($id);
		if (is_null($tickets) || empty($tickets)) {
			return backWithError(trans('admin.undefinedRecord'));
		}

        $tickets->delete();
		return backWithSuccess(trans('admin.deleted'));

	}

}
