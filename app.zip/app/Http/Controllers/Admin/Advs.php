<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use Carbon\Carbon;
use App\Models\Adv;

use App\Http\Controllers\Validations\AdvsRequest;

class Advs extends Controller
{

	public function __construct() {

		$this->middleware('AdminRole:advs_show', [
			'only' => ['index', 'show'],
		]);
		$this->middleware('AdminRole:advs_add', [
			'only' => ['create', 'store'],
		]);
		$this->middleware('AdminRole:advs_edit', [
			'only' => ['edit', 'update'],
		]);
		$this->middleware('AdminRole:advs_delete', [
			'only' => ['destroy', 'multi_delete'],
		]);
	}

	

  /**
   * 
   * Display a listing of the resource.
   * @return \Illuminate\Http\Response
   */
  public function index()
  {
      $advs = Adv::paginate();
      return view('admin.advs.index',['title'=>trans('admin.advs'), 'advs' => $advs]);
  }


  /**
   * 
   * Show the form for creating a new resource.
   * @return \Illuminate\Http\Response
   */
  public function create()
  {
    
      return view('admin.advs.create',['title'=>trans('admin.create')]);
  }

  /**
   * 
   * Store a newly created resource in storage.
   * @param  \Illuminate\Http\Request  $request
   * @return \Illuminate\Http\Response Or Redirect
   */
  public function store(AdvsRequest $request)
  {
      $data = $request->except("_token", "_method");
      $data['image'] = "";
      $advs = Adv::create($data); 
      $redirect = isset($request["add_back"])?"/create":"";
      return redirectWithSuccess(url(request()->segment('1').'/advs'.$redirect), trans('admin.added')); 
  }

  /**
   * Display the specified resource.
   * 
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function show($id)
  {
      $advs =  Adv::find($id);
      return is_null($advs) || empty($advs)?
      backWithError(trans("admin.undefinedRecord"),aurl("advs")) :
      view('admin.advs.show',[
        'title'=>trans('admin.show'),
        'advs'=>$advs
      ]);
  }


  /**
  * 
  * edit the form for creating a new resource.
  * @return \Illuminate\Http\Response
  */
  public function edit($id)
  {
      $advs =  Adv::find($id);
      return is_null($advs) || empty($advs)?
      backWithError(trans("admin.undefinedRecord"),aurl("advs")) :
      view('admin.advs.edit',[
        'title'=>trans('admin.edit'),
        'advs'=>$advs
      ]);
  }


  /**
  * 
  * update a newly created resource in storage.
  * @param  \Illuminate\Http\Request  $request
  * @return \Illuminate\Http\Response
  */
  public function updateFillableColumns() {
      $fillableCols = [];
      foreach (array_keys((new AdvsRequest)->attributes()) as $fillableUpdate) {
        if (!is_null(request($fillableUpdate))) {
          $fillableCols[$fillableUpdate] = request($fillableUpdate);
        }
      }
      return $fillableCols;
  }

  public function update(AdvsRequest $request,$id)
  {
      // Check Record Exists
      $advs =  Adv::find($id);
      if(is_null($advs) || empty($advs)){
        return backWithError(trans("admin.undefinedRecord"),aurl("advs"));
      }
      $data = $this->updateFillableColumns(); 
      Adv::where('id',$id)->update($data);
      $redirect = isset($request["save_back"])?"/".$id."/edit":"";
      return redirectWithSuccess(url(request()->segment('1').'/advs'.$redirect), trans('admin.updated'));
  }

  /**
  * 
  * destroy a newly created resource in storage.
  * @param  $id
  * @return \Illuminate\Http\Response
  */
	public function destroy($id){
		$advs = Adv::find($id);
		if(is_null($advs) || empty($advs)){
			return backWithSuccess(trans('admin.undefinedRecord'),aurl("advs"));
		}
    if(!empty($advs->image)){
			it()->delete($advs->image);		
    }

		it()->delete('adv',$id);
		$advs->delete();
		return redirectWithSuccess(aurl("advs"),trans('admin.deleted'));
	}


}