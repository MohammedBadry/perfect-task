<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Events\OrderNotification;
use App\Models\Admin;
use App\Models\Setting;
use App\Models\Product;
use App\Models\Category;
use App\Models\VendorCategory;
use App\Models\Order;
use App\Models\User;

class Dashboard extends Controller {

	public function home() {
        $data['products'] = admin()->user()->is_vendor==0 ? Product::get()->count() : Product::where('vendor_id', admin()->user()->id)->get()->count();
        $data['orders'] = admin()->user()->is_vendor==0 ? Order::get()->count() : Order::where('vendor_id', admin()->user()->id)->get()->count();
        $data['customers'] = User::where(['type' => 'user', 'status' => 1])->get()->count();
        $data['deliveries'] = admin()->user()->is_vendor==0 ? User::where(['type' => 'delivery', 'status' => 1])->get()->count() : User::where(['type' => 'delivery', 'status' => 1])->whereIn('id', function($query) { $query->select('delivery_id')->from('branch_deliveries')->where('vendor_id', admin()->user()->id); })->get()->count();
        $data['categories'] = Category::where('parent_id', '')->get()->count();
        $data['sub_categories'] = Category::where('parent_id', '!=', '')->get()->count();
        $data['vcategories'] = admin()->user()->is_vendor==0 ? VendorCategory::get()->count() : VendorCategory::where('vendor_id', admin()->user()->id)->get()->count();

        $data['new_o_data'] = collect([]); // Could also be an array
        $data['processing_o_data'] = collect([]); // Could also be an array
        $data['completed_o_data'] = collect([]); // Could also be an array
        $data['cancelled_o_data'] = collect([]); // Could also be an array
        for($i=1; $i<=12; $i++) {
            $new = admin()->user()->is_vendor==0 ? Order::where('status_id', 1)->whereMonth('created_at', $i)->count() : Order::where('vendor_id', admin()->user()->id)->where('status_id', 1)->whereMonth('created_at', $i)->get()->count();
            $processing = admin()->user()->is_vendor==0 ? Order::where('status_id', 2)->whereMonth('created_at', $i)->count() : Order::where('vendor_id', admin()->user()->id)->where('status_id', 2)->whereMonth('created_at', $i)->get()->count();
            $completed = admin()->user()->is_vendor==0 ? Order::where('status_id', 3)->whereMonth('created_at', $i)->count() : Order::where('vendor_id', admin()->user()->id)->where('status_id', 3)->whereMonth('created_at', $i)->get()->count();
            $cancelled = admin()->user()->is_vendor==0 ? Order::where('status_id', 4)->whereMonth('created_at', $i)->count() : Order::where('vendor_id', admin()->user()->id)->where('status_id', 4)->whereMonth('created_at', $i)->get()->count();
            $data['new_o_data']->push($new);
            $data['processing_o_data']->push($processing);
            $data['completed_o_data']->push($completed);
            $data['cancelled_o_data']->push($cancelled);
        }
        $data['total_new'] = admin()->user()->is_vendor==0 ? Order::where('status_id', 1)->count() : Order::where('vendor_id', admin()->user()->id)->where('status_id', 1)->get()->count();
        $data['total_processing'] = admin()->user()->is_vendor==0 ? Order::where('status_id', 2)->count() : Order::where('vendor_id', admin()->user()->id)->where('status_id', 2)->get()->count();
        $data['total_completed'] = admin()->user()->is_vendor==0 ? Order::where('status_id', 3)->count() : Order::where('vendor_id', admin()->user()->id)->where('status_id', 3)->get()->count();
        $data['total_cancelled'] = admin()->user()->is_vendor==0 ? Order::where('status_id', 4)->count() : Order::where('vendor_id', admin()->user()->id)->where('status_id', 4)->get()->count();

        return view('admin.home', [
            'title' => trans('admin.dashboard'),
            'data' => $data,
        ]);
	}

	public function prepareKey($key) {
		$setting = setting()->theme_setting;
		if (!empty($setting) && !empty($setting->{$key})) {
			$$key = $setting->{$key};
		} else {
			$$key = '';
		}

		if (request()->has($key)) {
			if (!empty(request($key))) {
				return [$key => request($key)];
			} else {
				return [$key => ''];
			}
		} else {
			return [$key => $$key];
		}
	}

	public function theme_setting() {
		$data_setting = [];
		$data_setting = array_merge($data_setting, $this->prepareKey('brand_color'));
		$data_setting = array_merge($data_setting, $this->prepareKey('sidebar_class'));
		$data_setting = array_merge($data_setting, $this->prepareKey('main_header'));
		$data_setting = array_merge($data_setting, $this->prepareKey('navbar'));
		//return print_r($data_setting);
		return json_encode($data_setting);
	}

	public function theme($id) {
		if (request()->ajax()) {
			$update = Setting::find(setting()->id);
			$update->theme_setting = $this->theme_setting();
			$update->save();
			return setting()->theme_setting;
		} else {
			return 'no ajax request';
		}
	}
}
