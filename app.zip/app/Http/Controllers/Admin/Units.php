<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use Carbon\Carbon;
use App\Models\Unit;

use App\Http\Controllers\Validations\UnitsRequest;

class Units extends Controller
{

	public function __construct() {

		$this->middleware('AdminRole:units_show', [
			'only' => ['index', 'show'],
		]);
		$this->middleware('AdminRole:units_add', [
			'only' => ['create', 'store'],
		]);
		$this->middleware('AdminRole:units_edit', [
			'only' => ['edit', 'update'],
		]);
		$this->middleware('AdminRole:units_delete', [
			'only' => ['destroy', 'multi_delete'],
		]);
	}

	

  /**
   * 
   * Display a listing of the resource.
   * @return \Illuminate\Http\Response
   */
  public function index()
  {
      $units = Unit::paginate();
      return view('admin.units.index',['title'=>trans('admin.units'), 'units' => $units]);
  }


  /**
   * 
   * Show the form for creating a new resource.
   * @return \Illuminate\Http\Response
   */
  public function create()
  {
    
      return view('admin.units.create',['title'=>trans('admin.create')]);
  }

  /**
   * 
   * Store a newly created resource in storage.
   * @param  \Illuminate\Http\Request  $request
   * @return \Illuminate\Http\Response Or Redirect
   */
  public function store(UnitsRequest $request)
  {
      $data = $request->except("_token", "_method");
      $data['image'] = "";
      $units = Unit::create($data); 
      if(request()->hasFile('image')){
        $units->image = it()->upload('image','units/'.$units->id);
        $units->save();
      }
      $redirect = isset($request["add_back"])?"/create":"";
      return redirectWithSuccess(url(request()->segment('1').'/units'.$redirect), trans('admin.added')); 
  }

  /**
   * Display the specified resource.
   * 
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function show($id)
  {
      $units =  Unit::find($id);
      return is_null($units) || empty($units)?
      backWithError(trans("admin.undefinedRecord"),aurl("units")) :
      view('admin.units.show',[
        'title'=>trans('admin.show'),
        'units'=>$units
      ]);
  }


  /**
  * 
  * edit the form for creating a new resource.
  * @return \Illuminate\Http\Response
  */
  public function edit($id)
  {
      $units =  Unit::find($id);
      return is_null($units) || empty($units)?
      backWithError(trans("admin.undefinedRecord"),aurl("units")) :
      view('admin.units.edit',[
        'title'=>trans('admin.edit'),
        'units'=>$units
      ]);
  }


  /**
  * 
  * update a newly created resource in storage.
  * @param  \Illuminate\Http\Request  $request
  * @return \Illuminate\Http\Response
  */
  public function updateFillableColumns() {
      $fillableCols = [];
      foreach (array_keys((new UnitsRequest)->attributes()) as $fillableUpdate) {
        if (!is_null(request($fillableUpdate))) {
          $fillableCols[$fillableUpdate] = request($fillableUpdate);
        }
      }
      return $fillableCols;
  }

  public function update(UnitsRequest $request,$id)
  {
      // Check Record Exists
      $units =  Unit::find($id);
      if(is_null($units) || empty($units)){
        return backWithError(trans("admin.undefinedRecord"),aurl("units"));
      }
      $data = $this->updateFillableColumns(); 
      if(request()->hasFile('image')){
        it()->delete($units->image);
        $data['image'] = it()->upload('image','units');
      } 
      Unit::where('id',$id)->update($data);
      $redirect = isset($request["save_back"])?"/".$id."/edit":"";
      return redirectWithSuccess(url(request()->segment('1').'/units'.$redirect), trans('admin.updated'));
  }

  /**
  * 
  * destroy a newly created resource in storage.
  * @param  $id
  * @return \Illuminate\Http\Response
  */
	public function destroy($id){
		$units = Unit::find($id);
		if(is_null($units) || empty($units)){
			return backWithSuccess(trans('admin.undefinedRecord'),aurl("units"));
		}
               		if(!empty($units->image)){
			it()->delete($units->image);		}

		it()->delete('unit',$id);
		$units->delete();
		return redirectWithSuccess(aurl("units"),trans('admin.deleted'));
	}

}