<?php
namespace App\Http\Controllers\Admin;
use App\DataTables\AdminsDataTable;
use App\Http\Controllers\Controller;
use App\Http\Controllers\Validations\DeliveriesRequest;
use App\Services\AutoAssignmentService;
use App\Models\User;
use App\Models\OrderItem;
use App\Models\WithdrawalRequest;
use App\Models\UserEditRequest;

class Deliveries extends Controller {

	public function __construct() {

		$this->middleware('AdminRole:deliveries_show', [
			'only' => ['index', 'show'],
		]);
		$this->middleware('AdminRole:deliveries_add', [
			'only' => ['create', 'store'],
		]);
		$this->middleware('AdminRole:deliveries_edit', [
			'only' => ['edit', 'update'],
		]);
		$this->middleware('AdminRole:deliveries_delete', [
			'only' => ['destroy', 'multi_delete'],
		]);
	}

	/**
	 * Display a listing of the resource.
	 * @return \Illuminate\Http\Response
	 */
	public function index() {
        if (admin()->user()->is_vendor == 1) {
			$deliveries = User::where('type', 'delivery')
			->whereIn('id', function($query) { $query->select('delivery_id')->from('branch_deliveries')->where('vendor_id', admin()->user()->id); })
			->paginate();
        } else {
			$deliveries = User::where('type', 'delivery')->paginate();
        }
            //mark all order notifications as read
			/*
            foreach(User::where(['type' => 'delivery', 'payment_status' => 'paid', 'read' => 0])->get() as $delivey) {
                $delivey->read = 1;
                $delivey->save();
            }
			*/
		return view('admin.deliveries.index', ['title' => 'السائقين', 'deliveries' => $deliveries]);
	}

	public function editRequests() {
		$edit_requests = UserEditRequest::paginate();
		return view('admin.deliveries.user_edit_requests', ['title' => 'طلبات تعديل الحساب', 'edit_requests' => $edit_requests]);
	}

    /**
	 * Show the form for creating a new resource.
	 * @return \Illuminate\Http\Response
	 */
	public function create() {
		return view('admin.deliveries.create', ['title' => trans('admin.create')]);
	}

	/**
	 * Store a newly created resource in storage.
	 * @param  \Illuminate\Http\Request  $request
	 * @return \Illuminate\Http\Response Or Redirect
	 */
	public function store(DeliveriesRequest $request) {
		$data = $request->except("_token", "_method");
		if (request()->hasFile('photo_profile')) {
			$data['photo_profile'] = it()->upload('photo_profile', 'users');
		} else {
			$data['photo_profile'] = "";
		}

		$data['password'] = bcrypt(request('password'));

		User::create($data);
		return redirectWithSuccess(url(request()->segment('1').'/deliveries'), trans('admin.added'));
	}

	/**
	 * Display the specified resource.
	 * @param  int  $id
	 * @return \Illuminate\Http\Response
	 */
	public function show($id) {
		$deliveries = User::find($id);
            //mark order notifications as read
            $deliveries->read = 1;
            $deliveries->save();
        if(admin()->user()->is_vendor==1) {
    		$orders = OrderItem::where(['delivery_id' => $id, 'status_id' => 5])
    		->whereIn('order_id', function($query) {
    		    $query->select('id')->from('orders')->where('vendor_id', admin()->user()->id);
    		})
    		->paginate(20);
    		
    		$transactions = WithdrawalRequest::where(['delivery_id' => $id, 'status' => 'completed'])
    		->paginate(20);
        } else {
    		$orders = OrderItem::where(['delivery_id' => $id, 'status_id' => 5])->paginate(20);
    		$transactions = WithdrawalRequest::where(['delivery_id' => $id, 'status' => 'completed'])->paginate(20);
        }	

		return is_null($deliveries) || empty($deliveries) ?
		backWithError(trans("admin.undefinedRecord")) :
		view('admin.deliveries.show', [
			'title' => trans('admin.show'),
			'deliveries' => $deliveries,
			'orders' => $orders,
			'transactions' => $transactions,
		]);
	}

	/**
	 * edit the form for creating a new resource.
	 * @return \Illuminate\Http\Response
	 */
	public function edit($id) {
		$deliveries = User::find($id);
		return is_null($deliveries) || empty($deliveries) ?
		backWithError(trans("admin.undefinedRecord")) :
		view('admin.deliveries.edit', [
			'title' => trans('admin.edit'),
			'deliveries' => $deliveries,
		]);
	}

	/**
	 * update a newly created resource in storage.
	 * @param  \Illuminate\Http\Request  $request
	 * @return \Illuminate\Http\Response
	 */
	public function updateFillableColumns() {
		$fillableCols = [];
		foreach (array_keys((new DeliveriesRequest)->attributes()) as $fillableUpdate) {
			if (!is_null(request($fillableUpdate))) {
				$fillableCols[$fillableUpdate] = request($fillableUpdate);
			}
		}
		return $fillableCols;
	}

	public function update(DeliveriesRequest $request, $id) {
		// Check Record Exists

		$deliveries = User::find($id);
		if (is_null($deliveries) || empty($deliveries)) {
			return backWithError(trans("admin.undefinedRecord"));
		}
		$data = $this->updateFillableColumns();

		if (!empty(request('password'))) {
			$data['password'] = bcrypt(request('password'));
		}

		$data['status'] = request('status');

		if (request()->hasFile('photo_profile')) {
			it()->delete($deliveries->photo_profile);
			$data['photo_profile'] = it()->upload('photo_profile', 'users');
		}
		User::where('id', $id)->update($data);
		return redirectWithSuccess(url(request()->segment('1').'/deliveries'), trans('admin.updated'));
	}

	public function approve($id) {

		$deliveries = User::find($id);
		if (is_null($deliveries) || empty($deliveries)) {
			return backWithError(trans("admin.undefinedRecord"));
		}
		$deliveries->approved = 1;
		$deliveries->save();

        $autoAssignmentSerivce = new AutoAssignmentService();
        $autoAssignmentSerivce->sendGeneralNotification($deliveries, 'auth.approve_account_title', 'auth.approve_account_details', 'approve_account', '', '');

		return redirectWithSuccess(url(request()->segment('1').'/deliveries'), 'تمت الموافقة على الحساب بنجاح');
	}

	public function approveEditRequest($id) {

		$request = UserEditRequest::find($id);
		$user = User::find($request->user_id);
		if (is_null($request) || empty($request)) {
			return backWithError(trans("admin.undefinedRecord"));
		}

        if($request->name!='') {
            $user->name = $request->name;
        }
        if($request->mobile!='') {
            if($request->mobile!=$user->mobile) {
                $user->status = 0;
            }
            $user->mobile = $request->mobile;
        }
        if($request->email!='') {
            $user->email = $request->email;
        }
        if($request->photo_profile!='') {
			it()->delete($user->photo_profile);
            $user->photo_profile = $request->photo_profile;
        }
        if($request->car_front_image!='') {
			it()->delete($user->car_front_image);
            $user->car_front_image = $request->car_front_image;
        }
        if($request->car_back_image!='') {
			it()->delete($user->car_back_image);
            $user->car_back_image = $request->car_back_image;
        }
        if($request->licence_image!='') {
			it()->delete($user->licence_image);
            $user->licence_image = $request->licence_image;
        }
		$user->save();

        $request->delete();


        $autoAssignmentSerivce = new AutoAssignmentService();
        $autoAssignmentSerivce->sendGeneralNotification($request->user, 'auth.approve_edit_request_title', 'auth.approve_edit_request_details', 'accept_edit_request', '', '');

		return redirectWithSuccess(url(request()->segment('1').'/deliveries'), 'تمت الموافقة على طلب تعديل الحساب بنجاح');
	}

	/**
	 * destroy a newly created resource in storage.
	 * @param  $id
	 * @return \Illuminate\Http\Response
	 */
	public function destroy($id) {
		$deliveries = User::find($id);
		if (is_null($deliveries) || empty($deliveries)) {
			return backWithError(trans('admin.undefinedRecord'));
		}
		if (!empty($deliveries->photo_profile)) {
			it()->delete($deliveries->photo_profile);
		}
		if (!empty($deliveries->car_front_image)) {
			it()->delete($deliveries->car_front_image);
		}
		if (!empty($deliveries->car_back_image)) {
			it()->delete($deliveries->car_back_image);
		}
		if (!empty($deliveries->licence_image)) {
			it()->delete($deliveries->licence_image);
		}

		$deliveries->delete();
		return backWithSuccess(trans('admin.deleted'));

	}

	public function destroyEditRequest($id) {
		$request = UserEditRequest::find($id);
		if (is_null($request) || empty($request)) {
			return backWithError(trans('admin.undefinedRecord'));
		}
		if (!empty($request->photo_profile)) {
			it()->delete($request->photo_profile);
		}
		if (!empty($request->car_front_image)) {
			it()->delete($request->car_front_image);
		}
		if (!empty($request->car_back_image)) {
			it()->delete($request->car_back_image);
		}
		if (!empty($request->licence_image)) {
			it()->delete($request->licence_image);
		}

		$request->delete();

        $autoAssignmentSerivce = new AutoAssignmentService();
        $autoAssignmentSerivce->sendGeneralNotification($request->user, 'auth.reject_edit_request_title', 'auth.reject_edit_request_details', 'reject_edit_request', '', '');

		return backWithSuccess(trans('admin.deleted'));

	}


}
