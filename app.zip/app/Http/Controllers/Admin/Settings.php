<?php

namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\Setting;
use Illuminate\Http\Request;

class Settings extends Controller {

	public function __construct() {

		$this->middleware('AdminRole:settings_show', [
			'only' => ['index', 'show'],
		]);
		$this->middleware('AdminRole:settings_edit', [
			'only' => ['store'],
		]);

	}

	/**
	 * Display a listing of the resource.
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function index() {
		return view('admin.settings.index', ['title' => trans('admin.settings')]);
	}

	/**
	 * Store a newly created resource in storage.
	 *
	 * @param  \Illuminate\Http\Request  $request
	 * @return \Illuminate\Http\Response
	 */
	public function store(Request $request) {
		$rules = [
			'sitename_ar' => 'sometimes|nullable',
			'sitename_en' => 'sometimes|nullable',
			//'email' => 'sometimes|nullable',
			'logo' => 'sometimes|nullable|' . it()->image(),
			'icon' => 'sometimes|nullable|' . it()->image(),
			'tax' => 'sometimes|nullable',
			'user_app_about_ar' => 'sometimes|nullable',
			'delivery_app_about_ar' => 'sometimes|nullable',
			'branch_app_about_ar' => 'sometimes|nullable',
			'user_app_terms_ar' => 'sometimes|nullable',
			'delivery_app_terms_ar' => 'sometimes|nullable',
			'branch_app_terms_ar' => 'sometimes|nullable',
			'user_app_about_en' => 'sometimes|nullable',
			'delivery_app_about_en' => 'sometimes|nullable',
			'branch_app_about_en' => 'sometimes|nullable',
			'user_app_terms_en' => 'sometimes|nullable',
			'delivery_app_terms_en' => 'sometimes|nullable',
			'branch_app_terms_en' => 'sometimes|nullable',
			'user_app_about_urdu' => 'sometimes|nullable',
			'delivery_app_about_urdu' => 'sometimes|nullable',
			'branch_app_about_urdu' => 'sometimes|nullable',
			'user_app_terms_urdu' => 'sometimes|nullable',
			'delivery_app_terms_urdu' => 'sometimes|nullable',
			'branch_app_terms_urdu' => 'sometimes|nullable',
    		'bank_name' => 'nullable|max:200',
    		'bank_account_name' => 'nullable|max:200',
    		'bank_account_number' => 'nullable|numeric',
    		'iban' => 'nullable|max:200',
		];

		$data = $this->validate(request(), $rules, [], [
			'sitename_ar' => trans('admin.sitename_ar'),
			'sitename_en' => trans('admin.sitename_en'),
			//'email' => trans('admin.email'),
			'logo' => trans('admin.logo'),
			'icon' => trans('admin.icon'),
			'tax' => trans('admin.tax'),
			'user_app_about' => trans('admin.user_app_about'),
			'delivery_app_about' => trans('admin.delivery_app_about'),
			'branch_app_about' => trans('admin.branch_app_about'),
			'user_app_terms' => trans('admin.user_app_terms'),
			'delivery_app_terms' => trans('admin.delivery_app_terms'),
			'branch_app_terms' => trans('admin.branch_app_terms'),
    		'bank_name' => 'اسم البنك',
    		'bank_account_name' => 'اسم الحساب',
    		'bank_account_number' => 'رقم الحساب',
    		'iban' => 'رقم الأيبان',
		]);
		if (request()->hasFile('logo')) {
			$data['logo'] = it()->upload('logo', 'setting');
		}
		if (request()->hasFile('icon')) {
			$data['icon'] = it()->upload('icon', 'setting');
		}
		Setting::orderBy('id', 'desc')->update($data);
		session()->flash('success', trans('admin.updated'));

		if(request()->page!='') {
			return redirect(url(request()->segment('1').'/settings').'/?page='.request()->page);
		}
		return redirect(url(request()->segment('1').'/settings'));

	}

}
