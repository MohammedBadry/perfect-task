<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use Carbon\Carbon;
use App\Models\Car;

use App\Http\Controllers\Validations\CarsRequest;

class Cars extends Controller
{

	public function __construct() {

		$this->middleware('AdminRole:cars_show', [
			'only' => ['index', 'show'],
		]);
		$this->middleware('AdminRole:cars_add', [
			'only' => ['create', 'store'],
		]);
		$this->middleware('AdminRole:cars_edit', [
			'only' => ['edit', 'update'],
		]);
		$this->middleware('AdminRole:cars_delete', [
			'only' => ['destroy', 'multi_delete'],
		]);
	}

	

  /**
   * 
   * Display a listing of the resource.
   * @return \Illuminate\Http\Response
   */
  public function index()
  {
      $cars = Car::paginate();
      return view('admin.cars.index',['title'=>trans('admin.cars'), 'cars' => $cars]);
  }


  /**
   * 
   * Show the form for creating a new resource.
   * @return \Illuminate\Http\Response
   */
  public function create()
  {
    
      return view('admin.cars.create',['title'=>trans('admin.create')]);
  }

  /**
   * 
   * Store a newly created resource in storage.
   * @param  \Illuminate\Http\Request  $request
   * @return \Illuminate\Http\Response Or Redirect
   */
  public function store(carsRequest $request)
  {
      $data = $request->except("_token", "_method");
      $data['image'] = "";
      $cars = Car::create($data); 
      if(request()->hasFile('image')){
        $cars->image = it()->upload('image','cars/'.$cars->id);
        $cars->save();
      }
      $redirect = isset($request["add_back"])?"/create":"";
      return redirectWithSuccess(url(request()->segment('1').'/cars'.$redirect), trans('admin.added')); 
  }

  /**
   * Display the specified resource.
   * 
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function show($id)
  {
      $cars =  Car::find($id);
      return is_null($cars) || empty($cars)?
      backWithError(trans("admin.undefinedRecord"),aurl("cars")) :
      view('admin.cars.show',[
        'title'=>trans('admin.show'),
        'cars'=>$cars
      ]);
  }


  /**
  * 
  * edit the form for creating a new resource.
  * @return \Illuminate\Http\Response
  */
  public function edit($id)
  {
      $cars =  Car::find($id);
      return is_null($cars) || empty($cars)?
      backWithError(trans("admin.undefinedRecord"),aurl("cars")) :
      view('admin.cars.edit',[
        'title'=>trans('admin.edit'),
        'cars'=>$cars
      ]);
  }


  /**
  * 
  * update a newly created resource in storage.
  * @param  \Illuminate\Http\Request  $request
  * @return \Illuminate\Http\Response
  */
  public function updateFillableColumns() {
      $fillableCols = [];
      foreach (array_keys((new carsRequest)->attributes()) as $fillableUpdate) {
        if (!is_null(request($fillableUpdate))) {
          $fillableCols[$fillableUpdate] = request($fillableUpdate);
        }
      }
      return $fillableCols;
  }

  public function update(carsRequest $request,$id)
  {
      // Check Record Exists
      $cars =  Car::find($id);
      if(is_null($cars) || empty($cars)){
        return backWithError(trans("admin.undefinedRecord"),aurl("cars"));
      }
      $data = $this->updateFillableColumns(); 
      if(request()->hasFile('image')){
        it()->delete($cars->image);
        $data['image'] = it()->upload('image','cars');
      } 
      Car::where('id',$id)->update($data);
      $redirect = isset($request["save_back"])?"/".$id."/edit":"";
      return redirectWithSuccess(url(request()->segment('1').'/cars'.$redirect), trans('admin.updated'));
  }

  /**
  * 
  * destroy a newly created resource in storage.
  * @param  $id
  * @return \Illuminate\Http\Response
  */
	public function destroy($id){
		$cars = Car::find($id);
		if(is_null($cars) || empty($cars)){
			return backWithSuccess(trans('admin.undefinedRecord'),aurl("cars"));
		}
               		if(!empty($cars->image)){
			it()->delete($cars->image);		}

		it()->delete('car',$id);
		$cars->delete();
		return redirectWithSuccess(aurl("cars"),trans('admin.deleted'));
	}

}