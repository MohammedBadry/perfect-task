<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Carbon\Carbon;
use App\Models\City;
use App\Http\Controllers\Validations\CitiesRequest;

class Cities extends Controller
{

	public function __construct() {

		$this->middleware('AdminRole:cities_show', [
			'only' => ['index', 'show'],
		]);
		$this->middleware('AdminRole:cities_add', [
			'only' => ['create', 'store'],
		]);
		$this->middleware('AdminRole:cities_edit', [
			'only' => ['edit', 'update'],
		]);
		$this->middleware('AdminRole:cities_delete', [
			'only' => ['destroy', 'multi_delete'],
		]);
	}
    /**
     *
     * Display a listing of the resource.
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $cities = City::paginate();
        return view('admin.cities.index', ['title' => 'المدن', 'cities' => $cities]);
    }

    /**
     *
     * Show the form for creating a new resource.
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.cities.create', ['title' => trans('admin.create')]);
    }

    /**
     *
     * Store a newly created resource in storage.
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response Or Redirect
     */
    public function store(CitiesRequest $request)
    {
        $data = $request->except("_token", "_method");
        $cities = City::create($data);
        $redirect = isset($request["add_back"]) ? "/create" : "";
        return redirectWithSuccess(aurl('cities/' . $redirect), trans('admin.added'));
    }

    /**
     *
     * edit the form for creating a new resource.
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $cities = City::findOrFail($id);
        return is_null($cities) || empty($cities) ?
            backWithError(trans("admin.undefinedRecord"), aurl("cities")) :
            view('admin.cities.edit', [
                'title' => trans('admin.edit'),
                'cities' => $cities,
            ]);
    }


    /**
     *
     * update a newly created resource in storage.
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function updateFillableColumns()
    {
        $fillableCols = [];
        foreach (array_keys((new CitiesRequest)->attributes()) as $fillableUpdate) {
            if (!is_null(request($fillableUpdate))) {
                $fillableCols[$fillableUpdate] = request($fillableUpdate);
            }
        }
        return $fillableCols;
    }

    public function update(CitiesRequest $request, $id)
    {
        $data = $this->updateFillableColumns();
        $city = City::where('id', $id)->first();
        $city->update($data);
        $redirect = isset($request["save_back"]) ? "/" . $id . "/edit" : "";
        return redirectWithSuccess(aurl("cities/"), trans('admin.updated'));
    }
    /**
     *
     * destroy a newly created resource in storage.
     * @param  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $cities = City::find($id);
        if (is_null($cities) || empty($cities)) {
            return backWithSuccess(trans('admin.undefinedRecord'), aurl("cities"));
        }
        $cities->delete();
        return redirectWithSuccess(aurl("cities"), trans('admin.deleted'));
    }

}
