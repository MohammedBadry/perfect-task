<?php
namespace App\Http\Controllers\Api\V1;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\AutoAssignment;
use App\Models\WalletTransaction;
use App\Models\Cart;
use App\Models\User;
use App\Models\OrderCancelReason;
use App\Models\Setting;
use App\Models\OrderStatus;
use App\Models\UserAddress;
use App\Events\OrderNotification;
use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\ValidationsApi\V1\OrdersRequest;
use App\Http\Resources\Orders\Branches\BranchesOrdersResource;
use App\Http\Resources\Orders\Branches\BranchesOrderDetailsResource;
use App\Http\Resources\Orders\Branches\OrderCancelReasonsResource;
use App\Traits\GeneralTrait;
use App\Http\Controllers\Api\V1\OrderPaymentApi;
use App\Services\AutoAssignmentService;
use App\Events\SendInvoiceEvent;
use DB;

class BranchOrdersApi extends Controller
{
    use GeneralTrait;

	protected $selectColumns = [
	];

    /**
     * Display the specified releationshop.
     * @return array to assign with index & show methods
     */
    public function arrWith(){
        return [];
    }

    /**
     * Display a listing of the resource. Api
     * @return \Illuminate\Http\Response
     */

    public function index()
    {
        if(request()->has('status_id')) {
            $order = Order::with($this->arrWith())
            ->where('branch_id', auth()->guard('api')->user()->id)
            ->where('status_id', request('status_id'))
            ->orderBy("id","desc")->paginate();
        } else {
            $order = Order::with($this->arrWith())
            ->where('branch_id', auth()->guard('api')->user()->id)
            ->orderBy("id","desc")->paginate();
        }

        return $this->returnData(BranchesOrdersResource::collection($order), '');
    }

    /**
     * Display the specified resource.
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $order = Order::with($this->arrWith())->find($id);
        if(is_null($order) || empty($order)){
            return $this->returnError('422', trans('auth.undefinedRecord'));
        }
        return $this->returnData(new BranchesOrderDetailsResource($order), '');
    }

    /**
     * update a newly created resource in storage.
     * @return \Illuminate\Http\Response
     */
    public function updateFillableColumns() {
                $fillableCols = [];
                foreach (array_keys((new OrdersRequest)->attributes()) as $fillableUpdate) {
                if (!is_null(request($fillableUpdate))) {
                    $fillableCols[$fillableUpdate] = request($fillableUpdate);
                }
                }
                return $fillableCols;
        }

    public function update(OrdersRequest $request,$id)
    {
        $order = Order::find($id);
        if(is_null($order) || empty($order)){
            return $this->returnError('422', trans('auth.undefinedRecord'));
        }

        $data = $this->updateFillableColumns();

        Order::where("id",$id)->update($data);

        $order = Order::with($this->arrWith())->find($id);
        return $this->returnData(new BranchesOrdersResource($order), trans("auth.updated"));
    }

    public function acceptOrder(Request $request,$id)
    {
        $order = Order::with($this->arrWith())->find($id);
        if(is_null($order) || empty($order)){
            return $this->returnError('422', trans('auth.undefinedRecord'));
        }
        if($order->branch_id!=auth()->guard('api')->user()->id){
            return $this->returnError('422', trans('auth.notAllowed'));
        }
        if($order->status_id!=1){
            return $this->returnError('422', trans('auth.notAllowed'));
        }

        $order->status_id = 2;
        $order->save();

        $autoAssignmentSerivce = new AutoAssignmentService();
        $autoAssignmentSerivce->sendNotification($order->user, 'auth.order_status_'.$request->status_id.'_title', 'auth.order_status_'.$request->status_id.'_details', 'order_status', $order->id, '');
        $autoAssignmentSerivce->sendNotification($order->user, 
        'auth.order_accepted_title_part1'.$order->id.'auth.order_accepted_title_from_vendor_part2'.$order->vendor->name, 
        'auth.order_accepted_title_part1'.$order->id.'auth.order_accepted_title_from_vendor_part2'.$order->vendor->name, 
        'vendor_order_acceptance', 
        $order->id, '');

        return $this->returnData(new BranchesOrdersResource($order), trans("auth.updated"));
    }

    public function rejectReasons(Request $request)
    {
        $resons = OrderCancelReason::get();
        
        return $this->returnData(OrderCancelReasonsResource::collection($resons), '');
    }

    public function rejectOrder(Request $request,$id)
    {
        $order = Order::with($this->arrWith())->find($id);
        if(is_null($order) || empty($order)){
            return $this->returnError('422', trans('auth.undefinedRecord'));
        }
        if($order->branch_id!=auth()->guard('api')->user()->id){
            return $this->returnError('422', trans('auth.notAllowed'));
        }
        if($order->status_id!=1){
            return $this->returnError('422', trans('auth.notAllowed'));
        }
        $rules['reason_id'] = 'required|int';
        if($request->reason_id==0) {
            $rules['comments'] = 'required|max:1000';
        } else {
            $rules['reason_id'] = 'exists:order_cancel_reasons,id';
            $rules['comments'] = 'nullable|max:1000';
        }

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }

        $resons = OrderCancelReason::find($request->reason_id);

        $order->status_id = 4;
        $order->cancel_reason = $resons->text_ar;
        $order->comments = $request->comments;
        $order->save();

        //return order paid amount to user wallet
        $user = $order->user;
        $user->wallet_balance += $order->payed_amount;
        $user->save();

        $autoAssignmentSerivce = new AutoAssignmentService();
        $autoAssignmentSerivce->sendNotification($order->user, 'auth.order_status_'.$request->status_id.'_title', 'auth.order_status_'.$request->status_id.'_details', 'order_status', $order->id, '');

        return $this->returnData(new BranchesOrdersResource($order), trans("auth.updated"));
    }

    public function updateOrderStatus(Request $request,$id)
    {
        $order = Order::with($this->arrWith())->find($id);
        if(is_null($order) || empty($order)){
            return $this->returnError('422', trans('auth.undefinedRecord'));
        }
        $rules['status_id'] = 'required|exists:order_statuses,id';

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }

        if($order->branch_id!=auth()->guard('api')->user()->id){
            return $this->returnError('422', trans('auth.notAllowed'));
        }
        if(in_array($order->status_id, [3,4])){
            return $this->returnError('422', trans('auth.notAllowed'));
        }

        $order->status_id = $request->status_id;
        $order->save();

        $autoAssignmentSerivce = new AutoAssignmentService();
        $autoAssignmentSerivce->sendNotification($order->user, 'auth.order_status_'.$request->status_id.'_title', 'auth.order_status_'.$request->status_id.'_details', 'order_status', $order->id, '');
        $autoAssignmentSerivce->sendNotification($order->delivery, 'auth.order_status_'.$request->status_id.'_title', 'auth.order_status_'.$request->status_id.'_details', 'order_status', $order->id, '');

        if($request->status_id==3) {
            $order->delivery->wallet_balance += $order->delivery_cost;
            $order->delivery->save();

            //Send notification to delivery that his wallet balance added
            $autoAssignmentSerivce->sendNotification($order->delivery, 'auth.balance_added_title', 'auth.balance_added_details', 'wallet_balance', $order->id, '' );

            //send invoice link sms to the custome
            event(New SendInvoiceEvent($order));
        }
        return $this->returnData(new BranchesOrdersResource($order), trans("auth.updated"));
    }

	public function sendOrderItemRequest(Request $request) {
        $rules = [
			'order_item_id' => 'required|exists:order_items,id',
			'delivery_id' => 'required|exists:users,id',
        ];

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }

		$orderItem = OrderItem::whereId($request->order_item_id)->first();
		$order = Order::whereId($orderItem->order_id)->first();
		if ($order->status_id!=2) {
			return $this->returnError('422', trans('auth.notAllowed'));
		}

		$delivery = User::where(['id' => $request->delivery_id, 'type' => 'delivery'])->first();
		if (!$delivery) {
			return $this->returnError('422', trans('auth.invalidData'));
		}

		$check = AutoAssignment::where(['delivery_id' => $request->delivery_id, 'order_item_id'=> $request->order_item_id])->first();
        if ($check) {
            return $this->returnError('422', trans('auth.order_sent_before'));
        }
		$assigend = AutoAssignment::create([
			'order_item_id' => $request->order_item_id,
			'delivery_id' => $request->delivery_id
		]);

        //send notification to delivery of this order item
        $autoAssignmentSerivce = new AutoAssignmentService();
        $autoAssignmentSerivce->sendNotification($assigend->delivery, 
        'auth.new_order_title_part1'.$orderItem->id.'auth.new_order_title_part2'.$delivery->name, 
        'auth.new_order_title_part1'.$orderItem->id.'auth.new_order_title_part2'.$delivery->name, 
        'delivery_order_acceptance', 
        $orderItem->order->id, '');

        return $this->returnData('', trans('auth.order_sent'));
    }

    public function assignOrderAsPaid($id)
    {
        $order = Order::with($this->arrWith())->where('branch_id', auth()->guard('api')->user()->id)->find($id);
        if(is_null($order) || empty($order)){
            return $this->returnError('422', trans('auth.undefinedRecord'));
        }

        $user = User::find(auth()->guard('api')->user()->id);

        if($order->status_id== 3 ||$order->status_id== 4 || $order->payment_status== 'totally_paid') {
            return $this->returnError('422', trans('auth.notAllowed'));
        }

        $order->payed_amount += $order->rest_amount;
        $order->rest_amount = 0;
        $order->payment_status = 'totally_paid';
        $order->save();

        return $this->returnData('', trans('auth.order_paid'));

    }


}
