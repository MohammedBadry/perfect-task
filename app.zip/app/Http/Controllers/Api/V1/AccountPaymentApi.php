<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Carbon\Carbon;
use Validator;
use App\Models\Order;
use App\Models\User;
use App\Models\Setting;
use App\Models\WalletTransaction;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;
use App\Services\AutoAssignmentService;
use App\Http\Resources\Orders\OrdersResource;
use App\Traits\GeneralTrait;

class AccountPaymentApi extends Controller
{
    use GeneralTrait;

    public function __construct()
    {
        $this->setting = Setting::first();
    }

    public function executePayment($amount, $payment_method, $user)
    {
        $token = $this->getToken();
        $basURL = $this->getUrl();

        $edited_amount = round($amount/4.03); //change from eur to sar
        $url = "https://eu-test.oppwa.com/v1/payments";

        if($payment_method=='visa') {
            $data = "entityId=8a8294174b7ecb28014b9699220015ca" .
                "&amount=".$edited_amount.
                "&currency=EUR" .
                "&paymentBrand=VISA" .
                "&paymentType=DB" .
                "&card.number=".request()->card_number.
                "&card.holder=".request()->card_holder_name.
                "&card.expiryMonth=".request()->expiry_month.
                "&card.expiryYear=".request()->expiry_year.
                "&card.cvv=".request()->cvv;
        } elseif($payment_method=='master') {
            $data = "entityId=8a8294174b7ecb28014b9699220015ca" .
                "&amount=".$edited_amount.
                "&currency=EUR" .
                "&paymentBrand=MASTER" .
                "&paymentType=PA" .
                "&card.number=".request()->card_number.
                "&card.holder=".request()->card_holder_name.
                "&card.expiryMonth=".request()->expiry_month.
                "&card.expiryYear=".request()->expiry_year.
                "&card.cvv=".request()->cvv;
        } elseif($payment_method=='mada') {
            $data = "entityId=8a8294174b7ecb28014b9699220015ca" .
                "&amount=".$edited_amount.
                "&currency=EUR" .
                "&testMode=EXTERNAL" .
                "&paymentType=DB" .
                "&paymentBrand=MADA" .
                "&card.cvv=".request()->cvv.
                "&card.holder=".request()->card_holder_name.
                "&card.number=".request()->card_number.
                "&card.expiryYear=".request()->expiry_year.
                "&card.expiryMonth=".request()->expiry_month;
        }
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                    'Authorization:Bearer '.$token));
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);// this should be set to true in production
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $responseData = curl_exec($ch);
        $deced_response = json_decode($responseData, true);
        if(curl_errno($ch)) {
            return curl_error($ch);
        }
        curl_close($ch);

        if ($deced_response['result']['code']==='000.100.000' || $deced_response['result']['code']==='000.100.110') {
            //Save wallet transaction
            WalletTransaction::create([
                'user_id' => $user->id,
                'type' => 'charge',
                'amount' => $amount,
                'payment_method' => $payment_method,
                'payment_id' => $deced_response['id'],
                'last_wallet_balance' => $user->wallet_balance,
                'status' => 1
            ]);

            $user->payment_id = $deced_response['id'];
            $user->wallet_balance += $amount;
			$user->save();

            $not = new AutoAssignmentService();
            $not->sendNotification($user, trans('auth.successful_wallet_charge'), trans('auth.successful_wallet_charge'), 'wallet', $user->id, '');
            return $this->returnData('', trans('auth.balance_added'));
        } else {
            $order->delete();
            return $this->returnError('422', trans('auth.failed_order_payment'));
        }
    }

    /**
     * @return string
     */
    private function getUrl()
    {
        if($this->setting->payment_mode=='live') {
            return $this->setting->live_url;
        } else {
            return $this->setting->test_url;
        }
    }

    private function getToken()
    {
        if($this->setting->payment_mode=='live') {
            //return $this->setting->live_token;
        } else {
            //return $this->setting->test_token;
            return 'OGE4Mjk0MTc0YjdlY2IyODAxNGI5Njk5MjIwMDE1Y2N8c3k2S0pzVDg=';
        }
    }

}
