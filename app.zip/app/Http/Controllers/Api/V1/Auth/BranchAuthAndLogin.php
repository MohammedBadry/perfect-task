<?php
namespace App\Http\Controllers\Api\V1\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\BranchDelivery;
use App\Events\SendOtpEvent;
use Illuminate\Http\Request;
use Tymon\JWTAuth\Exceptions\JWTException;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rules\Password;
use App\Services\OTPService;
use Hash;
use App\Http\Controllers\Api\V1\AccountPaymentApi;
use App\Services\AutoAssignmentService;
use App\Http\Resources\Deliveries\BranchesDeliveriesResource;
use App\Http\Resources\Deliveries\BranchesDeliveryDetailsResource;
use App\Traits\GeneralTrait;

// Auto Configured by (IT) Baboon maker (phpanonymous/it package)

class BranchAuthAndLogin extends Controller {

    use GeneralTrait;

	/**
	 * Create a new AuthController instance.
	 *
	 * @return void
	 */
	public function __construct() {
		$this->middleware('jwt.verify', ['except' => ['login', 'forgetPassword', 'restetPassword']]);
	}

	/**
	 * Get a JWT via given credentials.
	 * Login Auth
	 * @return \Illuminate\Http\JsonResponse
	 */
	public function login(Request $request) {

        $rules = [
			'mobile' => 'required',
			'password' => 'required',
        ];

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }

        $credentials = ['mobile'=>request('mobile'),'password'=>request('password')];
		try {
			if (!$token = $this->auth()->attempt($credentials)) {
                return $this->returnError('422', trans('auth.failed'));
			}
            $user = \App\Models\User::where(['mobile' => request('mobile')])->first();
            if($user->type!='branch') {
                return $this->returnError('422', trans('auth.failed'));
            }
            if($user->deleted==1) {
                return $this->returnError('422', trans('auth.failed'));
            }
            if($user->status!=1) {
                return $this->returnError('433', trans('auth.activate_mobile_first'));
            }
            if($request->fcm_token) {
                $user->fcm_token = $request->fcm_token;
                $user->device_type = $request->device_type;
                $user->save();
            }
		} catch (JWTException $e) {
			//return errorResponseJson(['error' => 'Unauthorized', 'message' => 'Could not create token']);
            return $this->returnError('422', trans('auth.token_failed'));
		}

		//return successResponseJson(['data' => $this->respondWithToken($token)]);
        return $this->returnData($this->respondWithToken($token), '');
	}

	/**
	 * change Password Method
	 *
	 * @return \Illuminate\Http\JsonResponse
	 */

    public function forgetPassword(Request $request) {
        $rules = [
			'mobile' => 'required|exists:users,mobile',
        ];

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }

        $user = User::where('mobile', $request->mobile)->first();
        /*
		if ($user->otp_trails>3) {
            return $this->returnError('422', trans('auth.exceddedLmit'));
		}
		*/

        $user->otp_trails += 1;
        if($user->otp_trails==3) {
            $user->otp_date = date('Y-m-d', strtotime(' + 1 day'));
        }
        $user->save();

        event(New SendOtpEvent($user));

        return $this->returnData('', trans('auth.otpSent'));
    }

    public function restetPassword(Request $request) {
        $rules = [
			'mobile' => 'required|exists:users,mobile',
			'otp_code' => 'required',
			'new_password' => [
				'required',
				'different:otp_code',
			],
			'password_confirmation' => [
				'required',
				'same:new_password',
				'string', Password::min(6)
			],
        ];

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }
        $user = User::where('mobile', $request->mobile)->first();

        if($user->otp_code!=$request->otp_code) {
            return $this->returnError('422', trans('auth.invaliOtp'));
        }

		$user->update([
			'password' => bcrypt(request('new_password')),
            'otp_code' => null,
		]);
        return $this->returnData('', trans('auth.password_changed'));
	}

	private function auth() {
		return auth()->guard('api');
	}
	/**
	 * Get the token array structure.
	 *
	 * @param  string $token
	 *
	 * @return \Illuminate\Http\JsonResponse
	 */
	protected function respondWithToken($token) {

		$user = $this->auth()->user();
        $data = [
            'id' => $user->id,
            'name' => $user->name,
            'email' => $user->email,
            'mobile' => $user->mobile,
            'photo_profile' => it()->url($user->photo_profile),
            'default_address' => $user->default_address,
            'device_type' => $user->device_type,
            'fcm_token' => $user->fcm_token,
            'access_token' => $token,
			'lang' => $user->lang
        ];

		return [
			'user' => $data,
		];
		/*
		return [
			'access_token' => $token,
			'token_type' => 'Bearer',
			'expires_in' => $this->auth()->factory()->getTTL() * 60,
			'user' => $this->auth()->user(),
		];
		*/
	}

	/**
	 * Get the authenticated User.
	 *
	 * @return \Illuminate\Http\JsonResponse
	 */
	public function me() {

        return $this->returnData($this->auth()->user(), '');
	}

	/**
	 * Log the user out (Invalidate the token).
	 *
	 * @return \Illuminate\Http\JsonResponse
	 */
	public function logout() {
		$this->auth()->logout();

        return $this->returnData('', '');
	}

	/**
	 * Refresh a token.
	 *
	 * @return \Illuminate\Http\JsonResponse
	 */
	public function refresh() {

        return $this->returnData($this->respondWithToken($this->auth()->refresh()), '');
	}

	public function account() {

        return $this->returnData(new \App\Http\Resources\Users\BranchResource($this->auth()->user()), '');
	}

	public function notifications() {

		$notifications = \App\Models\MobileNotification::where('user_id', $this->auth()->user()->id)->orderBy('id', 'desc')->get();
		foreach(\App\Models\MobileNotification::where('user_id', $this->auth()->user()->id)->get() as $not) {
		    $not->read=1;
		    $not->save();
		}
        return $this->returnData(\App\Http\Resources\Notifications\NotificationsResource::collection($notifications), '');
	}

    public function updateProfile(Request $request) {
        $rules = [
            'name'     => 'required|max:100|regex:/^[\pL\s\-]+$/u',
			'email' => 'sometimes|email|unique:users,email,' . $this->auth()->user()->id,
			'mobile' => 'sometimes|regex:/[0-9]{8}/|unique:users,mobile,' . $this->auth()->user()->id,
			'photo_profile' => 'sometimes|nullable|image'
        ];

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }
        $user = $this->auth()->user();
        if($request->mobile!='' && $request->mobile!=$user->mobile) {
            $user->status = 0;
        }

        $data['name'] = request('name');
		if (request()->hasFile('photo_profile')) {
			it()->delete($user->photo_profile);
			$data['photo_profile'] = it()->upload('photo_profile', 'users');
		}

		$user->update($data);
        return $this->returnData(new \App\Http\Resources\Users\UsersResource($user), trans('auth.updated'));
	}

    public function changeLang(Request $request) {
        $rules = [
			'lang' => 'required|alpha',
        ];

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }
        $user = $this->auth()->user();

        $data['lang'] = request('lang');
		$user->update($data);
        return $this->returnData(new \App\Http\Resources\Users\UsersResource($user), trans('auth.updated'));
	}

	/**
	 * change Password Method
	 *
	 * @return \Illuminate\Http\JsonResponse
	 */
	public function change_password(Request $request) {
        $rules = [
			'current_password' => 'required',
			'new_password' => [
				'required',
				'different:current_password',
				'string', Password::min(6),
			],
			'password_confirmation' => [
				'required',
				'same:new_password',
				'string', Password::min(6),
			],
        ];
        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }
        if (!Hash::check($request->current_password, $this->auth()->user()->password)) {
            return $this->returnError('422', trans('auth.invalidPassword'));
        }

		User::where('id', $this->auth()->user()->id)->update([
			'password' => bcrypt(request('new_password')),
		]);

        return $this->returnData('', trans('auth.updated'));
    }

	public function addDelivery(Request $request) {
        $rules = [
			'mobile' => 'required|exists:users,mobile',
        ];

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }

		$delivery = User::where(['mobile' => $request->mobile, 'type' => 'delivery'])->first();
		if (!$delivery) {
			return $this->returnError('422', trans('auth.invalidData'));
		}

		$check_deliveries = BranchDelivery::where('delivery_id', $delivery->id)->first();
        if ($check_deliveries) {
	        if ($check_deliveries->branch_id==$this->auth()->user()->id) {
            	return $this->returnError('422', trans('auth.delivery_added_before'));
			} else {
            	return $this->returnError('422', trans('auth.delivery_added_for_another_branch_or_vendor'));
			}
        }
		BranchDelivery::create([
			'branch_id' => $this->auth()->user()->id,
			'delivery_id' => $delivery->id
		]);

        return $this->returnData('', trans('auth.delivery_added'));
    }

	public function deliveries() {

		$deliveries = User::whereIn('id', function($query) {
			$query->select('delivery_id')->from('branch_deliveries')
			->where('branch_id', $this->auth()->user()->id);
		})->get();

        return $this->returnData(BranchesDeliveriesResource::collection($deliveries), '');
    }

	public function deliveryDetails($id) {

		$deliveries = User::whereIn('id', function($query) {
			$query->select('delivery_id')->from('branch_deliveries')
			->where('branch_id', $this->auth()->user()->id);
		})->findOrFail($id);

        return $this->returnData(new BranchesDeliveryDetailsResource($deliveries), '');
    }
}
