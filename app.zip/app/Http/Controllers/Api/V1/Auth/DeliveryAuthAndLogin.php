<?php
namespace App\Http\Controllers\Api\V1\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\UserAddress;
use App\Http\Resources\Users\DeliveryResource;
use App\Http\Resources\Cars\CarsResource;
use App\Models\WalletTransaction;
use App\Events\SendOtpEvent;
use Illuminate\Http\Request;
use Tymon\JWTAuth\Exceptions\JWTException;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rules\Password;
use App\Services\OTPService;
use Hash;
use App\Http\Controllers\Api\V1\AccountPaymentApi;
use App\Services\AutoAssignmentService;
use App\Traits\GeneralTrait;

// Auto Configured by (IT) Baboon maker (phpanonymous/it package)

class DeliveryAuthAndLogin extends Controller {

    use GeneralTrait;

	/**
	 * Create a new AuthController instance.
	 *
	 * @return void
	 */
	public function __construct() {
		$this->middleware('jwt.verify', ['except' => ['register', 'checkMobile', 'verifyAccount', 'addVerifyTrail', 'getVerifyTrail', 'login', 'forgetPassword', 'restetPassword']]);
	}

	/**
	 * register & Get a JWT via given credentials.
	 *
	 * @return \Illuminate\Http\JsonResponse
	 */
	public function register(Request $register) {
		$register = $register->all();
		$register['password'] = bcrypt(request('password'));
		$register['type'] = 'delivery';

        $rules = [
			'name' => 'required|alpha',
			'mobile' => 'required|regex:/[0-9]{8}/|unique:users,mobile',
			'national_id' => 'required|numeric',
			'password' => [
				'required',
				//'string', Password::min(6)->mixedCase()->numbers()->symbols()->uncompromised(),
				'string', Password::min(6),
			],
			'car_id' => 'required|exists:cars,id',
			'max_load' => 'required',
			'plate_number' => 'required',
			'car_color' => 'required',
			'nid_image' => 'required',
			'licence_image' => 'required',
			'car_form_image' => 'required',
			'car_front_image' => 'required',
			'car_back_image' => 'required',
			'photo_profile' => 'required',
			'transport_license_image' => 'nullable',
			'address' => 'required|max:500',
			'latitude' => 'required|regex:/([0-9.-]+).+?([0-9.-]+)/',
			'longitude' => 'required|regex:/([0-9.-]+).+?([0-9.-]+)/'
        ];

        $validator = Validator::make($register, $rules);

        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }
		if (request()->hasFile('nid_image')) {
			$register['nid_image'] = it()->upload('nid_image', 'users');
		}
		if (request()->hasFile('licence_image')) {
			$register['licence_image'] = it()->upload('licence_image', 'users');
		}
		if (request()->hasFile('car_form_image')) {
			$register['car_form_image'] = it()->upload('car_form_image', 'users');
		}
		if (request()->hasFile('car_front_image')) {
			$register['car_front_image'] = it()->upload('car_front_image', 'users');
		}
		if (request()->hasFile('car_back_image')) {
			$register['car_back_image'] = it()->upload('car_back_image', 'users');
		}
		if (request()->hasFile('photo_profile')) {
			$register['photo_profile'] = it()->upload('photo_profile', 'users');
		}
		if (request()->hasFile('transport_license_image')) {
			$register['transport_license_image'] = it()->upload('transport_license_image', 'users');
		}

		$user = User::create($register);
		if($user) {
    		$address = UserAddress::create([
    		        'user_id' => $user->id,
        		    'description' => $register['address'],
        		    'latitude' => $register['latitude'],
        		    'longitude' => $register['longitude'],
        		    'is_default' => 1
    		    ]);
    		event(New SendOtpEvent($user));
		}

        return $this->returnData(new DeliveryResource($user), trans('auth.delivery_account_created'));
	}

	public function checkMobile(Request $register) {
		$register = $register->except('lang');

        $rules = [
			'mobile' => 'required|regex:/[0-9]{8}/|unique:users,mobile',
        ];

        $validator = Validator::make($register, $rules);

        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }

        return $this->returnData('', trans('auth.available_mobile')); 
	}

    public function verifyAccount(Request $request)
    {
        $rules = [
			'mobile' => 'required',
			'otp_code' => 'required',
			'password' => 'required',
        ];

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }

        $credentials = [
            'mobile' => $request->mobile,
            'password' => $request->password
        ];

		try {
			if (!$token = $this->auth()->attempt($credentials)) {
                return $this->returnError('422', trans('auth.failed'));
			}
		} catch (JWTException $e) {
            return $this->returnError('422', trans('auth.token_failed'));
		}

		$user = User::where('mobile', request('mobile'))->first();
		if ($user->status==1) {
            return $this->returnError('422', trans('auth.alreadyVerified'));
		}
        
		if ($user->otp_code!=$request->otp_code) {
            return $this->returnError('422', trans('auth.invaliOtp'));
		}
		
		//verify user account
        $user->status = 1;
        $user->fcm_token = $request->fcm_token;
        $user->device_type = $request->device_type;
        $user->save();
        if($user->approved==1) {
            return $this->returnData($this->respondWithToken($token), '');  //return json response
        } else {
            return $this->returnError('433', trans('auth.approved_waiting_approve'));
        }

    }

    public function addVerifyTrail(Request $request)
    {
        $rules = [
			'mobile' => 'required',
        ];

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }

		$user = User::where(['mobile' => request('mobile'), 'type' => 'user'])->first();
		if (!$user) {
            return $this->returnError('422', trans('auth.failed'));
		}
		/*
		if ($user->otp_verify_trails>10) {
            return $this->returnError('422', trans('auth.exceddedLmit'));
		}
		*/
        $user->otp_verify_trails += 1;
        if($user->otp_verify_trails==3) {
            $user->otp_verify_date = date('Y-m-d', strtotime(' + 1 day'));
        }
        $user->save();
        return $this->returnData('', '');

    }

    public function getVerifyTrail(Request $request)
    {
        $rules = [
			'mobile' => 'required',
        ];

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }

		$user = User::where(['mobile' => request('mobile'), 'type' => 'user'])->first();
		if (!$user) {
            return $this->returnError('422', trans('auth.failed'));
		}
        return $this->returnData(['trails' => $user->otp_verify_trails], '');

    }
	
	/**
	 * Get a JWT via given credentials.
	 * Login Auth
	 * @return \Illuminate\Http\JsonResponse
	 */
	public function login(Request $request) {

        $rules = [
			'mobile' => 'required',
			'password' => 'required',
        ];

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }

        $credentials = ['mobile'=>request('mobile'),'password'=>request('password')];
		try {
			if (!$token = $this->auth()->attempt($credentials)) {
                return $this->returnError('422', trans('auth.failed'));
			}
            $user = \App\Models\User::where(['mobile' => request('mobile')])->first();
            if($user->type!='delivery') {
                return $this->returnError('422', trans('auth.failed'));
            }
            if($user->deleted==1) {
                return $this->returnError('422', trans('auth.failed'));
            }
            if($user->status!=1) {
                return $this->returnError('433', trans('auth.activate_mobile_first'));
            }
            if($user->approved!=1) {
                return $this->returnError('433', trans('auth.waiting_approve'));
            }
            if($request->fcm_token) {
                $user->fcm_token = $request->fcm_token;
                $user->device_type = $request->device_type;
                $user->save();
            }
		} catch (JWTException $e) {
			//return errorResponseJson(['error' => 'Unauthorized', 'message' => 'Could not create token']);
            return $this->returnError('422', trans('auth.token_failed'));
		}

		//return successResponseJson(['data' => $this->respondWithToken($token)]);
        return $this->returnData($this->respondWithToken($token), '');
	}

	/**
	 * change Password Method
	 *
	 * @return \Illuminate\Http\JsonResponse
	 */

    public function forgetPassword(Request $request) {
        $rules = [
			'mobile' => 'required|exists:users,mobile',
        ];

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }

        $user = User::where('mobile', $request->mobile)->first();
        /*
		if ($user->otp_trails>10) {
            return $this->returnError('422', trans('auth.exceddedLmit'));
		}
        */
        $user->otp_trails += 1;
        if($user->otp_trails==3) {
            $user->otp_date = date('Y-m-d', strtotime(' + 1 day'));
        }
        $user->save();

        event(New SendOtpEvent($user));

        return $this->returnData('', trans('auth.otpSent'));
    }

    public function restetPassword(Request $request) {
        $rules = [
			'mobile' => 'required|regex:/[0-9]{8}/|exists:users,mobile',
			'otp_code' => 'required',
			'new_password' => [
				'required',
				'different:otp_code',
			],
			'password_confirmation' => [
				'required',
				'same:new_password',
				'string', Password::min(6)
			],
        ];

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }
        $user = User::where('mobile', $request->mobile)->first();

        if($user->otp_code!=$request->otp_code) {
            return $this->returnError('422', trans('auth.invaliOtp'));
        }

		$user->update([
			'password' => bcrypt(request('new_password')),
            'otp_code' => null,
		]);
        return $this->returnData('', trans('auth.password_changed'));
	}

	private function auth() {
		return auth()->guard('api');
	}
	/**
	 * Get the token array structure.
	 *
	 * @param  string $token
	 *
	 * @return \Illuminate\Http\JsonResponse
	 */
	protected function respondWithToken($token) {

		$user = $this->auth()->user();
        //check if this delivery has on-going orders, or his availability is 0
        $delivery_recent_orders = \App\Models\Order::whereIn('id', function($query) use($user) {
            $query->select('order_id')->from('order_items')->where('delivery_id', $user->id);
        })
        ->where('status_id', 1)
        ->first();

        if($user->availability==0 || $delivery_recent_orders) {

            $availability = 0;
        } else {
            $availability = 1;
        }

        $data = [
            'id' => $user->id,
            'name' => $user->name,
            'mobile' => $user->mobile,
            'national_id' => $user->national_id,
            'car' => new CarsResource($user->car),
            'max_load' => $user->max_load,
            'plate_number' => $user->plate_number,
            'car_color' => $user->car_color,
            'photo_profile' => it()->url($user->photo_profile),
            'nid_image' => it()->url($user->nid_image),
            'licence_image' => it()->url($user->licence_image),
            'car_form_image' => it()->url($user->car_form_image),
            'car_front_image' => it()->url($user->car_front_image),
            'car_back_image' => it()->url($user->car_back_image),
            'transport_license_image' => it()->url($user->transport_license_image),
            'default_address' => $user->default_address,
            'device_type' => $user->device_type,
			'lang' => $user->lang,
			'status' => $user->status,
			'approved' => $user->approved,
			'availability' => $availability,
            'access_token' => $token
        ];

		return [
			'user' => $data,
		];
		/*
		return [
			'access_token' => $token,
			'token_type' => 'Bearer',
			'expires_in' => $this->auth()->factory()->getTTL() * 60,
			'user' => $this->auth()->user(),
		];
		*/
	}

	/**
	 * Get the authenticated User.
	 *
	 * @return \Illuminate\Http\JsonResponse
	 */
	public function me() {

        return $this->returnData($this->auth()->user(), '');
	}

	/**
	 * Log the user out (Invalidate the token).
	 *
	 * @return \Illuminate\Http\JsonResponse
	 */
	public function logout() {
		$this->auth()->logout();

        return $this->returnData('', '');
	}

	/**
	 * Refresh a token.
	 *
	 * @return \Illuminate\Http\JsonResponse
	 */
	public function refresh() {

        return $this->returnData($this->respondWithToken($this->auth()->refresh()), '');
	}

	public function account() {

        return $this->returnData(new \App\Http\Resources\Users\DeliveryResource($this->auth()->user()), '');
	}

	public function report() {

        return $this->returnData(new \App\Http\Resources\Users\DeliveryReportResource($this->auth()->user()), '');
	}

	public function notifications() {

		$notifications = \App\Models\MobileNotification::where('user_id', $this->auth()->user()->id)->orderBy('id', 'desc')->get();
		foreach(\App\Models\MobileNotification::where('user_id', $this->auth()->user()->id)->get() as $not) {
		    $not->read=1;
		    $not->save();
		}
        return $this->returnData(\App\Http\Resources\Notifications\NotificationsResource::collection($notifications), '');
	}

    public function updateProfile(Request $request) {
        $rules = [
            'name'     => 'nullable|max:100|regex:/^[\pL\s\-]+$/u',
			'mobile' => 'nullable|regex:/[0-9]{8}/|unique:users,mobile,' . $this->auth()->user()->id,
			//'photo_profile' => 'nullable|image'
			'national_id' => 'nullable|numeric',
			'car_id' => 'nullable|exists:cars,id',
			'max_load' => 'nullable',
			'plate_number' => 'nullable',
			'car_color' => 'nullable',
        ];

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }
        $user = $this->auth()->user();
        if($request->mobile!='' && $request->mobile!=$user->mobile) {
            $user->status = 0;
        }

        if($request->name=='' && $request->mobile=='' && $request->national_id=='' && $request->car_id=='' && $request->max_load=='' && $request->plate_number=='' && $request->car_color=='') {
            return $this->returnError('422', trans('auth.noDataToUpdate'));
        }

        $data['name'] = request('name');
        
		if (request()->national_id) {
			$data['national_id'] = request()->national_id;
		}
		if (request()->car_id) {
			$data['car_id'] = request()->car_id;
		}
		if (request()->max_load) {
			$data['max_load'] = request()->max_load;
		}
		if (request()->plate_number) {
			$data['plate_number'] = request()->plate_number;
		}
		if (request()->car_color) {
			$data['car_color'] = request()->car_color;
		}
		
		if (request()->hasFile('photo_profile')) {
			it()->delete($user->photo_profile);
			$data['photo_profile'] = it()->upload('photo_profile', 'users');
		}

		$user->update($data);
        return $this->returnData(new DeliveryResource($user), trans('auth.updated'));
	}

    public function changeLang(Request $request) {
        $rules = [
			'lang' => 'required|alpha',
        ];

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }
        $user = $this->auth()->user();

        $data['lang'] = request('lang');
		$user->update($data);
        return $this->returnData(new DeliveryResource($user), trans('auth.updated'));
	}

	/**
	 * change Password Method
	 *
	 * @return \Illuminate\Http\JsonResponse
	 */
	public function change_password(Request $request) {
        $rules = [
			'current_password' => 'required',
			'new_password' => [
				'required',
				'different:current_password',
				'string', Password::min(6),
			],
			'password_confirmation' => [
				'required',
				'same:new_password',
				'string', Password::min(6),
			],
        ];
        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }
        if (!Hash::check($request->current_password, $this->auth()->user()->password)) {
            return $this->returnError('422', trans('auth.invalidPassword'));
        }

		User::where('id', $this->auth()->user()->id)->update([
			'password' => bcrypt(request('new_password')),
		]);

        return $this->returnData('', trans('auth.updated'));
    }

    public function deleteAccount(Request $request) {

		$request = $request->except('lang');

        $user = User::whereId($this->auth()->user()->id)->first();
        $user->deleted = 1;
        $user->save();

        return $this->returnData('', trans('auth.account_deleted'));
	}

}
