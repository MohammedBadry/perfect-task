<?php
namespace App\Http\Controllers\Api\V1\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\WalletTransaction;
use App\Events\SendOtpEvent;
use Illuminate\Http\Request;
use Tymon\JWTAuth\Exceptions\JWTException;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rules\Password;
use App\Services\OTPService;
use Hash;
use App\Http\Controllers\Api\V1\AccountPaymentApi;
use App\Services\AutoAssignmentService;
use App\Traits\GeneralTrait;

// Auto Configured by (IT) Baboon maker (phpanonymous/it package)

class AuthAndLogin extends Controller {

    use GeneralTrait;

	/**
	 * Create a new AuthController instance.
	 *
	 * @return void
	 */
	public function __construct() {
		$this->middleware('jwt.verify', ['except' => ['register', 'checkEmail', 'checkMobile', 'verifyAccount', 'addVerifyTrail', 'getVerifyTrail', 'login', 'forgetPassword', 'restetPassword']]);
	}

	/**
	 * register & Get a JWT via given credentials.
	 *
	 * @return \Illuminate\Http\JsonResponse
	 */
	public function register(Request $register) {
		$register = $register->all();
		$register['password'] = bcrypt(request('password'));
		$register['type'] = 'user';
		//$register['email_verified_at'] =null;

        $rules = [
			'name' => 'required|alpha',
			'email' => 'required|email|unique:users,email',
			'mobile' => 'required|unique:users,mobile',
			'password' => [
				'required',
				//'string', Password::min(6)->mixedCase()->numbers()->symbols()->uncompromised(),
				'string', Password::min(6),
			],
        ];

        $validator = Validator::make($register, $rules);

        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }

		$user = User::create($register);

		event(New SendOtpEvent($user));

        return $this->returnData(['user' => new \App\Http\Resources\Users\UsersResource($user)], trans('auth.created'));
	}

	public function checkEmail(Request $register) {
		$register = $register->except('lang');

        $rules = [
			'email' => 'required|email|unique:users,email',
        ];

        $validator = Validator::make($register, $rules);

        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }

        return $this->returnData('', trans('auth.available_email')); 
	}

	public function checkMobile(Request $register) {
		$register = $register->except('lang');

        $rules = [
			'mobile' => 'required|unique:users,mobile',
        ];

        $validator = Validator::make($register, $rules);

        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }

        return $this->returnData('', trans('auth.available_mobile')); 
	}

    public function verifyAccount(Request $request)
    {
        $rules = [
			'mobile' => 'required',
			'otp_code' => 'required',
			'password' => 'required',
        ];

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }

        $credentials = [
            'mobile' => $request->mobile,
            'password' => $request->password
        ];

		try {
			if (!$token = $this->auth()->attempt($credentials)) {
                return $this->returnError('422', trans('auth.failed'));
			}
		} catch (JWTException $e) {
            return $this->returnError('422', trans('auth.token_failed'));
		}

		$user = User::where('mobile', request('mobile'))->first();
		if ($user->status==1) {
            return $this->returnError('422', trans('auth.alreadyVerified'));
		}
        
		if ($user->otp_code!=$request->otp_code) {
            return $this->returnError('422', trans('auth.invaliOtp'));
		}
		
		//verify user account
        $user->status = 1;
        $user->fcm_token = $request->fcm_token;
        $user->device_type = $request->device_type;
        $user->save();

        return $this->returnData($this->respondWithToken($token), '');  //return json response

    }

    public function addVerifyTrail(Request $request)
    {
        $rules = [
			'mobile' => 'required',
        ];

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }

		$user = User::where(['mobile' => request('mobile'), 'type' => 'user'])->first();
		if (!$user) {
            return $this->returnError('422', trans('auth.failed'));
		}
		/*
		if ($user->otp_verify_trails>10) {
            return $this->returnError('422', trans('auth.exceddedLmit'));
		}
		*/
        $user->otp_verify_trails += 1;
        if($user->otp_verify_trails==3) {
            $user->otp_verify_date = date('Y-m-d', strtotime(' + 1 day'));
        }
        $user->save();
        return $this->returnData('', '');

    }

    public function getVerifyTrail(Request $request)
    {
        $rules = [
			'mobile' => 'required',
        ];

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }

		$user = User::where(['mobile' => request('mobile'), 'type' => 'user'])->first();
		if (!$user) {
            return $this->returnError('422', trans('auth.failed'));
		}
        return $this->returnData(['trails' => $user->otp_verify_trails], '');

    }
	
	/**
	 * Get a JWT via given credentials.
	 * Login Auth
	 * @return \Illuminate\Http\JsonResponse
	 */
	public function login(Request $request) {

        $rules = [
			'mobile' => 'required',
			'password' => 'required',
        ];

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }

        $credentials = ['mobile'=>request('mobile'),'password'=>request('password')];
		try {
			if (!$token = $this->auth()->attempt($credentials)) {
                return $this->returnError('422', trans('auth.failed'));
			}
            $user = \App\Models\User::where(['mobile' => request('mobile')])->first();
            if($user->type!='user') {
                return $this->returnError('422', trans('auth.failed'));
            }
            if($user->deleted==1) {
                return $this->returnError('422', trans('auth.failed'));
            }
            if($user->status!=1) {
                return $this->returnError('433', trans('auth.activate_mobile_first'));
            }
            if($request->fcm_token) {
                $user->fcm_token = $request->fcm_token;
                $user->device_type = $request->device_type;
                $user->save();
            }
		} catch (JWTException $e) {
			//return errorResponseJson(['error' => 'Unauthorized', 'message' => 'Could not create token']);
            return $this->returnError('422', trans('auth.token_failed'));
		}

		//return successResponseJson(['data' => $this->respondWithToken($token)]);
        return $this->returnData($this->respondWithToken($token), '');
	}

	/**
	 * change Password Method
	 *
	 * @return \Illuminate\Http\JsonResponse
	 */

    public function forgetPassword(Request $request) {
        $rules = [
			'mobile' => 'required|exists:users,mobile',
        ];

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }

        $user = User::where('mobile', $request->mobile)->first();
        /*
		if ($user->otp_trails>10) {
            return $this->returnError('422', trans('auth.exceddedLmit'));
		}
		*/

        $user->otp_trails += 1;
        if($user->otp_trails==3) {
            $user->otp_date = date('Y-m-d', strtotime(' + 1 day'));
        }
        $user->save();

        event(New SendOtpEvent($user));

        return $this->returnData('', trans('auth.otpSent'));
    }

    public function restetPassword(Request $request) {
        $rules = [
			'mobile' => 'required|exists:users,mobile',
			'otp_code' => 'required',
			'new_password' => [
				'required',
				'different:otp_code',
			],
			'password_confirmation' => [
				'required',
				'same:new_password',
				'string', Password::min(6)
			],
        ];

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }
        $user = User::where('mobile', $request->mobile)->first();

        if($user->otp_code!=$request->otp_code) {
            return $this->returnError('422', trans('auth.invaliOtp'));
        }

		$user->update([
			'password' => bcrypt(request('new_password')),
            'otp_code' => null,
		]);
        return $this->returnData('', trans('auth.password_changed'));
	}

	private function auth() {
		return auth()->guard('api');
	}
	/**
	 * Get the token array structure.
	 *
	 * @param  string $token
	 *
	 * @return \Illuminate\Http\JsonResponse
	 */
	protected function respondWithToken($token) {

		$user = $this->auth()->user();
        $data = [
            'id' => $user->id,
            'name' => $user->name,
            'email' => $user->email,
            'mobile' => $user->mobile,
            'photo_profile' => it()->url($user->photo_profile),
            'default_address' => $user->default_address,
            'device_type' => $user->device_type,
            'fcm_token' => $user->fcm_token,
            'access_token' => $token,
			'lang' => $user->lang
        ];

		return [
			'user' => $data,
		];
		/*
		return [
			'access_token' => $token,
			'token_type' => 'Bearer',
			'expires_in' => $this->auth()->factory()->getTTL() * 60,
			'user' => $this->auth()->user(),
		];
		*/
	}

	/**
	 * Get the authenticated User.
	 *
	 * @return \Illuminate\Http\JsonResponse
	 */
	public function me() {

        return $this->returnData($this->auth()->user(), '');
	}

	/**
	 * Log the user out (Invalidate the token).
	 *
	 * @return \Illuminate\Http\JsonResponse
	 */
	public function logout() {
		$this->auth()->logout();

        return $this->returnData('', '');
	}

	/**
	 * Refresh a token.
	 *
	 * @return \Illuminate\Http\JsonResponse
	 */
	public function refresh() {

        return $this->returnData($this->respondWithToken($this->auth()->refresh()), '');
	}

	public function account() {

        return $this->returnData(new \App\Http\Resources\Users\UsersResource($this->auth()->user()), '');
	}

	public function notifications() {

		$notifications = \App\Models\MobileNotification::where('user_id', $this->auth()->user()->id)->orderBy('id', 'desc')->get();
		foreach(\App\Models\MobileNotification::where('user_id', $this->auth()->user()->id)->get() as $not) {
		    $not->read=1;
		    $not->save();
		}
        return $this->returnData(\App\Http\Resources\Notifications\NotificationsResource::collection($notifications), '');
	}

    public function updateProfile(Request $request) {
        $rules = [
            'name'     => 'required|max:100|regex:/^[\pL\s\-]+$/u',
			'email' => 'sometimes|email|unique:users,email,' . $this->auth()->user()->id,
			'mobile' => 'sometimes|regex:/[0-9]{8}/|unique:users,mobile,' . $this->auth()->user()->id,
			'photo_profile' => 'sometimes|nullable|image'
        ];

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }
        $user = $this->auth()->user();
        /*if($request->mobile!='' && $request->mobile!=$user->mobile) {
            $user->status = 0;
            
            event(New SendOtpEvent($user));
        } */

        if($request->email) {
            $user->email = request('email');
        }

        $data['name'] = request('email');
		if (request()->hasFile('photo_profile')) {
			it()->delete($user->photo_profile);
			$data['photo_profile'] = it()->upload('photo_profile', 'users');
		}

		$user->update($data);
        return $this->returnData(new \App\Http\Resources\Users\UsersResource($user), trans('auth.updated'));
	}

    public function changeLang(Request $request) {
        $rules = [
			'lang' => 'required|alpha',
        ];

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }
        $user = $this->auth()->user();

        $data['lang'] = request('lang');
		$user->update($data);
        return $this->returnData(new \App\Http\Resources\Users\UsersResource($user), trans('auth.updated'));
	}

	/**
	 * change Password Method
	 *
	 * @return \Illuminate\Http\JsonResponse
	 */
	public function change_password(Request $request) {
        $rules = [
			'current_password' => 'required',
			'new_password' => [
				'required',
				'different:current_password',
				'string', Password::min(6),
			],
			'password_confirmation' => [
				'required',
				'same:new_password',
				'string', Password::min(6),
			],
        ];
        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }
        if (!Hash::check($request->current_password, $this->auth()->user()->password)) {
            return $this->returnError('422', trans('auth.invalidPassword'));
        }

		User::where('id', $this->auth()->user()->id)->update([
			'password' => bcrypt(request('new_password')),
		]);

        return $this->returnData('', trans('auth.updated'));
    }

    public function chargeWallet(Request $request) {

        $rules = [
			'payment_amount' => 'required|integer',
			'payment_method' => 'required|in:visa,master,mada,apple_pay',
        ];
        if($request->payment_method=='apple_pay') {
            $rules['payment_id'] = 'required';
        }
        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }

        if($request->payment_method=='apple_pay') {

			$user = User::whereId($this->auth()->user()->id)->first();
            //Save wallet transaction
            WalletTransaction::create([
                'user_id' => $user->id,
                'type' => 'charge',
                'amount' => $request->payment_amount,
                'payment_method' => $request->payment_method,
                'payment_id' => $request->payment_id,
                'last_wallet_balance' => $user->wallet_balance,
                'status' => 1
            ]);

            $user->wallet_balance += $request->payment_amount;
			$user->save();

            //send notification to admin
            //event(new DeliveryPaymentNotification($user));

			$not = new AutoAssignmentService();
            $not->sendNotification($user, trans('auth.successful_wallet_charge'), trans('auth.successful_wallet_charge'), 'wallet', $user->id, '');

            //return view('payment-status', ['status' => 'success']);
            return $this->returnData('', trans("auth.balance_added"));
        } else {
			$payment = new AccountPaymentApi();
			return $payment->executePayment($request->payment_amount, $request->payment_method, $this->auth()->user());
		}
	}

	public function walletTransactions() {

		$transactions = \App\Models\WalletTransaction::where('user_id', $this->auth()->user()->id)->orderBy('id', 'desc')->get();
        return $this->returnData(\App\Http\Resources\Users\WalletTransactionsResource::collection($transactions), '', ['wallet_blance' => $this->auth()->user()->wallet_balance]);
	}

	public function transferBalance(Request $request) {

        $rules = [
			'amount' => 'required|integer',
			'mobile' => 'required|exists:users',
        ];
        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }
		$user = User::whereId($this->auth()->user()->id)->first();
        $customer = User::where(['mobile' => $request->mobile, 'type' => 'user'])->firstOrFail();
        
        if($user->mobile == $request->mobile) {
            return $this->returnError('422', trans('auth.notAllowed'));
        }

        if($user->wallet_balance < $request->amount) {
            return $this->returnError('422', trans('auth.notEnoughBalance'));
        }
            //Save wallet transaction
            WalletTransaction::create([
                'user_id' => $user->id,
                'type' => 'transfer',
                'amount' => $request->amount,
                'payment_method' => 'wallet',
                'last_wallet_balance' => $user->wallet_balance,
                'status' => 1
            ]);
		
        //add balance to customer
        $customer->wallet_balance += $request->amount;
		$customer->save();
		
        //deduct balance from user
        $user->wallet_balance -= $request->amount;
		$user->save();

            //send notification to customer
			$not = new AutoAssignmentService();
            $not->sendNotification($customer, trans('auth.wallet_balance_transfer').$request->amount, trans('auth.wallet_balance_transfer').$request->amount, 'wallet', $customer->id, '');
            
		$transactions = \App\Models\WalletTransaction::where('user_id', $this->auth()->user()->id)->orderBy('id', 'desc')->get();
        return $this->returnData(\App\Http\Resources\Users\WalletTransactionsResource::collection($transactions), '', ['wallet_blance' => $this->auth()->user()->wallet_balance]);
	}

    public function deleteAccount(Request $request) {

		$request = $request->except('lang');

        $user = User::whereId($this->auth()->user()->id)->first();
        $user->deleted = 1;
        $user->save();

        return $this->returnData('', trans('auth.account_deleted'));
	}

}
