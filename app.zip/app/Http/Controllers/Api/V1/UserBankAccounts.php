<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Models\UserBankAccount;
use Validator;
use App\Http\Resources\BankAccounts\BankAccountsResource;
use App\Traits\GeneralTrait;

class UserBankAccounts extends Controller
{
    use GeneralTrait;

    protected $selectColumns = [
    ];

    /**
     * Display the specified releationshop.
     * @return array to assign with index & show methods
     */
    public function arrWith()
    {
        return [];
    }


    /**
     * Display a listing of the resource. Api
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $accounts = UserBankAccount::where('user_id', auth()->guard('api')->user()->id)->paginate();
        return $this->returnData(BankAccountsResource::collection($accounts), '');
    }

    public function store(Request $request)
    {
        $rules['bank_name'] = 'required';
        $rules['bank_account'] = 'required|numeric';
        $rules['iban'] = 'required';

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }

        $check = UserBankAccount::where([
            'user_id' => auth()->guard('api')->user()->id,
            'bank_account' => $request->bank_account,
            'iban' => $request->iban
        ])
        ->first();
        if($check){
            return $this->returnError('422', trans("auth.addedBefore"));
        }

        UserBankAccount::create([
            'user_id' => auth()->guard('api')->user()->id,
            'bank_name' => $request->bank_name,
            'bank_account' => $request->bank_account,
            'iban' => $request->iban
        ]);

        return $this->returnData('', trans('auth.added'));
    }

    /**
     * destroy a newly created resource in storage.
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $account = UserBankAccount::find($id);
        if(is_null($account) || empty($account)){
            return $this->returnError('422', trans('auth.undefinedRecord'));
        }

        $account->delete();
        return $this->returnData('', trans("auth.deleted"));
    }
}
