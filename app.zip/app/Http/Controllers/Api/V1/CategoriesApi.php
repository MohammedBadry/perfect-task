<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Models\Category;
use Validator;
use App\Http\Controllers\ValidationsApi\V1\CategoriesRequest;
use App\Http\Resources\Categories\CategoriesResource;
use App\Http\Resources\Categories\CategoriesSubResource;
use App\Traits\GeneralTrait;

class CategoriesApi extends Controller
{
    use GeneralTrait;

    protected $selectColumns = [
        "id",
        "name_ar",
        "name_en",
        "image"
    ];

    /**
     * Display the specified releationshop.
     * @return array to assign with index & show methods
     */
    public function arrWith()
    {
        return [];
    }


    /**
     * Display a listing of the resource. Api
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $Category = Category::select($this->selectColumns)->main()->with($this->arrWith())->orderBy("id", "desc")->get();
        return $this->returnData(CategoriesResource::collection($Category), '');  //return json response
    }

    public function sub(Category $category)
    {
        $Category = Category::where('parent_id', $category->id)->orderBy("id", "desc")->get();
        return $this->returnData(CategoriesSubResource::collection($Category), '');  //return json response
    }

}
