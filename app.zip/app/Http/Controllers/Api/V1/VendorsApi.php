<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Models\Admin;
use App\Models\VendorRating;
use App\Models\Category;
use App\Models\User;
use App\Models\UserAddress;
use Validator;
use App\Http\Controllers\ValidationsApi\V1\BannersRequest;
use App\Http\Resources\Vendors\VendorDetailsResource;
use App\Http\Resources\Branches\BranchesResource2;
use App\Traits\GeneralTrait;
use DB;

class VendorsApi extends Controller
{
    use GeneralTrait;

    protected $selectColumns = [
    ];

    /**
     * Display the specified releationshop.
     * @return array to assign with index & show methods
     */
    public function arrWith()
    {
        return ['categories'];
    }


    /**
     * Display a listing of the resource. Api
     * @return \Illuminate\Http\Response
     */
    public function categoryVendors(Category $category, Request $request)
    {
        //$sub_cats = Category::where('parent_id', $category->id)->pluck('id');

        $category_id = $category->id;
        $category_parent_id = $category->parent_id;
        if($request->city_id!='') {
            $city_id = $request->city_id;
        } else {
            $city_id = auth()->user()->city_id;
        }
        if($request->area_id!='') {
            $area_id = $request->area_id;
        } else {
            $area_id = auth()->user()->area_id;
        }

        $branches = User::where('type', 'branch')
                ->whereIn('vendor_id', function($query) use ($category_parent_id) {
                    $query->select('id')
                    ->from('admins')
                    ->where(['status' => 1, 'is_vendor' => 1])
                    ->whereIn('id', function($query) use ($category_parent_id) {
                        $query->select('vendor_id')->from('vendor_categories')->where('category_id', $category_parent_id);
                    });            
                })
                ->when($city_id, function($query) use ($city_id) {
                    $query->where('city_id', $city_id);
                })
                ->when($area_id, function($query) use ($area_id) {
                    $query->where('area_id', $area_id);
                })
                ->get();

        $vendors = Admin::with($this->arrWith())
        ->where(['status' => 1, 'is_vendor' => 1])
        // this sub category is under vendor parent category
        ->whereIn('id', function($query) use ($category_parent_id) {
            $query->select('vendor_id')->from('vendor_categories')->where('category_id', $category_parent_id);
        })
        //and the vendor already sale products for this category
        /*
        ->whereIn('id', function($query) use ($category_id) {
            $query->select('vendor_id')->from('products')->where('category_id', $category_id);
        })
        */
        //get vendors who have branches in this city
        ->whereIn('id', function($query) use ($city_id) {
            $query->select('vendor_id')->from('users')->where('type', 'branch')->where('city_id', $city_id);
        })
        //get vendors who have branches in this area
        ->whereIn('id', function($query) use ($area_id) {
            $query->select('vendor_id')->from('users')->where('type', 'branch')->where('area_id', $area_id);
        })
        ->get();

        return $this->returnData(BranchesResource2::collection($branches), '');
    }

    public function subcategoriesVendors(Category $category, Request $request)
    {
        if($request->latitude && $request->longitude) {
            $lat = $request->latitude;
            $lon = $request->longitude;
        } else {
            $user_address = UserAddress::where(["user_id" => auth()->guard('api')->user()->id, 'is_default' => 1 ])->first();
            if($user_address) {
                $lat = $user_address->latitude;
                $lon = $user_address->longitude;
            } else {
                $lat = '';
                $lon = '';
            }
        }
        if($lat && $lon) {
            $nearest_vendors = DB::table("admins")
                ->select("*"
                    ,DB::raw("6371 * acos(cos(radians(" . $lat . "))
                    * cos(radians(admins.latitude))
                    * cos(radians(admins.longitude) - radians(" . $lon . "))
                    + sin(radians(" .$lat. ")) * sin(radians(admins.latitude))) AS distance "))
                    ->where(['status' => 1, 'is_vendor' => 1, 'category_id' => $category->id ])
                    ->where('latitude', '!=', null)
                    ->where('latitude', '!=', null)
                    //->having('distance', '<', 25)
                    ->orderBy('distance', 'asc')
                    ->limit(4)
                    ->get();
        } else {
            $nearest_vendors = [];
        }
        $top_vendors = DB::table('admins')
                ->select('admins.*')
                ->join('orders', 'admins.id', '=', 'orders.vendor_id')
                ->join('order_items', 'orders.id', '=', 'order_items.order_id')
                ->where(['admins.status' => 1, 'admins.is_vendor' => 1, 'admins.category_id' => $category->id ])
                ->orderBy('quantity', 'desc')
                ->limit(4)
                ->get();

        $result = [
            'nearest_vendors' => VendorDetailsResource::collection($nearest_vendors),
            'top_vendors' => VendorDetailsResource::collection($top_vendors),
        ];
        return $this->returnData($result, '');
    }

    public function show($id)
    {
        $vendor = Admin::with($this->arrWith())->find($id);
        if(is_null($vendor) || empty($vendor)){
            return $this->returnError('422', trans('auth.undefinedRecord'));
        }
        return $this->returnData(new VendorDetailsResource($vendor), '');
    }

    public function rateVendor(Request $request, $id)
    {
        $branch = User::find($id);
        if(is_null($branch) || empty($branch)){
            return $this->returnError('422', trans("auth.undefinedRecord"));
        }
        $rules['rating'] = 'required|integer';
        $rules['comment'] = 'nullable';

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }


        $rating_exists = VendorRating::where([
            'user_id' => auth()->guard('api')->user()->id,
            'vendor_id' => $branch->vendor_id,
            'branch_id' => $id,
        ])
        ->first();
        if(!$rating_exists) {
            VendorRating::create([
                'user_id' => auth()->guard('api')->user()->id,
                'vendor_id' => $branch->vendor_id,
                'branch_id' => $id,
                'rating' => $request->rating
            ]);
        } else {
            $rating_exists->update(['rating' => $request->rating]);
        }
        return $this->returnData('', trans("auth.added"));
    }

}
