<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Models\Cart;
use App\Models\Product;
use Validator;
use App\Traits\GeneralTrait;
use App\Http\Resources\Cart\CartResource;
use App\Http\Resources\Vendors\VendorBankAccountResource;
use DB;
use App\Models\Setting;

class CartApi extends Controller
{
    use GeneralTrait;

    protected $selectColumns = [
    ];

    /**
     * Display the specified releationshop.
     * Baboon Api Script By [it v 1.6.39]
     * @return array to assign with index & show methods
     */
    public function arrWith()
    {
        return [];
    }


    /**
     * Baboon Api Script By [it v 1.6.39]
     * Display a listing of the resource. Api
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $cart = Cart::where('user_id', auth()->guard('api')->user()->id)->orderBy("id", "desc")->get();
        
        $cart_item = Cart::where('user_id', auth()->guard('api')->user()->id)->first();
        $branch_id = $cart_item ? $cart_item->branch_id : '';
        
        $setting = Setting::first();

        $tax = (auth()->guard('api')->user()->cartTotal()+auth()->guard('api')->user()->cartDeliveryCost())*($setting->tax/100);

        return $this->returnData(CartResource::collection($cart), '', [
            'branch_id' => $branch_id,
            'cart_total' => auth()->guard('api')->user()->cartTotal(),
            'tax' => $tax,
            'delivery_cost' => auth()->guard('api')->user()->cartDeliveryCost(),
            'final_total' => auth()->guard('api')->user()->cartTotal()+$tax+auth()->guard('api')->user()->cartDeliveryCost(),
            'bank_account_details' => new VendorBankAccountResource($setting)
        ]);
    }


    /**
     * Baboon Api Script By [it v 1.6.39]
     * Store a newly created resource in storage. Api
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->except("_token");

        $rules = [
			'branch_id' => 'required|exists:users,id',
			'product_id' => 'required|exists:products,id',
			'quantity' => 'required|integer',
        ];
        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }

        $product = Product::whereId($request->product_id)->first();
        
        $branch = $product->vendor->branches->where('id', $request->branch_id)->first();
        
        if (!$branch) {
            return $this->returnError('422', trans("auth.invalidBranch"));
        }
        
        if ($request->quantity < $product->minimum_order) {
            return $this->returnError('422', trans("auth.lessThanAllowedQuantity"));
        }

        $check_branch = Cart::where(['user_id' => auth()->guard('api')->user()->id])->first();
        if ($check_branch && $check_branch->branch_id!=$request->branch_id) {
            return $this->returnError('422', trans("auth.notAllowed"));
        }


        $check = Cart::where(['product_id' => $request->product_id, 'user_id' => auth()->guard('api')->user()->id])->first();

        $quantity = $request->quantity;
        
        $check_delivery_cost = \App\Models\ProductCarLoad::where('product_id', $request->product_id)
        ->where(function ($query) use ($quantity) {
            $query->where('from', '<=', $quantity);
            $query->where('to', '>=', $quantity);
        })->first();
        
        if(!$check_delivery_cost) {
            return $this->returnError('422', trans("auth.moreThanAllowedQuantity"));
        }
                
        $delivery_cost = $check_delivery_cost->car->delivery_cost;

        if ($check) {
            $check->quantity = $request->quantity;
            $check->delivery_cost = $delivery_cost;
            $check->save();
            return $this->returnData('', trans("auth.updated"));
        }

        DB::beginTransaction();
        $data['user_id'] = auth()->guard('api')->user()->id;
        $data['delivery_cost'] = $delivery_cost;
        $cart = Cart::create($data);

        DB::commit();

        return $this->returnData('', trans("auth.added"));
    }


    /**
     * Display the specified resource.
     * Baboon Api Script By [it v 1.6.39]
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $cart = Cart::find($id);
        if (is_null($cart) || empty($cart)) {
            return $this->returnError('422', trans("auth.undefinedRecord"));
        }

        return $this->returnData(new CartResource($cart), '');
    }

    /**
     * Baboon Api Script By [it v 1.6.39]
     * update a newly created resource in storage.
     * @return \Illuminate\Http\Response
     */
    public function updateFillableColumns()
    {
        $fillableCols = [];
        foreach (array_keys((new Request)->attributes()) as $fillableUpdate) {
            if (!is_null(request($fillableUpdate))) {
                $fillableCols[$fillableUpdate] = request($fillableUpdate);
            }
        }
        return $fillableCols;
    }

    public function update(Request $request, $id)
    {
        $cart = Cart::where(['id' => $id, 'user_id' => auth()->guard('api')->user()->id])->first();
        if (is_null($cart) || empty($cart)) {
            return $this->returnError('422', trans("auth.undefinedRecord"));
        }
        $rules = [
			'quantity' => 'required|integer',
        ];

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }

        $quantity = $request->quantity;
        $check_delivery_cost = \App\Models\ProductCarLoad::where('product_id', $request->product_id)
        ->where(function ($query) use ($quantity) {
            $query->where('from', '<=', $quantity);
            $query->where('to', '>=', $quantity);
        })->first();
        $delivery_cost = $check_delivery_cost->car->delivery_cost;


        $cart = Cart::where(["id" => $id, 'user_id'=> auth()->guard('api')->user()->id])->update(['quantity' => $request->quantity, 'delivery_cost' => $delivery_cost]);

        $cart = Cart::where('id', $id)->first();
        return $this->returnData(new CartResource($cart), trans("auth.updated"));
    }

    /**
     * Baboon Api Script By [it v 1.6.39]
     * destroy a newly created resource in storage.
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $carts = Cart::where(['id' => $id, 'user_id' => auth()->guard('api')->user()->id])->first();
        if (is_null($carts) || empty($carts)) {
            return $this->returnError('422', trans("auth.undefinedRecord"));
        }


        $carts->delete();
        return $this->returnData('', trans("auth.deleted"));
    }
    /*
    public function cartTotal() {
        $cart = Cart::where('user_id', auth()->guard('api')->user()->id)->get();
        $total = 0;
        $extras = 0;
        foreach ($cart as $c) {
            if(count($c->extras)>0) {
                foreach($c->extras as $extra) {
                        $extras += $extra->extra->extra_price;
                }
            }
            $total += ($c->product->price*$c->quantity)+$extras;
        }
        return $total;
    }
    */
}
