<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Models\Favourite;
use App\Models\Product;
use Validator;
use App\Traits\GeneralTrait;
use App\Http\Resources\Favourites\FavouritesResource;

class FavouritesApi extends Controller
{
    use GeneralTrait;

    protected $selectColumns = [
    ];

    /**
     * Display the specified releationshop.
     * Baboon Api Script By [it v 1.6.39]
     * @return array to assign with index & show methods
     */
    public function arrWith()
    {
        return [];
    }


    /**
     * Baboon Api Script By [it v 1.6.39]
     * Display a listing of the resource. Api
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $type = request()->type;
        $favourite = Favourite::where('user_id', auth()->guard('api')->user()->id)->when($type, function($query) use ($type) {
            $query->where('type', $type);
        })->orderBy("id", "desc")->get();
        return $this->returnData(FavouritesResource::collection($favourite), '');
    }


    /**
     * Baboon Api Script By [it v 1.6.39]
     * Store a newly created resource in storage. Api
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->except("_token");

        $rules = [
            'type'=>"required|in:product,branch",
        ];
        if($request->type=='product') {
            $rules['target_id'] = 'required|exists:products,id';
        } else {
            $rules['target_id'] = 'required|exists:users,id';
        }

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }

        if($request->type=='product') {
            $check = Favourite::where(['target_id' => $request->target_id, 'type' => 'product', 'user_id' => auth()->guard('api')->user()->id])->first();
        } else {
            $check = Favourite::where(['target_id' => $request->target_id, 'type' => 'branch', 'user_id' => auth()->guard('api')->user()->id])->first();
        }
        if ($check) {
            $check->delete();
            return $this->returnData('', trans("auth.deleted"));
        } else {
            $data['user_id'] = auth()->guard('api')->user()->id;
            $favourite = Favourite::create($data);
            return $this->returnData('', trans("auth.added"));
        }
    }


    /**
     * Display the specified resource.
     * Baboon Api Script By [it v 1.6.39]
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $favourite = Favourite::find($id);
        if (is_null($favourite) || empty($favourite)) {
            return $this->returnError('422', trans("auth.undefinedRecord"));
        }

        return $this->returnData(new FavouritesResource($favourite), '');
    }


    /**
     * Baboon Api Script By [it v 1.6.39]
     * update a newly created resource in storage.
     * @return \Illuminate\Http\Response
     */
    public function updateFillableColumns()
    {
        $fillableCols = [];
        foreach (array_keys((new Request)->attributes()) as $fillableUpdate) {
            if (!is_null(request($fillableUpdate))) {
                $fillableCols[$fillableUpdate] = request($fillableUpdate);
            }
        }
        return $fillableCols;
    }

    public function update(Request $request, $id)
    {
        $favourite = Favourite::find($id);
        if (is_null($favourite) || empty($favourite)) {
            return $this->returnError('422', trans("auth.undefinedRecord"));
        }

        $data = $this->updateFillableColumns();

        Favourite::where("id", $id)->update($data);

        $favourite = Favourite::find($id);
        return $this->returnData(new FavouritesResource($favourite), trans("auth.updated"));
    }

    /**
     * Baboon Api Script By [it v 1.6.39]
     * destroy a newly created resource in storage.
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {

        $rules = [
            'type'=>"required|in:product,branch",
        ];

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }
        $favourites = Favourite::where(['target_id' => $id, 'type' => $request->type, 'user_id' => auth()->guard('api')->user()->id])->first();
        if (is_null($favourites) || empty($favourites)) {
            return $this->returnError('422', trans("auth.undefinedRecord"));
        }


        it()->delete("favourite", $id);

        $favourites->delete();
        return $this->returnData('', trans("auth.deleted"));
    }
}
