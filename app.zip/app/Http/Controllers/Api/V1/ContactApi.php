<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Models\Ticket;
use App\Models\Setting;
use Validator;
//use App\Http\Resources\ContactUs\ContactUsResource;
use App\Notifications\AdminInqueryNotification;
use App\Traits\GeneralTrait;
use App\Events\InqueryEmailEvent;

class ContactApi extends Controller
{
    use GeneralTrait;

    protected $selectColumns = [
    ];

    /**
     * Display the specified releationshop.
     * @return array to assign with index & show methods
     */
    public function arrWith()
    {
        return [];
    }

    public function send(Request $request)
    {

        $rules = [
            'subject'=>"required|string|max:191",
            'message'=>'required',
        ];

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }
        $settings = Setting::first();
        $user = auth()->guard('api')->user();

        Ticket::create([
            'subject' => $request->subject,
            'message' => $request->message,
            'user_id' => auth()->guard()->user()->id,
        ]);
        //event(new InqueryEmailEvent($user, $settings));

        if($request->has('web')) {
            return redirect()->back()->with('message', 'تم إرسال رسالتك بنجاح');
        }
        return $this->returnData('', trans('auth.messageSent'));
    }
}
