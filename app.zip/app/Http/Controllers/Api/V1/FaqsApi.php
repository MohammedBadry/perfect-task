<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Models\Faq;
use Validator;
use App\Http\Controllers\ValidationsApi\V1\FaqsRequest;
use App\Http\Resources\Faqs\FaqsResource;
use App\Traits\GeneralTrait;

class FaqsApi extends Controller
{
    use GeneralTrait;

    protected $selectColumns = [
        "id", "question_ar", "question_en", "question_urdu", "answer_ar", "answer_en", "answer_urdu"
    ];

    /**
     * Display the specified releationshop.
     * @return array to assign with index & show methods
     */
    public function arrWith()
    {
        return [];
    }

    public function userFaqs()
    {
        $faq = Faq::select($this->selectColumns)
        ->with($this->arrWith())
        ->where('type', 'users')
        ->orderBy("id", "desc")->get();
        return $this->returnData(FaqsResource::collection($faq), '');
    }

    public function branchFaqs()
    {
        $faq = Faq::select($this->selectColumns)
        ->with($this->arrWith())
        ->where('type', 'branches')
        ->orderBy("id", "desc")->get();
        return $this->returnData(FaqsResource::collection($faq), '');
    }

    public function deliveryFaqs()
    {
        $faq = Faq::select($this->selectColumns)
        ->with($this->arrWith())
        ->where('type', 'deliveries')
        ->orderBy("id", "desc")->get();
        return $this->returnData(FaqsResource::collection($faq), '');  //return json response
    }

    /**
     * Display the specified resource.
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $faq = Faq::with($this->arrWith())->find($id, $this->selectColumns);
        if (is_null($faq) || empty($faq)) {
            return $this->returnError('422', trans("auth.undefinedRecord"));
        }

        return $this->returnData(new FaqsResource($faq), '');
    }

}
