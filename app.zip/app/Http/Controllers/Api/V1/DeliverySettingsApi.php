<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Models\Setting;
use Validator;
use App\Http\Resources\Settings\DeliverySettingsResource;
use App\Traits\GeneralTrait;

class DeliverySettingsApi extends Controller
{
    use GeneralTrait;

    protected $selectColumns = [
    ];

    /**
     * Display the specified releationshop.
     * @return array to assign with index & show methods
     */
    public function arrWith()
    {
        return [];
    }


    /**
     * Display a listing of the resource. Api
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $settings = Setting::first();
        return $this->returnData(new DeliverySettingsResource($settings), '');
    }
}
