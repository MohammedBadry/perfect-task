<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Models\Banner;
use Validator;
use App\Http\Controllers\ValidationsApi\V1\BannersRequest;
use App\Http\Resources\Banners\BannersResource;
use App\Traits\GeneralTrait;

class BannersApi extends Controller
{
    use GeneralTrait;

    protected $selectColumns = [
        "id",
        "image",
    ];

    /**
     * Display the specified releationshop.
     * @return array to assign with index & show methods
     */
    public function arrWith()
    {
        return [];
    }

    /**
     * Display a listing of the resource. Api
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $Banner = Banner::select($this->selectColumns)->with($this->arrWith())->orderBy("id", "desc")->get();
        return $this->returnData(BannersResource::collection($Banner), '');  //return json response
    }

}
