<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Models\UserAddress;
use Validator;
use App\Http\Resources\UserAddresses\UserAddressResource;
use App\Traits\GeneralTrait;

class UserAddressApi extends Controller
{
    use GeneralTrait;

    protected $selectColumns = [];

    /**
     * Display the specified releationshop.
     * @return array to assign with index & show methods
     */
    public function arrWith()
    {
        return [];
    }


    /**
     * Display a listing of the resource. Api
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $address = UserAddress::where('user_id', auth()->guard('api')->user()->id)
        ->orderBy("id","desc")->get();

        return $this->returnData(UserAddressResource::collection($address), '');
    }


    /**
     * Store a newly created resource in storage. Api
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $rules = [
			'address' => 'required',
			'description' => 'required|max:500',
			'city_id' => 'required|exists:cities,id',
			'area_id' => 'required|exists:areas,id',
			'district' => 'required|max:250',
			'street' => 'required|max:250',
			'latitude' => 'required|regex:/([0-9.-]+).+?([0-9.-]+)/',
			'longitude' => 'required|regex:/([0-9.-]+).+?([0-9.-]+)/'
        ];

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }
        if(UserAddress::where('user_id', auth()->guard('api')->user()->id)->get()->count()<1) {
            $request['is_default'] = 1;
        }
        if(UserAddress::where(['latitude'=> $request->latitude, 'longitude'=> $request->longitude, 'user_id' => auth()->guard('api')->user()->id])->get()->count()>0) {
            return $this->returnError('422', trans('auth.addedBefore'));
        }
        if($request->is_default==1) {
            $user_addresses = UserAddress::where("user_id", auth()->guard('api')->user()->id)->get();
            foreach($user_addresses as $address) {
                $address->is_default = 0;
                $address->save();
            }
        }
        $data['is_default'] = $request->is_default;
        $request['user_id'] = auth()->guard('api')->user()->id;
        $data = $request->except('lang');
		$address = UserAddress::create($data);
        return $this->returnData(new UserAddressResource($address), trans('auth.created'));
    }

    public function update($id, Request $request) {
        $addresses = UserAddress::find($id);
        if (is_null($addresses) || empty($addresses)) {
            return $this->returnError('422', trans('auth.undefinedRecord'));
        }
        if ($addresses->user_id!=auth()->guard('api')->user()->id) {
            return $this->returnError('422', trans('auth.notAllowed'));
        }

        $rules = [
			'address' => 'required',
			'description' => 'required|max:250',
			'city_id' => 'required|exists:cities,id',
			'area_id' => 'required|exists:areas,id',
			'district' => 'nullable|max:250',
			'street' => 'nullable|max:250',
			'latitude' => 'required|regex:/([0-9.-]+).+?([0-9.-]+)/',
			'longitude' => 'required|regex:/([0-9.-]+).+?([0-9.-]+)/'
        ];

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }

        if($request->address) {
            $data['address'] = $request->address;
        }
        if($request->description) {
            $data['description'] = $request->description;
        }
        if($request->city_id) {
            $data['city_id'] = $request->city_id;
        }
        if($request->area_id) {
            $data['area_id'] = $request->area_id;
        }
        if($request->district) {
            $data['district'] = $request->district;
        }
        if($request->street) {
            $data['street'] = $request->street;
        }
        if($request->latitude) {
            $data['latitude'] = $request->latitude;
        }
        if($request->longitude) {
            $data['longitude'] = $request->longitude;
        }
        if($request->is_default==1) {
            $user_addresses = UserAddress::where("user_id", auth()->guard('api')->user()->id)->get();
            foreach($user_addresses as $address) {
                $address->is_default = 0;
                $address->save();
            }
        }
        if($request->is_default) {
            $data['is_default'] = $request->is_default;
        }
        UserAddress::where("id",$id)->update($data);

        $address = UserAddress::find($id);

        return $this->returnData(new UserAddressResource($address), trans('auth.updated'));

    }

    public function makeDefault(Request $request,$id) {
        $addresses = UserAddress::find($id);

        if (is_null($addresses) || empty($addresses)) {
            return $this->returnError('422', trans('auth.undefinedRecord'));
        }
        if ($addresses->user_id!=auth()->guard('api')->user()->id) {
            return $this->returnError('422', trans('auth.notAllowed'));
        }

        $data = ['is_default' => 1];
        $user_addresses = UserAddress::where("user_id", auth()->guard('api')->user()->id)->get();

        foreach($user_addresses as $address) {
            $address->is_default = 0;
            $address->save();
        }

        UserAddress::where("id",$id)->update($data);

        $address = UserAddress::find($id);

        return $this->returnData(new UserAddressResource($address), trans('auth.updated'));

    }

    /**
     * destroy a newly created resource in storage.
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $addresses = UserAddress::find($id);
        if (is_null($addresses) || empty($addresses)) {
            return $this->returnError('422', trans('auth.undefinedRecord'));
        }

        $addresses->delete();
        return $this->returnData('', trans('auth.deleted'));
    }
}
