<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Carbon\Carbon;
use Validator;
use App\Models\User;
use App\Models\OrderItem;
use App\Models\WithdrawalRequest;
use App\Models\WithdrawalRelatedOrder;
use App\Http\Resources\WithdrawalRequests\WithdrawalRequestsResource;
use App\Traits\GeneralTrait;

class WithdrawalRequests extends Controller
{
    use GeneralTrait;

    /**
     * Display a listing of the resource. Api
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $rules = [
			'type' => 'required|in:withdrawal,order',
        ];
        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }
        if($request->type=='withdrawal') {
            $accounts = WithdrawalRequest::where('delivery_id', auth()->guard('api')->user()->id)->get();
        } else {
            $accounts = OrderItem::where(['delivery_id' => auth()->guard('api')->user()->id, 'status_id' => 5])->get();
        }
        return $this->returnData(WithdrawalRequestsResource::collection($accounts), '', ['wallet_balance' => auth()->guard('api')->user()->wallet_balance]);
    }

    public function store(Request $request)
    {
        $rules = [
			'bank_account_id' => 'required|exists:user_bank_accounts,id',
        ];
        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }

        $user = auth()->guard('api')->user();

        $check_bank_account = $user->bank_accounts->where('id', $request->bank_account_id)->first();
        if(!$check_bank_account) {
            return $this->returnError('422', trans("auth.notAllowed"));
        }

        $check = WithdrawalRequest::where(['delivery_id'=>$user->id, 'status'=>'pending'])->first();

        if($check) {
            return $this->returnError('422', trans("auth.pendingWithdrawalExsist"));
        }

        $wallet_balance = OrderItem::where(['delivery_id' => $user->id, 'status_id' => 'completed', 'paid_status' => 0])->sum('delivery_cost');

        if($user->wallet_balance<1) {
            return $this->returnError('422', trans("auth.notAllowedAmount"));
        }
        
        $balance_per_vendor = OrderItem::where(['delivery_id' => $user->id, 'status_id' => 5, 'paid_status' => 0])->groupBy('vendor_id')->get();
        
        foreach($balance_per_vendor as $b_p_v) {
            $ref_no = $this->getUniqueRefNumber();
            $withdReq = WithdrawalRequest::create([
                'ref_no' => $ref_no,
                'delivery_id' => $user->id,
                'vendor_id' => $b_p_v->vendor_id,
                'amount' => $b_p_v->delivery_cost,
                'bank_account_id' => $request->bank_account_id,
                'status' => 'pending'
            ]);
            
            $separated_orders = OrderItem::where(['delivery_id' => $user->id, 'vendor_id' => $b_p_v->vendor_id, 'status_id' => 5, 'paid_status' => 0])->get();
            foreach($separated_orders as $s_ords) {
                WithdrawalRelatedOrder::create([
                        'withdrawal_request_id' => $withdReq->id,
                        'order_item_id' => $s_ords->id,
                    ]);
            }
        }
        
        //send notification to admin
        //event(new WithdrawalRequestNotification($withdReq));

        return $this->returnData('', trans("admin.added"));
    }

    /**
     * destroy a newly created resource in storage.
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $request = WithdrawalRequest::whereId($id)->where('delivery_id', auth()->guard('api')->user()->id)->first();
        if(is_null($request) || empty($request)){
            return $this->returnError('422', trans('auth.undefinedRecord'));
        }

        $request->delete();
        return $this->returnData('', trans("admin.deleted"));
    }

    /**
     * destroy a newly created resource in storage.
     * @return \Illuminate\Http\Response
     */
    public function destroyAll()
    {
        $requests = WithdrawalRequest::where('delivery_id', auth()->guard('api')->user()->id)->get();

        foreach($requests as $request) {
            $request->delete();
        }
        return $this->returnData('', trans("admin.deleted"));
    }

    private function getUniqueRefNumber()
    {
        $value = WithdrawalRequest::query()->selectRaw('FLOOR(10000 + RAND() * 10000) AS generatedCode')
            ->whereRaw("'generatedCode'  NOT IN (SELECT ref_no FROM withdrawal_requests WHERE withdrawal_requests.ref_no IS NOT NULL)")
            ->limit(1)->first();
        if ($value == null) return 10000;
        $value = (int)$value->generatedCode;
        return $value;
    }

}
