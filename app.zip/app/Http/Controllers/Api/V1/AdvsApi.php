<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Models\Adv;
use Validator;
use App\Http\Resources\Advs\AdvsResource;
use App\Traits\GeneralTrait;

class AdvsApi extends Controller
{
    use GeneralTrait;

    protected $selectColumns = [
        "id",
        "title_ar",
        "title_en",
        "title_urdu",
        "price",
        "cursor",
    ];

    /**
     * Display the specified releationshop.
     * @return array to assign with index & show methods
     */
    public function arrWith()
    {
        return [];
    }

    /**
     * Display a listing of the resource. Api
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $Adv = Adv::select($this->selectColumns)->with($this->arrWith())->orderBy("id", "desc")->get();
        //return successResponseJson(["data" => AdvsResource::collection($Adv)]);
        return $this->returnData(AdvsResource::collection($Adv), '');  //return json response
    }

}
