<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Models\City;
use App\Models\Area;
use Validator;
use App\Http\Resources\Cities\CitiesResource;
use App\Http\Resources\Cities\AreasResource;
use App\Traits\GeneralTrait;

class CitiesApi extends Controller
{
    use GeneralTrait;

    protected $selectColumns = [
        "id",
        "name_ar",
        "name_en",
        "name_urdu",
    ];

    /**
     * Display the specified releationshop.
     * @return array to assign with index & show methods
     */
    public function arrWith()
    {
        return [];
    }


    /**
     * Display a listing of the resource. Api
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $city = City::select($this->selectColumns)->with($this->arrWith())->orderBy("id", "desc")->get();
        return $this->returnData(CitiesResource::collection($city), '');  //return json response
    }

    public function areas(City $city)
    {
        $area = Area::where('city_id', $city->id)->orderBy("id", "desc")->get();
        return $this->returnData(AreasResource::collection($area), '');  //return json response
    }

}
