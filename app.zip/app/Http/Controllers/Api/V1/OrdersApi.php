<?php
namespace App\Http\Controllers\Api\V1;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\WalletTransaction;
use App\Models\Cart;
use App\Models\User;
use App\Models\Setting;
use App\Models\OrderStatus;
use App\Models\OrderItemStatusTime;
use App\Models\UserAddress;
use App\Events\OrderNotification;
use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\ValidationsApi\V1\OrdersRequest;
use App\Http\Resources\Orders\OrdersResource;
use App\Http\Resources\Orders\OrderDetailsResource;
use App\Http\Resources\Orders\OrderStatusesResource;
use App\Traits\GeneralTrait;
use App\Http\Controllers\Api\V1\OrderPaymentApi;
use App\Services\AutoAssignmentService;
use App\Events\SendDeliveryOtpEvent;
use DB;

class OrdersApi extends Controller
{
    use GeneralTrait;

	protected $selectColumns = [
	];

    /**
     * Display the specified releationshop.
     * @return array to assign with index & show methods
     */
    public function arrWith(){
        return [];
    }

    /**
     * Display a listing of the resource. Api
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(request()->has('status_id')) {
            if(request()->status_id==1) {
                $order = Order::with($this->arrWith())
                ->where('user_id', auth()->guard('api')->user()->id)
                ->whereIn('status_id', [1,2])
                ->orderBy("id","desc")->get();
            } elseif(request()->status_id==2) {
                $order = Order::with($this->arrWith())
                ->where('user_id', auth()->guard('api')->user()->id)
                ->where('status_id', 3)
                ->orderBy("id","desc")->get();
            }
        } else {
            $order = Order::with($this->arrWith())
            ->where('user_id', auth()->guard('api')->user()->id)
            ->orderBy("id","desc")->get();
        }

        return $this->returnData(OrdersResource::collection($order), '');
    }

    /**
     * Store a newly created resource in storage. Api
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
    	$data = $request->except("_token");

        $rules['branch_id'] = 'required|exists:users,id';
        $rules['address_id'] = 'required|exists:user_addresses,id';
        $rules['payment_method'] = 'required|in:visa,master,mada,apple_pay,wallet,bank';
        $rules['payment_status'] = 'required|in:totally_paid,partially_paid';

        if($request->payment_method=='visa' || $request->payment_method=='mada') {
            $rules['payment_amount'] = 'required';
            $rules['card_number'] = 'required';
            $rules['card_holder_name'] = 'required';
            $rules['expiry_month'] = 'required';
            $rules['expiry_year'] = 'required|int';
            $rules['cvv'] = 'required|int';
        }
        if($request->payment_method=='bank') {
            $rules['transfer_receipt'] = 'required|image';
        }

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }

        $user = User::find(auth()->guard('api')->user()->id);
        $setting = Setting::first();
        //DB::beginTransaction();

            $cart = Cart::where('user_id', auth()->guard('api')->user()->id)->first();
            $cart_items = Cart::where('user_id', auth()->guard('api')->user()->id)->get();

            if($cart_items->count()<1){
                return $this->returnError('422', trans('auth.cartEmpty'));
            }

            if(!in_array($request->branch_id, $cart->product->vendor->branches->pluck('id')->toArray())){
                return $this->returnError('422', trans('auth.invalidBrnch'));
            }

            $tax = (auth()->guard('api')->user()->cartTotal()+auth()->guard('api')->user()->cartDeliveryCost())*($setting->tax/100);

            $final_total = (auth()->user()->cartTotal()+$tax+auth()->user()->cartDeliveryCost());
            if(request()->payment_status=='totally_paid') {
                $payment_amount = $final_total;
            } else {
                $payment_amount = request()->payment_amount;
            }
            if($request->payment_method=='wallet' && $user->wallet_balance < $payment_amount) {
                return $this->returnError('422', trans('auth.notEnoughBalance'));
            }

            $order_address = UserAddress::whereId($request->address_id)->first();
            $address = $order_address->city->name_ar.', '.$order_address->area->name_ar.', '.$order_address->description;
            
            $ref_no = $this->getOrderUniqueRefNumber();
            
            if ($request->payment_method=='bank' && request()->hasFile('transfer_receipt')) {
                $data['transfer_receipt_1'] = it()->upload('transfer_receipt', 'orders');
            }
            $data['ref_no'] = $ref_no;
            $data['sub_total'] = auth()->user()->cartTotal();
            $data['tax'] = $tax;
            $data['delivery_cost'] = auth()->user()->cartDeliveryCost();
            $data['final_total'] = $final_total;
            $data['vendor_id'] = $cart->product->vendor_id;
            $data['branch_id'] = $request->branch_id;
            $data['address'] = $address;
            $data['city_id'] = $order_address->city_id;
            $data['area_id'] = $order_address->area_id;
            $data['district'] = $order_address->district;
            $data['street'] = $order_address->street;
            $data['latitude'] = $order_address->latitude;
            $data['longitude'] = $order_address->longitude;
            $data['recieve_date'] = $request->recieve_date ?? date('Y-m-d');

        $data['user_id'] = auth()->guard('api')->user()->id;
        $data['status_id'] = OrderStatus::first()->id;
        if(in_array($request->payment_method, ['bank', 'wallet', 'apple_pay'])) {
            if($request->payment_method=='bank') {
                $data['payment_status'] = 'pending';
            } else {
                $data['payed_amount'] = $final_total;
                $data['rest_amount'] = 0;
                $data['payment_status'] = 'totally_paid';
            }
            if($request->payment_method=='apple_pay') {
                $data['payment_id'] = $request->payment_id;
            }
        }

        $order = Order::create($data);
            foreach($cart_items as $item) {
                $item_ref_no = $this->getItemUniqueRefNumber();

                $order_item = OrderItem::create([
                    'ref_no' => $item_ref_no,
                    'order_id' => $order->id,
                    'product_id' => $item->product_id,
                    'vendor_id' => $item->product->vendor_id,
                    'price' => $item->product->price,
                    'discount' => $item->product->discount,
                    'quantity' => $item->quantity,
                    'total' => $item->quantity*$item->product->price,
                    'delivery_cost' => $item->delivery_cost,
                ]);
                OrderItemStatusTime::create([
                    'order_item_id' => $order_item->id,
                    'status_id' => 1,
                ]);
                $item->delete();
            }

            //send notification to admin and vendor
        //event(new OrderNotification($order));

        //conduct user wallet balance
        if($request->payment_method=='wallet') {
            $user->wallet_balance -= $payment_amount;
            $user->save();

            //Save wallet transaction
            WalletTransaction::create([
                'user_id' => $order->user_id,
                'type' => 'purchase',
                'amount' => $order->final_total,
                'payment_method' => $order->payment_method,
                'status' => 1,
            ]);
        }

        if(in_array($request->payment_method, ['bank', 'wallet', 'apple_pay'])) {
            return $this->returnData(new OrdersResource($order), trans("auth.order_added"));
        } else {
            $payment = new OrderPaymentApi();
            return $payment->executePayment($order);
        }

        //DB::commit();
    }

    /**
     * Display the specified resource.
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $order = Order::with($this->arrWith())->find($id);
        if(is_null($order) || empty($order)){
            return $this->returnError('422', trans('auth.undefinedRecord'));
        }
        return $this->returnData(new OrderDetailsResource($order), '');
    }

    public function completeOrderPayment(Request $request, $id)
    {
        $order = Order::with($this->arrWith())->find($id);
        if(is_null($order) || empty($order)){
            return $this->returnError('422', trans('auth.undefinedRecord'));
        }

    	$data = $request->except("_token");

        $rules['payment_method'] = 'required|in:visa,master,mada,apple_pay,wallet,bank';

        if($request->payment_method=='visa' || $request->payment_method=='mada') {
            $rules['payment_amount'] = 'required';
            $rules['card_number'] = 'required';
            $rules['card_holder_name'] = 'required';
            $rules['expiry_month'] = 'required';
            $rules['expiry_year'] = 'required|int';
            $rules['cvv'] = 'required|int';
        }
        if($request->payment_method=='bank') {
            $rules['transfer_receipt'] = 'required|image';
        }

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }

        $user = User::find(auth()->guard('api')->user()->id);

        if($request->payment_method=='wallet' && $user->wallet_balance < $order->rest_amount) {
            return $this->returnError('422', trans('auth.notEnoughBalance'));
        }

            //send notification to admin and vendor
        //event(new OrderNotification($order));

        //conduct user wallet balance
        if($request->payment_method=='wallet') {
            $user->wallet_balance -= $order->rest_amount;
            $user->save();

            //Save wallet transaction
            WalletTransaction::create([
                'user_id' => $order->user_id,
                'type' => 'purchase',
                'amount' => $order->rest_amount,
                'payment_method' => 'wallet',
                'status' => 1,
            ]);

            $order->payed_amount += $order->rest_amount;
            $order->rest_amount = 0;
            $order->payment_status = 'totally_paid';
            $order->save();
            
            //send otp to the user
            foreach($order->items as $item) {
                if($item->status_id==4) {
                    event(New SendDeliveryOtpEvent($item));
                }
            }
            
        } elseif($request->payment_method=='apple_pay') {
            $order->payed_amount += $order->rest_amount;
            $order->rest_amount = 0;
            $order->payment_status = 'totally_paid';
            $order->save();
            
            //send otp to the user
            foreach($order->items as $item) {
                if($item->status_id==4) {
                    event(New SendDeliveryOtpEvent($item));
                }
            }
        } elseif($request->payment_method=='bank') {
            $order->transfer_receipt_2 = it()->upload('transfer_receipt', 'orders');
            $order->save();
        }

        if(in_array($request->payment_method, ['wallet', 'apple_pay'])) {
            return $this->returnData(new OrderDetailsResource($order), trans("auth.order_paid"));
        } elseif($request->payment_method=='bank') {
            return $this->returnData(new OrderDetailsResource($order), trans("auth.pay_request_sent"));
        } else {
            $payment = new OrderPaymentApi();
            return $payment->completeOrderPayment($order);
        }

    }
    /**
     * update a newly created resource in storage.
     * @return \Illuminate\Http\Response
     */
    public function updateFillableColumns() {
                $fillableCols = [];
                foreach (array_keys((new OrdersRequest)->attributes()) as $fillableUpdate) {
                if (!is_null(request($fillableUpdate))) {
                    $fillableCols[$fillableUpdate] = request($fillableUpdate);
                }
                }
                return $fillableCols;
        }

    public function update(OrdersRequest $request,$id)
    {
        $order = Order::find($id);
        if(is_null($order) || empty($order)){
            return $this->returnError('422', trans('auth.undefinedRecord'));
        }

        $data = $this->updateFillableColumns();

        Order::where("id",$id)->update($data);

        $order = Order::with($this->arrWith())->find($id);
        return $this->returnData(new OrdersResource($order), trans("auth.updated"), '');
    }

    public function updateOrderStatus(Request $request,$id)
    {
        $order = Order::with($this->arrWith())->find($id);
        if(is_null($order) || empty($order)){
            return $this->returnError('422', trans('auth.undefinedRecord'));
        }
        if($order->delivery_id!=auth()->guard('api')->user()->id){
            return $this->returnError('422', trans('auth.notAllowed'));
        }
        if(in_array($order->status_id, [7,8])){
            return $this->returnError('422', trans('auth.notAllowed'));
        }
        $rules['status_id'] = 'required|exists:order_statuses,id';
        //$rules['address'] = 'required';
        $rules['latitude'] = 'required|numeric';
        $rules['longitude'] = 'required|numeric';

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }
        //Not allowed to update status step backward
        if($request->status_id<=$order->status_id){
            return $this->returnError('422', trans('auth.notAllowed'));
        }

        //Not allowed to update status more than one step forward
        if($request->status_id>($order->status_id+1) && $request->status_id!=8){
            return $this->returnError('422', trans('auth.notAllowed'));
        }

        $order->status_id = $request->status_id;
        $order->save();

        //Send delivery location
        $deliv = auth()->guard('api')->user();
        //$deliv->address = $request->address;
        $deliv->latitude = $request->latitude;
        $deliv->longitude = $request->longitude;
        $deliv->save();

        $autoAssignmentSerivce = new AutoAssignmentService();
        $autoAssignmentSerivce->sendNotification($order->user, 'auth.order_status_'.$request->status_id.'_title', 'auth.order_status_'.$request->status_id.'_details', 'order_status', $order->id, '');

        if($request->status_id==7 && $order->payment_method!='cash') {
            $deliv->wallet_balance += $order->order_total();
            $deliv->save();
            //Send notification to delivery that his wallet balance added
            $autoAssignmentSerivce->sendNotification($deliv, 'auth.balance_added_title', 'auth.balance_added_details', 'wallet_balance', $order->id, '' );
        }
        return $this->returnData(new OrdersResource($order), trans("auth.updated"));
    }

    /**
     * destroy a newly created resource in storage.
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $orders = Order::find($id);
        if(is_null($orders) || empty($orders)){
            return $this->returnError('422', trans('auth.undefinedRecord'));
        }


        it()->delete("order",$id);

        $orders->delete();
        return $this->returnData('', trans("auth.deleted"));
    }

    /**
     * Cancel order.
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function cancelOrder($id)
    {
        $order = Order::with($this->arrWith())->find($id);
        if(is_null($order) || empty($order)){
            return $this->returnError('422', trans('auth.undefinedRecord'));
        }
        if($order->user_id!=auth()->guard('api')->user()->id){
            return $this->returnError('422', trans('auth.notAllowed'));
        }
        if(in_array($order->status_id, [7])){
            return $this->returnError('422', trans('auth.notAllowed'));
        }
        if($order->delivery_id!=null){
            return $this->returnError('422', trans('auth.cancelNotAllowed'));
        }
        $order->status_id = 8;
        $order->save();

        return $this->returnSuccess(trans("auth.order_status_8_title"));
    }
    
    private function getOrderUniqueRefNumber()
    {
        $value = Order::query()->selectRaw('FLOOR(10000 + RAND() * 10000) AS generatedCode')
            ->whereRaw("'generatedCode'  NOT IN (SELECT ref_no FROM orders WHERE orders.ref_no IS NOT NULL)")
            ->limit(1)->first();
        if ($value == null) return 10000;
        $value = (int)$value->generatedCode;
        return $value;
    }
    
    private function getItemUniqueRefNumber()
    {
        $value = OrderItem::query()->selectRaw('FLOOR(10000 + RAND() * 10000) AS generatedCode')
            ->whereRaw("'generatedCode'  NOT IN (SELECT ref_no FROM order_items WHERE order_items.ref_no IS NOT NULL)")
            ->limit(1)->first();
        if ($value == null) return 10000;
        $value = (int)$value->generatedCode;
        return $value;
    }

}
