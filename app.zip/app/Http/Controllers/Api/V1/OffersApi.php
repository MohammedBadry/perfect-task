<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Models\Offer;
use Validator;
use App\Http\Resources\Offers\OffersResource;
use App\Traits\GeneralTrait;

class OffersApi extends Controller
{
    use GeneralTrait;

    protected $selectColumns = [
        "id",
        "product_id",
        "text_ar",
        "text_en",
        "text_urdu",
        "discount_percentage",
        "created_at",
        "updated_at",
    ];

    /**
     * Display the specified releationshop.
     * @return array to assign with index & show methods
     */
    public function arrWith()
    {
        return [];
    }

    /**
     * Display a listing of the resource. Api
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $offers = Offer::select($this->selectColumns)->with($this->arrWith())->orderBy("id", "desc")->get();
        //return successResponseJson(["data" => OffersResource::collection($offers)]);
        return $this->returnData(OffersResource::collection($offers), '');  //return json response
    }

}
