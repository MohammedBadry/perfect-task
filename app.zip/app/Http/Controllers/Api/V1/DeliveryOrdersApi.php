<?php
namespace App\Http\Controllers\Api\V1;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\WalletTransaction;
use App\Models\AutoAssignment;
use App\Models\Cart;
use App\Models\User;
use App\Models\Setting;
use App\Models\OrderStatus;
use App\Models\OrderItemStatusTime;
use App\Models\UserAddress;
use App\Events\OrderNotification;
use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\ValidationsApi\V1\OrdersRequest;
use App\Http\Resources\Orders\OrdersResource;
use App\Http\Resources\OrderItems\Delivery\DeliveryOrderItemsResource;
use App\Http\Resources\OrderItems\Delivery\DeliveryOrderItemDetailsResource;
use App\Http\Resources\Orders\OrderDetailsResource;
use App\Traits\GeneralTrait;
use App\Http\Controllers\Api\V1\OrderPaymentApi;
use App\Services\AutoAssignmentService;
use App\Events\SendDeliveryOtpEvent;
use DB;

class DeliveryOrdersApi extends Controller
{
    use GeneralTrait;

	protected $selectColumns = [
	];

    /**
     * Display the specified releationshop.
     * @return array to assign with index & show methods
     */
    public function arrWith(){
        return [];
    }

    /**
     * Display a listing of the resource. Api
     * @return \Illuminate\Http\Response
     */

    public function index(Request $request)
    {
        $rules = [
			'status_id' => 'required|in:1,2,3',
        ];
        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }
        if(request()->status_id==1) {
            $new = AutoAssignment::where(['delivery_id'=> auth()->guard('api')->user()->id, 'status' => 'pending'])->pluck('order_item_id');
            $order = OrderItem::with($this->arrWith())
            ->whereIn('order_id', function($query) {
                $query->select('id')->from('orders')->where('status_id', 2);
            })
        ->where('status_id', 1)
            ->whereIn('id', $new)
            ->orderBy("id","desc")->get();
        } elseif(request()->status_id==2) {
            $order = OrderItem::with($this->arrWith())
            ->whereIn('order_id', function($query) {
                $query->select('id')->from('orders')->where('status_id', 2);
            })
            ->whereIn('status_id', [2,3,4])
            ->orderBy("id","desc")->get();
        } elseif(request()->status_id==3) {
            $order = OrderItem::with($this->arrWith())
            ->whereIn('order_id', function($query) {
                $query->select('id')->from('orders')->where('status_id', 3);
            })
            ->where('status_id', 5)
            ->orderBy("id","desc")->get();
        }

        return $this->returnData(DeliveryOrderItemsResource::collection($order), '');
    }

    public function acceptOrderItem(Request $request, $id)
    {
        $orderItem = OrderItem::with($this->arrWith())->find($id);
        if(is_null($orderItem) || empty($orderItem)){
            return $this->returnError('422', trans('auth.undefinedRecord'));
        }

        //Check if the delivery should be assigned to the order
        $assigned = AutoAssignment::where(['order_item_id' => $id, 'delivery_id'=> auth()->guard('api')->user()->id, 'status' => 'pending'])->first();
        if(!$assigned || $orderItem->delivery_id!=''){
            return $this->returnError('422', trans('auth.notAllowed'));
        }

        $orderItem->delivery_id = auth()->guard('api')->user()->id;
        $orderItem->status_id = 2;
        $orderItem->save();

        $assigned->status = 'accepted';
        $assigned->save();

        OrderItemStatusTime::create([
            'order_item_id' => $id,
            'status_id' => 2,
        ]);

        //send notification to branch when delivery accepts the order
        $autoAssignmentSerivce = new AutoAssignmentService();
        $autoAssignmentSerivce->sendNotification($orderItem->order->branch, 
        'auth.order_accepted_title_part1'.$orderItem->id.'auth.order_accepted_title_part2'.$orderItem->delivery->name, 
        'auth.order_accepted_title_part1'.$orderItem->id.'auth.order_accepted_title_part2'.$orderItem->delivery->name, 
        'delivery_order_acceptance', 
        $orderItem->order->id, '');

        return $this->returnData(new OrdersResource($orderItem->order), trans("auth.order_accepted"));
    }

    /**
     * Display the specified resource.
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $order = OrderItem::with($this->arrWith())->find($id);
        if(is_null($order) || empty($order)){
            return $this->returnError('422', trans('auth.undefinedRecord'));
        }
        return $this->returnData(new DeliveryOrderItemDetailsResource($order), '');
    }

    public function updateOrderItemStatus(Request $request,$id)
    {
        $orderitem = OrderItem::with($this->arrWith())->find($id);
        if(is_null($orderitem) || empty($orderitem)){
            return $this->returnError('422', trans('auth.undefinedRecord'));
        }
        if($orderitem->delivery_id!=auth()->guard('api')->user()->id){
            return $this->returnError('422', trans('auth.notAllowed'));
        }
        //if the main order completed || canceled || order item delivered || status step backward
        if(in_array($orderitem->order->status_id, [3,4]) || $orderitem->status_id==5 || $request->status_id<=$orderitem->status_id){
            return $this->returnError('422', trans('auth.notAllowed'));
        }
        $rules['status_id'] = 'required|exists:order_items_statuses,id';
        if($request->status_id==5) {
            $rules['otp_code'] = 'required|int';
        }

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }

        if($request->status_id==5 && $orderitem->order->payment_status!='totally_paid') {
            return $this->returnError('422', trans('auth.orderNotPaidYet'));
        }

        if($request->status_id==4 && $orderitem->order->payment_status=='totally_paid') {
            //send otp to the user
            event(New SendDeliveryOtpEvent($orderitem));
        }
		if ($request->status_id==5 && $orderitem->otp_code!=$request->otp_code) {
            return $this->returnError('422', trans('auth.invaliOtp'));
		}

        $orderitem->status_id = $request->status_id;
        if($request->status_id==5) {
            $orderitem->otp_code = '';
        }
        $orderitem->save();

        OrderItemStatusTime::create([
            'order_item_id' => $id,
            'status_id' => $request->status_id,
        ]);

        //send notification to user and branch
        $autoAssignmentSerivce = new AutoAssignmentService();
        $autoAssignmentSerivce->sendNotification($orderitem->order->user, 'auth.order_status_'.$request->status_id.'_title', 'auth.order_status_'.$request->status_id.'_details', 'order_status', $orderitem->id, '');

        $autoAssignmentSerivce = new AutoAssignmentService();
        $autoAssignmentSerivce->sendNotification($orderitem->order->branch, 'auth.order_status_'.$request->status_id.'_title', 'auth.order_status_'.$request->status_id.'_details', 'order_status', $orderitem->id, '');
        
        if($request->status_id==5) {
            $deliv = auth()->guard('api')->user();
            $deliv->wallet_balance += $orderitem->delivery_cost;
            $deliv->save();

            //Update main order status to be completed if this item the last to be delivered
            $order_items_count = OrderItem::where('order_id', $orderitem->order_id)
                ->where('id', '!=', $id)
                ->where('status_id', '!=', 5)
                ->get()
                ->count();
            if($order_items_count<1) {
                $orderitem->order->status_id=3;            
                $orderitem->order->save();
            }
            //Send notification to delivery that his wallet balance added
            $autoAssignmentSerivce->sendNotification($deliv, 'auth.balance_added_title', 'auth.balance_added_details', 'wallet_balance', $orderitem->id, '' );
        }
        return $this->returnData(new DeliveryOrderItemDetailsResource($orderitem), trans("auth.updated"));
    }

}
