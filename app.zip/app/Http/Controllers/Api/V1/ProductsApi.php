<?php
namespace App\Http\Controllers\Api\V1;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Models\Product;
use App\Models\ProductRating;
use Validator;
use App\Http\Controllers\ValidationsApi\V1\ProductsRequest;
use App\Http\Resources\Products\ProductsResource;
use App\Http\Resources\Products\ProductDetailsResource;
use App\Traits\GeneralTrait;

class ProductsApi extends Controller
{
    use GeneralTrait;

    protected $selectColumns = [
        "id",
        "name_ar",
        "name_en",
        "description_ar",
        "description_en",
        "price",
        "preparing_time",
        "discount",
        "vendor_id",
        "image",
        "category_id",
    ];

    /**
     * Display the specified releationshop.
     * @return array to assign with index & show methods
     */
    public function arrWith(){
        return ['category'];
    }


    /**
     * Display a listing of the resource. Api
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $Product = Product::select($this->selectColumns)->with($this->arrWith())->orderBy("id","desc")->get();
        return $this->returnData(ProductsResource::collection($Product), '');  //return json response
    }

    public function vendorProducts($id, Request $request)
    {
        $category_id = $request->category_id;

        $Product = Product::select($this->selectColumns)
        ->with($this->arrWith())
        ->where('vendor_id', $id)
        ->when($category_id, function ($q) use ($category_id) {
            return $q->where('category_id', $category_id);
        })
        ->orderBy("id","desc")->get();
        return $this->returnData(ProductsResource::collection($Product), '');  //return json response
    }

    /**
     * Display the specified resource.
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $Product = Product::with($this->arrWith())->find($id,$this->selectColumns);
        if(is_null($Product) || empty($Product)){
            return $this->returnError('422', trans("auth.undefinedRecord"));
        }

        return $this->returnData(new ProductDetailsResource($Product), '');  //return json response
    }

    public function rateProduct(Request $request, $id)
    {
        $Product = Product::with($this->arrWith())->find($id,$this->selectColumns);
        if(is_null($Product) || empty($Product)){
            return $this->returnError('422', trans("auth.undefinedRecord"));
        }
        $rules['rating'] = 'required|integer';

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }


        $rating_exists = ProductRating::where([
            'user_id' => auth()->guard('api')->user()->id,
            'product_id' => $id,
        ])
        ->first();
        if(!$rating_exists) {
            ProductRating::create([
                'user_id' => auth()->guard('api')->user()->id,
                'product_id' => $id,
                'rating' => $request->rating
            ]);
        } else {
            $rating_exists->update(['rating' => $request->rating]);
        }
        return $this->returnData('', trans("auth.added"));
    }
}
