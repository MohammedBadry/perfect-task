<?php
namespace App\Http\Controllers\Validations;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class AdvsRequest extends FormRequest {

	/**

	 * Determine if the user is authorized to make this request.
	 *
	 * @return bool
	 */
	public function authorize() {
		return true;
	}

	/**

	 * Get the validation rules that apply to the request.
	 *
	 * @return array (onCreate,onUpdate,rules) methods
	 */
	protected function onCreate() {
		return [
			'title_ar'=>'required|string',
			'title_en'=>'required|string',
			'title_urdu'=>'required|string',
			'price'=>'required|integer',
			'cursor'=>'sometimes|nullable',
		];
	}

	protected function onUpdate() {
		return [
			'title_ar'=>'required|string',
			'title_en'=>'required|string',
			'title_urdu'=>'required|string',
			'price'=>'required|integer',
			'cursor'=>'sometimes|nullable',
		];
	}

	public function rules() {
		return request()->isMethod('put') || request()->isMethod('patch') ?
		$this->onUpdate() : $this->onCreate();
	}


	/**

	 * Get the validation attributes that apply to the request.
	 *
	 * @return array
	 */
	public function attributes() {
		return [
			'title_ar'=>trans('admin.title_ar'),
			'title_en'=>trans('admin.title_en'),
			'title_urdu'=>trans('admin.title_urdu'),
			'price'=>trans('admin.price'),
			'cursor'=>trans('admin.cursor'),
		];
	}

	/**

	 * response redirect if fails or failed request
	 *
	 * @return redirect
	 */
	public function response(array $errors) {
		return $this->ajax() || $this->wantsJson() ?
		response([
			'status' => false,
			'StatusCode' => 422,
			'StatusType' => 'Unprocessable',
			'errors' => $errors,
		], 422) :
		back()->withErrors($errors)->withInput(); // Redirect back
	}



}
