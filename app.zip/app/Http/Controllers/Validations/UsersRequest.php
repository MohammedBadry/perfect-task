<?php
namespace App\Http\Controllers\Validations;

use Illuminate\Foundation\Http\FormRequest;

class UsersRequest extends FormRequest {

	/**
	 * 
	 * Determine if the user is authorized to make this request.
	 *
	 * @return bool
	 */
	public function authorize() {
		return true;
	}

	/**
	 * 
	 * Get the validation rules that apply to the request.
	 *
	 * @return array (onCreate,onUpdate,rules) methods
	 */
	protected function onCreate() {
		return [
			'name' => 'required|string|max:100',
			'email' => 'required|email|unique:users',
			'mobile' => 'required|regex:/[0-9]{8}/|unique:users',
			'photo_profile' => '' . it()->image() . '|nullable|sometimes',
			'password' => 'required|confirmed|max:255|min:6',
		];
	}

	protected function onUpdate() {
		return [
			'name' => "required|string|max:100",
			'email' => 'required|email|unique:users,email,' . request()->segment(3),
			'mobile' => 'required|regex:/[0-9]{8}/|unique:users,mobile,' . request()->segment(3),
			'photo_profile' => '' . it()->image() . '|nullable|sometimes',
			'password' => 'sometimes|nullable|max:255|min:6',
			'partial_payment' => 'nullable|int',
			'status' => 'required',
		];
	}

	public function rules() {
		return request()->isMethod('put') || request()->isMethod('patch') ?
		$this->onUpdate() : $this->onCreate();
	}

	/**
	 * 
	 * Get the validation attributes that apply to the request.
	 *
	 * @return array
	 */
	public function attributes() {
		return [
			'name' => trans('admin.name'),
			'mobile' => trans('admin.mobile'),
			'email' => trans('admin.email'),
			'photo_profile' => trans('admin.photo_profile'),
			'password' => trans('admin.password'),
			'partial_payment' => trans('admin.partial_payment'),
			'status' => trans('admin.status'),
		];
	}

	/**
	 * 
	 * response redirect if fails or failed request
	 *
	 * @return redirect
	 */
	public function response(array $errors) {
		return $this->ajax() || $this->wantsJson() ?
		response([
			'status' => false,
			'StatusCode' => 422,
			'StatusType' => 'Unprocessable',
			'errors' => $errors,
		], 422) :
		back()->withErrors($errors)->withInput(); // Redirect back
	}

}