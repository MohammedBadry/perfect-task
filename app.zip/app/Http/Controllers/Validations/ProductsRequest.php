<?php
namespace App\Http\Controllers\Validations;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class ProductsRequest extends FormRequest {

	/**
	 * 
	 * Determine if the user is authorized to make this request.
	 *
	 * @return bool
	 */
	public function authorize() {
		return true;
	}

	/**
	 * 
	 * Get the validation rules that apply to the request.
	 *
	 * @return array (onCreate,onUpdate,rules) methods
	 */
	protected function onCreate() {
		return [
            'name_ar'=>'required',
            'name_en'=>'required',
            'name_urdu'=>'sometimes|nullable',
            'description_ar'=>'required',
            'description_en'=>'required',
            'description_urdu'=>'sometimes|nullable',
            'unit_id'=>'required|exists:units,id',
            'price' => 'required|numeric|gt:0',
            'vendor_id'=>'required|exists:admins,id',
            'category_id'=>'required|exists:categories,id',
            'minimum_order'=>'required',
            'preparing_time'=>'required',
            'image'=>'required|image',	
		];
	}

	protected function onUpdate() {
		return [
            'name_ar'=>'required',
            'name_en'=>'required',
            'name_urdu'=>'sometimes|nullable',
            'description_ar'=>'required',
            'description_en'=>'required',
            'description_urdu'=>'sometimes|nullable',
            'unit_id'=>'required|exists:units,id',
            'price' => 'required|numeric|gt:0',
            'vendor_id'=>'required|exists:admins,id',
            'category_id'=>'required|exists:categories,id',
            'minimum_order'=>'required',
            'preparing_time'=>'required',
            'image'=>'nullable|image',
		];
	}

	public function rules() {
		return request()->isMethod('put') || request()->isMethod('patch') ?
		$this->onUpdate() : $this->onCreate();
	}


	/**
	 * 
	 * Get the validation attributes that apply to the request.
	 *
	 * @return array
	 */
	public function attributes() {
		return [
             'name_ar'=>trans('admin.name_ar'),
             'name_en'=>trans('admin.name_en'),
             'name_urdu'=>trans('admin.name_urdu'),
             'description_ar'=>trans('admin.name_ar'),
             'description_en'=>trans('admin.name_en'),
             'description_urdu'=>trans('admin.description_urdu'),
             'unit_id'=>trans('admin.unit_id'),
             'price'=>trans('admin.price'),
             'vendor_id'=>trans('admin.vendor_id'),
             'category_id'=>trans('admin.category_id'),
             'vendor_id'=>trans('admin.vendor_id'),
             'minimum_order'=>trans('admin.minimum_order'),
             'preparing_time'=>trans('admin.preparing_time'),
             'image'=>trans('admin.image'), 
		];
	}

	/**
	 * 
	 * response redirect if fails or failed request
	 *
	 * @return redirect
	 */
	public function response(array $errors) {
		return $this->ajax() || $this->wantsJson() ?
		response([
			'status' => false,
			'StatusCode' => 422,
			'StatusType' => 'Unprocessable',
			'errors' => $errors,
		], 422) :
		back()->withErrors($errors)->withInput(); // Redirect back
	}



}