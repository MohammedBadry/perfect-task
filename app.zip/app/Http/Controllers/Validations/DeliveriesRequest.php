<?php
namespace App\Http\Controllers\Validations;

use Illuminate\Foundation\Http\FormRequest;

class DeliveriesRequest extends FormRequest {

	/**
	 * 
	 * Determine if the user is authorized to make this request.
	 *
	 * @return bool
	 */
	public function authorize() {
		return true;
	}

	/**
	 * 
	 * Get the validation rules that apply to the request.
	 *
	 * @return array (onCreate,onUpdate,rules) methods
	 */
	protected function onCreate() {
		return [
			'name' => 'required|string',
			'mobile' => 'required|regex:/[0-9]{8}/|unique:admins',
			'photo_profile' => '' . it()->image() . '|nullable|sometimes',
			'password' => 'required|confirmed|max:255|min:6',
		];
	}

	protected function onUpdate() {
		return [
			'name' => 'required|string',
			'mobile' => 'required|regex:/[0-9]{8}/|unique:admins,mobile,' . request()->segment(3),
			'national_id' => 'required',
			'car_id' => 'required|exists:cars,id',
			'plate_number' => 'required',
			'car_color' => 'required',
			'password' => 'sometimes|nullable|max:255|min:6',
			'photo_profile' => '' . it()->image() . '|nullable|sometimes',
			'status' => 'required',
			'approved' => 'required',
		];
	}

	public function rules() {
		return request()->isMethod('put') || request()->isMethod('patch') ?
		$this->onUpdate() : $this->onCreate();
	}

	/**
	 * 
	 * Get the validation attributes that apply to the request.
	 *
	 * @return array
	 */
	public function attributes() {
		return [
			'name' => trans('admin.name'),
			'mobile' => trans('admin.mobile'),
			'national_id' => trans('admin.national_id'),
			'car_id' => trans('admin.car_id'),
			'plate_number' => trans('admin.plate_number'),
			'car_color' => trans('admin.car_color'),
			'password' => trans('admin.password'),
			'photo_profile' => trans('admin.photo_profile'),
			'status' => trans('admin.status'),
			'approved' => trans('admin.approved_status'),
		];
	}

	/**
	 * 
	 * response redirect if fails or failed request
	 *
	 * @return redirect
	 */
	public function response(array $errors) {
		return $this->ajax() || $this->wantsJson() ?
		response([
			'status' => false,
			'StatusCode' => 422,
			'StatusType' => 'Unprocessable',
			'errors' => $errors,
		], 422) :
		back()->withErrors($errors)->withInput(); // Redirect back
	}

}