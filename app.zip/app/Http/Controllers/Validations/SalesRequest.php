<?php
namespace App\Http\Controllers\Validations;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class SalesRequest extends FormRequest {

	/**
	 * 
	 * Determine if the user is authorized to make this request.
	 *
	 * @return bool
	 */
	public function authorize() {
		return true;
	}

	/**
	 * 
	 * Get the validation rules that apply to the request.
	 *
	 * @return array (onCreate,onUpdate,rules) methods
	 */
	protected function onCreate() {
		return [
            'user_id'=>'required|exists:users,id',
            'tax_value' => 'nullable',
            'product_id'=>'required',
            'product_id.*'=>'exists:products,id',
            'price' => 'required',
            'price.*' => 'numeric|gt:0',
            'quantity'=>'required',
            'quantity.*'=>'int|gt:0',
		];
	}

	protected function onUpdate() {
		return [
		];
	}

	public function rules() {
		return request()->isMethod('put') || request()->isMethod('patch') ?
		$this->onUpdate() : $this->onCreate();
	}


	/**
	 * 
	 * Get the validation attributes that apply to the request.
	 *
	 * @return array
	 */
	public function attributes() {
		return [
			'user_id'=>trans('admin.user_id'),
			'tax_value'=>trans('admin.tax_value'),
			'product_id'=>trans('admin.product_id'),
			'price'=>trans('admin.price'),
			'quantity'=>trans('admin.quantity'),
		];
	}

	/**
	 * 
	 * response redirect if fails or failed request
	 *
	 * @return redirect
	 */
	public function response(array $errors) {
		return $this->ajax() || $this->wantsJson() ?
		response([
			'status' => false,
			'StatusCode' => 422,
			'StatusType' => 'Unprocessable',
			'errors' => $errors,
		], 422) :
		back()->withErrors($errors)->withInput(); // Redirect back
	}



}