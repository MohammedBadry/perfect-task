<?php
namespace App\Http\Controllers\Validations;

use Illuminate\Foundation\Http\FormRequest;

class BranchesRequest extends FormRequest {

	/**
	 *
	 * Determine if the user is authorized to make this request.
	 *
	 * @return bool
	 */
	public function authorize() {
		return true;
	}

	/**
	 *
	 * Get the validation rules that apply to the request.
	 *
	 * @return array (onCreate,onUpdate,rules) methods
	 */
	protected function onCreate() {
		return [
		    'city_id' => 'required|exists:cities,id',
			'name' => 'required|string',
			//'email' => 'required|email|unique:users',
			'address' => 'required|max:100',
			'latitude' => 'required',
			'longitude' => 'required',
			'mobile' => 'required|regex:/[0-9]{8}/|unique:users',
			'password' => 'required|max:255|min:6',
			'vendor_id' => 'required|exists:admins,id',
		];
	}

	protected function onUpdate() {
		return [
		    'city_id' => 'required|exists:cities,id',
			'name' => 'required|string',
			//'email' => 'required|email|unique:users,email,' . request()->segment(3),
			'address' => 'required|max:100',
			'latitude' => 'required',
			'longitude' => 'required',
			'mobile' => 'required|regex:/[0-9]{8}/|unique:users,mobile,' . request()->segment(3),
			'password' => 'sometimes|nullable|max:255|min:6',
		];
	}

	public function rules() {
		return request()->isMethod('put') || request()->isMethod('patch') ?
		$this->onUpdate() : $this->onCreate();
	}

	/**
	 *
	 * Get the validation attributes that apply to the request.
	 *
	 * @return array
	 */
	public function attributes() {
		return [
			'name' => trans('admin.name'),
			'email' => trans('admin.email'),
			'mobile' => trans('admin.mobile'),
			'photo_profile' => trans('admin.photo_profile'),
			'password' => trans('admin.password'),
			'category_id' => trans('admin.category_id'),
			'about_company' => trans('admin.about_company'),
			'Commercial_registration_type' => trans('admin.Commercial_registration_type'),
			'year_founded' => trans('admin.year_founded'),
			'employees_number' => trans('admin.employees_number'),
			'address' => trans('admin.address'),
			'latitude' => trans('admin.latitude'),
			'longitude' => trans('admin.longitude'),
		];
	}

	/**
	 *
	 * response redirect if fails or failed request
	 *
	 * @return redirect
	 */
	public function response(array $errors) {
		return $this->ajax() || $this->wantsJson() ?
		response([
			'status' => false,
			'StatusCode' => 422,
			'StatusType' => 'Unprocessable',
			'errors' => $errors,
		], 422) :
		back()->withErrors($errors)->withInput(); // Redirect back
	}

}
