<?php

namespace App\Http\Resources\Products;

use Illuminate\Http\Resources\Json\JsonResource;
use App\Http\Resources\Vendors\ProductVendorsResource;

class ProductsResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        if(request()->has('lang') && request()->lang=='en') {
            $name = $this->name_en;
            $desctiption = $this->description_en;
        } elseif(request()->lang=='urdu') {
            $name = $this->name_urdu;
            $desctiption = $this->description_urdu;
        } else {
            $name = $this->name_ar;
            $desctiption = $this->description_ar;
        }
        if(auth()->guard('api')->user()) {
            if(auth()->guard('api')->user()->type=='user') {
                $user_cart = auth()->guard('api')->user()->cart->where('product_id', $this->id)->first();
                $user_favourites = auth()->guard('api')->user()->favourite_products->pluck('target_id')->toArray();
                if($user_cart) {
                    $added_to_cart = 1;
                    $quantity_cart = $user_cart->quantity;
                } else {
                    $added_to_cart = 0;
                    $quantity_cart = 0;
                }
                if(in_array($this->id,$user_favourites)) {
                    $added_to_favourites = 1;
                } else {
                    $added_to_favourites = 0;
                }
                $p_rating = \App\Models\ProductRating::where(['user_id' => auth()->guard('api')->user()->id, 'product_id' => $this->id])->first();
                if($p_rating) {
                    $my_rating = $p_rating->rating;
                } else {
                    $my_rating = '';
                }
            } else {
                $my_rating = '';
                $added_to_cart = '';
                $quantity_cart = '';
                $added_to_favourites = '';
            }
        } else {
            $my_rating = '';
            $added_to_cart = '';
            $quantity_cart = '';
            $added_to_favourites = '';
    }
    $image = $this->images[0]->image??'';
        return [
            'id' => $this->id,
            'name' => $name,
            'desctiption' => $desctiption,
            'price' => $this->price,
            //'discount' => $this->discount,
            'vendor' => new ProductVendorsResource($this->vendor),
			'image' => it()->url($image),
            'features' => ProductFeaturesResource::collection($this->features),
            'added_to_cart' => $added_to_cart,
            'quantity_cart' => $quantity_cart,
            'added_to_favourites' => $added_to_favourites,
            //'my_rating' => $my_rating,
            //'total_rating' => $this->total_ratings(),
        ];
    }
}
