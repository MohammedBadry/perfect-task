<?php

namespace App\Http\Resources\Offers;

use Illuminate\Http\Resources\Json\JsonResource;
use App\Http\Resources\Products\ProductsResource;

class OffersResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {

        if(request()->has('lang') && request()->lang=='en') {
            $title = "Discounts";
            $text = $this->text_en;
        } elseif(request()->lang=='urdu') {
            $title = "چھوٹ";
            $text = $this->text_urdu;
        } else {
            $title = "تخفيضات";
            $text = $this->text_ar;
        }
        return [
            'id' => $this->id,
            'product' => new ProductsResource($this->product),
            'title' => $title,
            'text' => $text,
            'discount_percentage' => $this->discount_percentage,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ];
    }
}
