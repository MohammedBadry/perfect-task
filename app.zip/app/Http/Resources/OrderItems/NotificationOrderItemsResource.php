<?php

namespace App\Http\Resources\OrderItems;

use Illuminate\Http\Resources\Json\JsonResource;
use App\Http\Resources\Products\NotificationProductsResource;
use App\Http\Resources\Deliveries\DeliveriesResource;

class NotificationOrderItemsResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'product_id' => new NotificationProductsResource($this->product),
            'quantity' => $this->quantity,
            'total' => $this->total,
            'delivery' => new DeliveriesResource($this->delivery),
            'status' => $this->status
        ];
    }
}
