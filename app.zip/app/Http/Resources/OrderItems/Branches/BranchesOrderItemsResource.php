<?php

namespace App\Http\Resources\OrderItems\Branches;

use Illuminate\Http\Resources\Json\JsonResource;
use App\Http\Resources\Products\Branches\BranchesProductsResource;
use App\Http\Resources\Orders\OrderItemsStatusesTimesResource;
use App\Http\Resources\Deliveries\BranchesDeliveriesResource;

class BranchesOrderItemsResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        $statuses = \App\Models\OrderItemStatus::orderBy("id","asc")->get();

        $statuses = OrderItemsStatusesTimesResource::collection($statuses);
        $statuses->map(function($i) { 
            $i->item_id = $this->id; 
        });
     
        if(request()->lang=='en') {
            $hour = "Hours";
        } elseif(request()->lang=='urdu') {
            $hour = "گھنٹے";
        } else {
            $hour = "ساعة";
        }
        
        return [
            'id' => $this->id,
            'ref_no' => $this->ref_no,
            'product' => new BranchesProductsResource($this->product),
            'delivery' => new BranchesDeliveriesResource($this->delivery),
            'quantity' => $this->quantity,
            'total' => $this->total,
            'delivery_cost' => $this->delivery_cost,
            'preparing_time' => $this->product->preparing_time." ".$hour,
            'statuses' => $statuses,
        ];
    }
}
