<?php

namespace App\Http\Resources\OrderItems\Delivery;

use Illuminate\Http\Resources\Json\JsonResource;

class FromLocationResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        
        return [
            'address' => $this->branch->address,
            'latitude' => $this->branch->latitude,
            'longitude' => $this->branch->longitude,
        ];
    }
}
