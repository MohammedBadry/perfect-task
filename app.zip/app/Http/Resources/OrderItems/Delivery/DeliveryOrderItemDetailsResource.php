<?php

namespace App\Http\Resources\OrderItems\Delivery;

use Illuminate\Http\Resources\Json\JsonResource;
use App\Http\Resources\Products\Delivery\DeliveryProductsResource;
use App\Http\Resources\Deliveries\DeliveriesResource;
use App\Http\Resources\Orders\OrderItemsStatusesResource;
use App\Http\Resources\Orders\OrderItemsStatusesTimesResource;

class DeliveryOrderItemDetailsResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        if(request()->has('lang') && request()->lang=='en') {
            $unit_name = $this->product->unit->name_en;
        } elseif(request()->lang=='urdu') {
            $unit_name = $this->product->unit->name_urdu;
        } else {
            $unit_name = $this->product->unit->name_ar;
        }
        $statuses = \App\Models\OrderItemStatus::where('id', '!=', 1)->orderBy("id","asc")->get();

        $statuses = OrderItemsStatusesTimesResource::collection($statuses);
        $statuses->map(function($i) { 
            $i->item_id = $this->id; 
        });
        
        return [
            'id' => $this->id,
            'ref_no' => $this->ref_no,
            'statuses' => $statuses,
            'recieve_date' => $this->order->recieve_date,
            //'from' => new FromLocationResource($this->order),
            'product' => new DeliveryProductsResource($this->product),
            'quantity' => $this->quantity. ' '.$unit_name,
            'created_at' => $this->order->created_at,
            'recieve_date' => $this->order->recieve_date,
            'user_name' => $this->order->user->name,
            'user_mobile' => $this->order->user->user_mobile,
            'to' => new ToLocationResource($this->order),
            'delivery_cost' => $this->delivery_cost
        ];
    }
}
