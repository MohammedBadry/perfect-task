<?php

namespace App\Http\Resources\OrderItems;

use Illuminate\Http\Resources\Json\JsonResource;
use App\Http\Resources\Products\ProductsResource;
use App\Http\Resources\Deliveries\DeliveriesResource;
use App\Http\Resources\Orders\OrderItemsStatusesResource;
use App\Http\Resources\Orders\OrderItemsStatusesTimesResource;

class OrderItemsResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        $statuses = \App\Models\OrderItemStatus::orderBy("id","asc")->get();

        $statuses = OrderItemsStatusesTimesResource::collection($statuses);
        $statuses->map(function($i) { 
            $i->item_id = $this->id; 
        });
        
        return [
            'id' => $this->id,
            'ref_no' => $this->ref_no,
            'product' => new ProductsResource($this->product),
            'quantity' => $this->quantity,
            'total' => $this->total,
            'delivery' => new DeliveriesResource($this->delivery),
            'statuses' => $statuses
        ];
    }
}
