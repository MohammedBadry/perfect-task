<?php

namespace App\Http\Resources\OrderItems;

use Illuminate\Http\Resources\Json\JsonResource;
use App\Http\Resources\Products\DeliveryProductsResource;
use App\Http\Resources\Deliveries\DeliveriesResource;

class DeliveryOrderItemsResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'ref_no' => $this->ref_no,
            'product' => new DeliveryProductsResource($this->product),
            'quantity' => $this->quantity,
            'total' => $this->total,
            'delivery' => new DeliveriesResource($this->delivery),
            'status' => $this->status
        ];
    }
}
