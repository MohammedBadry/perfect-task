<?php

namespace App\Http\Resources\Categories;

use Illuminate\Http\Resources\Json\JsonResource;

class CategoriesResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        if(request()->has('lang') && request()->lang=='en') {
            $name = $this->name_en;
        } elseif(request()->lang=='urdu') {
            $name = $this->name_urdu;
        } else {
            $name = $this->name_ar;
        }
        $main_cat = $this->subcategories->pluck('id')->toArray();
        $Category_vendors = \App\Models\VendorCategory::where('category_id', $this->id)->get()->count();
        if($Category_vendors) {
            $has_vendors = 1;
        } else {
            $has_vendors = 0;
        }
        return [
            'id' => $this->id,
            'name' => $name,
            'image' => it()->url($this->image),
            'has_vendors' => $has_vendors
        ];
    }
}
