<?php

namespace App\Http\Resources\Cities;

use Illuminate\Http\Resources\Json\JsonResource;

class AreasResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        if(request()->has('lang') && request()->lang=='en') {
            $name = $this->name_en;
        } elseif(request()->lang=='urdu') {
            $name = $this->name_urdu;
        } else {
            $name = $this->name_ar;
        }
        return [
            'id' => $this->id,
            'name' => $name,
        ];
    }
}
