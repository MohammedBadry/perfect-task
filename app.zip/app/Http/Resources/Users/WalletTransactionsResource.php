<?php

namespace App\Http\Resources\Users;

use Illuminate\Http\Resources\Json\JsonResource;
use App\Http\Resources\Countries\CountriesResource;

class WalletTransactionsResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        if($this->type=='charge') {
            $cursor = 0;
        } else {
            $cursor = 1;
        }
        return [
            'id' => $this->id,
            'type' => $this->type,
            'amount' => $this->amount,
            'payment_method' => $this->payment_method,
            'cursor' => $cursor,
            'created_at' => $this->created_at,
        ];
    }
}
