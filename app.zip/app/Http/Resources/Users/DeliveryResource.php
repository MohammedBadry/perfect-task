<?php

namespace App\Http\Resources\Users;

use Illuminate\Http\Resources\Json\JsonResource;
use App\Http\Resources\Vendors\DeliveryVendorsResource;
use App\Http\Resources\UserAddresses\Delivery\UserAddressResource;

class DeliveryResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        if(request()->has('lang') && request()->lang=='en') {
            $car_type = $this->car->name_en;
        } elseif(request()->lang=='urdu') {
            $car_type = $this->car->name_urdu;
        } else {
            $car_type = $this->car->name_ar;
        }

        $delivery_vendors = \App\Models\BranchDelivery::select('delivery_id', 'vendor_id')->where('delivery_id', $this->id)->groupBy('vendor_id')->pluck('vendor_id');
        $delivery_vendors = \App\Models\Admin::whereIn('id', $delivery_vendors)->get();
        return [
            'id' => $this->id,
            'name' => $this->name,
            'mobile' => $this->mobile,
            'national_id' => $this->national_id,
            'car_type' => $car_type,
            'max_load' => $this->max_load,
            'plate_number' => $this->plate_number,
            'car_color' => $this->car_color,
            'photo_profile' => it()->url($this->photo_profile),
            'default_address' => new UserAddressResource($this->default_address),
            'vendors' => DeliveryVendorsResource::collection($delivery_vendors)
        ];
    }
}
