<?php

namespace App\Http\Resources\Users;

use Illuminate\Http\Resources\Json\JsonResource;
use App\Models\OrderItem;
use Carbon\Carbon;

class DeliveryReportResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {

        $data = collect([]);
        $data['saturday'] = collect([]);
        $data['sunday'] = collect([]);
        $data['monday'] = collect([]);
        $data['tuesday'] = collect([]);
        $data['wednesday'] = collect([]);
        $data['thursday'] = collect([]);
        $data['friday'] = collect([]);
        $startDate = Carbon::now()->startOfWeek(Carbon::SATURDAY);
        $endDate = Carbon::now()->endOfWeek(Carbon::THURSDAY);
        $interval = \DateInterval::createFromDateString('1 day');
        //Init Date Period from start date to end date
        //1 day is added to end date since date period ends before end date. See first comment: http://php.net/manual/en/class.dateperiod.php
        $datePeriod = new \DatePeriod($startDate, $interval, $endDate->modify('+1 day'));
        foreach($datePeriod as $key=>$datePeriodRow) {
            if($key==0) {
                $day = 'saturday';
            } elseif($key==1) {
                $day = 'sunday';
            } elseif($key==2) {
                $day = 'monday';
            } elseif($key==3) {
                $day = 'tuesday';
            } elseif($key==4) {
                $day = 'wednesday';
            } elseif($key==5) {
                $day = 'thursday';
            } elseif($key==6) {
                $day = 'friday';
            }
            $value = OrderItem::where('delivery_id', $this->id)->where('status_id', 5)->whereDate('created_at', $datePeriodRow->format('Y-m-d'))->count();
            $data[$day]->push($value);
        }
        $total_weekly_orders = OrderItem::where('delivery_id', $this->id)
                ->where('status_id', 5)
                ->whereBetween('created_at', 
                        [Carbon::now()->startOfWeek(Carbon::SATURDAY), Carbon::now()->endOfWeek(Carbon::FRIDAY)]
                    )
                ->get();

        return [
            'total_weekly_orders' => $total_weekly_orders->count(),
            'total_weekly_profit' => $total_weekly_orders->sum('delivery_cost'),
            'chart_data' => $data,
            'total_working_hours' => 21
        ];
    }
}
