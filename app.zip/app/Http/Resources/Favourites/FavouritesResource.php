<?php

namespace App\Http\Resources\Favourites;

use Illuminate\Http\Resources\Json\JsonResource;
use App\Http\Resources\Products\ProductsResource;
use App\Http\Resources\Branches\BranchesResource;

class FavouritesResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        if($this->type=='product') {
            $target = new ProductsResource($this->product);
        } else {
            $target = new BranchesResource($this->branch);
        }
        return $target;
    }
}
