<?php

namespace App\Http\Resources\Faqs;

use Illuminate\Http\Resources\Json\JsonResource;

class FaqsResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        if(request()->has('lang') && request()->lang=='en') {
            $question = $this->question_en;
            $answer = $this->answer_en;
        } elseif(request()->lang=='urdu') {
            $question = $this->question_urdu;
            $answer = $this->answer_urdu;
        } else {
            $question = $this->question_ar;
            $answer = $this->answer_ar;
        }
        return [
            'id' => $this->id,
            'question' => $question,
            'answer' => $answer,
            //'image' => url('storage/'.$this->image),
        ];
    }
}
