<?php

namespace App\Http\Resources\WithdrawalRequests;

use Illuminate\Http\Resources\Json\JsonResource;

class WithdrawalRequestsResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        if($request->type=='withdrawal') {
            $vendor_name = $this->vendor->name??'';
            $amount = $this->amount;
            if(request()->has('lang') && request()->lang=='en') {
                if($this->status=='pending') {
                    $status = 'Pending';
                } elseif($this->status=='completed') {
                    $status = 'Completed';
                } elseif($this->status=='canceled') {
                    $status = 'Canceled';
                }             
            } elseif(request()->lang=='urdu') {
                if($this->status=='pending') {
                    $status = 'زیر التواء';
                } elseif($this->status=='completed') {
                    $status = 'مکمل';
                } elseif($this->status=='canceled') {
                    $status = 'منسوخ';
                }             
            } else {
                if($this->status=='pending') {
                    $status = 'قيد المراجعة';
                } elseif($this->status=='completed') {
                    $status = 'مكتمل';
                } elseif($this->status=='canceled') {
                    $status = 'ملغي';
                }             
            }
        } else {
            $vendor_name = $this->order->vendor->name??'';
            $amount = $this->delivery_cost;
            if(request()->has('lang') && request()->lang=='en') {
                $status = 'Completed';
            } elseif(request()->lang=='urdu') {
                $status = 'مکمل';
            } else {
                $status = 'مكتمل';
            }
        }
        return [
            'id' => $this->id,
            'ref_no' => $this->ref_no,
            'vendor_name' => $vendor_name,
            'amount' => $amount,
            //'bank_account' => $this->bank_account,
            'status' => $status,
            'created_at' => $this->created_at,
        ];
    }
}
