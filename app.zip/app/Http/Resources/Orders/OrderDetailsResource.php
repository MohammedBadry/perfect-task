<?php

namespace App\Http\Resources\Orders;

use Illuminate\Http\Resources\Json\JsonResource;
use App\Http\Resources\Users\UsersResource;
use App\Http\Resources\Branches\BranchesResource;
use App\Http\Resources\OrderItems\OrderItemsResource;
use App\Http\Resources\Orders\OrderStatusesResource;

class OrderDetailsResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'ref_no' => $this->ref_no,
            'user' => new UsersResource($this->user),
            'branch' => new BranchesResource($this->branch),
            'sub_total' => $this->sub_total,
            'tax' => $this->tax,
            'delivery_cost' => $this->delivery_cost,
            'final_total' => $this->order_total(),
            'address' => $this->address,
            'latitude' => $this->latitude,
            'longitude' => $this->longitude,
            'payment_status' => $this->payment_status,
            'payment_method' => $this->payment_method,
            'payed_amount' => $this->payed_amount,
            'rest_amount' => $this->rest_amount,
            'status' => new OrderStatusesResource($this->status),
            'items' => OrderItemsResource::Collection($this->items),
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ];
    }
}
