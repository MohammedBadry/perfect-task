<?php

namespace App\Http\Resources\Orders;

use Illuminate\Http\Resources\Json\JsonResource;
use App\Http\Resources\Branches\BranchesResource;
use App\Http\Resources\Users\UsersResource;
use App\Http\Resources\Vendors\VendorsResource;
use App\Http\Resources\OrderItems\OrderItemsResource;
use App\Http\Resources\Orders\OrderStatusesResource;
use App\Http\Resources\Cities\CitiesResource;
use App\Http\Resources\Cities\AreasResource;

class OrdersResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'ref_no' => $this->ref_no,
            'vendor' => new VendorsResource($this->vendor),
            'branch' => new BranchesResource($this->branch),
            'final_total' => $this->order_total(),
            'payment_method' => $this->payment_method,
            'status' => new OrderStatusesResource($this->status),
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ];
    }
}
