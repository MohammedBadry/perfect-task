<?php

namespace App\Http\Resources\Orders;

use Illuminate\Http\Resources\Json\JsonResource;

class OrderStatusesResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        if(request()->has('lang') && request()->lang=='en') {
            $status = $this->status_en;
        } elseif(request()->lang=='urdu') {
            $status = $this->status_urdu;
        } else {
            $status = $this->status_ar;
        }
        return [
            'id' => $this->id,
            'status' => $status,
        ];
    }
}
