<?php

namespace App\Http\Resources\Orders\Branches;

use Illuminate\Http\Resources\Json\JsonResource;
use App\Http\Resources\Users\UsersResource;
use App\Http\Resources\OrderItems\Branches\BranchesOrderItemsResource;
use App\Http\Resources\Orders\OrderStatusesResource;

class BranchesOrderDetailsResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'ref_no' => $this->ref_no,
            'items' => BranchesOrderItemsResource::Collection($this->items),
            'status' => new OrderStatusesResource($this->status),
            'user_name' => $this->user->name,
            'user_mobile' => $this->user->mobile,
            'address' => $this->address,
            'latitude' => $this->latitude,
            'longitude' => $this->longitude,
            'sub_total' => $this->sub_total,
            'tax' => $this->tax,
            'delivery_cost' => $this->delivery_cost,
            'final_total' => $this->order_total(),
            'created_at' => $this->created_at,
            'recieve_date' => $this->recieve_date,
            'payment_status' => $this->payment_status,
        ];
    }
}
