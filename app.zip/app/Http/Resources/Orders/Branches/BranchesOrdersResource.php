<?php

namespace App\Http\Resources\Orders\Branches;

use Illuminate\Http\Resources\Json\JsonResource;
use App\Http\Resources\Branches\BranchesResource;
use App\Http\Resources\Users\UsersResource;
use App\Http\Resources\Vendors\VendorsResource;
use App\Http\Resources\OrderItems\OrderItemsResource;
use App\Http\Resources\Orders\OrderStatusesResource;
use App\Http\Resources\Cities\CitiesResource;
use App\Http\Resources\Cities\AreasResource;

class BranchesOrdersResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'ref_no' => $this->ref_no,
            'address' => $this->address,
            'latitude' => $this->latitude,
            'longitude' => $this->longitude,
            'final_total' => $this->order_total(),
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ];
    }
}
