<?php

namespace App\Http\Resources\Orders\Branches;

use Illuminate\Http\Resources\Json\JsonResource;

class OrderCancelReasonsResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        if(request()->has('lang') && request()->lang=='en') {
            $reason = $this->text_en;
        } elseif(request()->lang=='urdu') {
            $reason = $this->text_urdu;
        } else {
            $reason = $this->text_ar;
        }
        return [
            'id' => $this->id,
            'reason' => $reason,
        ];
    }
}
