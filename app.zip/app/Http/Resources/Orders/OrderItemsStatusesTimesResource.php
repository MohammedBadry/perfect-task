<?php

namespace App\Http\Resources\Orders;

use Illuminate\Http\Resources\Json\JsonResource;

class OrderItemsStatusesTimesResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {


        if(request()->has('lang') && request()->lang=='en') {
            $status = $this->status_en;
            $description = $this->description_en;
        } elseif(request()->lang=='urdu') {
            $status = $this->status_urdu;
            $description = $this->description_urdu;
        } else {
            $status = $this->status_ar;
            $description = $this->description_ar;
        }
        
        $item_id = $this->when(property_exists($this,'item_id'), function() { return $this->item_id; } );

        $check = \App\Models\OrderItemStatusTime::where(['order_item_id'=> $item_id, 'status_id'=> $this->id])->first();
        
        if($check) {
            $time = $check->time;
        } else {
            $time = null;
        }
        
        return [
            'id' => $this->id,
            'status' => $status,
            'description' => $description,
            'time' => $time
        ];
    }
}
