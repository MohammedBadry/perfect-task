<?php

namespace App\Http\Resources\Notifications;

use Illuminate\Http\Resources\Json\JsonResource;
use App\Http\Resources\Deliveries\DeliveriesResource;

class NotificationsResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        if($this->type=='new_order' || $this->type=='order_status' || $this->type=='accept_offer') {
            $target = new \App\Http\Resources\Orders\OrdersResource($this->target);
        } elseif($this->type=='new_offer' ) {
            $target = new \App\Http\Resources\OrderOffers\OrderOffersResource($this->target);
        } else {
            $target = null;
        }
        if(trans($this->title)!='' && trans($this->body)!='') {
            $title = trans($this->title);
            $body = trans($this->body);
        } else {
            $title = $this->title;
            $body = $this->body;
        }
        return [
            'id' => $this->id,
            'title' => trans($this->title),
            'body' => trans($this->body),
            'type' => $this->type,
            'data' => $target,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ];
    }
}
