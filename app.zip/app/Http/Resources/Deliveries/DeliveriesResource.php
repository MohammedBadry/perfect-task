<?php

namespace App\Http\Resources\Deliveries;

use Illuminate\Http\Resources\Json\JsonResource;
use App\Http\Resources\Cars\CarsResource;

class DeliveriesResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        //check if this delivery has on-going orders, or his availability is 0
        $delivery_recent_orders = \App\Models\Order::whereIn('id', function($query) {
            $query->select('order_id')->from('order_items')->where('delivery_id', $this->id);
        })
        ->where('status_id', 2)
        ->first();

        if($this->availability==0 || $delivery_recent_orders) {
            $availability = 0;
        } else {
            $availability = 1;
        }

        return [
            'id' => $this->id,
            'name' => $this->name,
            'mobile' => $this->mobile,
            'national_id' => $this->national_id,
            'car' => new CarsResource($this->car),
            'max_load' => $this->max_load,
            'plate_number' => $this->plate_number,
            'car_color' => $this->car_color,
            'photo_profile' => it()->url($this->photo_profile),
            'nid_image' => it()->url($this->nid_image),
            'licence_image' => it()->url($this->licence_image),
            'car_form_image' => it()->url($this->car_form_image),
            'car_front_image' => it()->url($this->car_front_image),
            'car_back_image' => it()->url($this->car_back_image),
            'transport_license_image' => it()->url($this->transport_license_image),
            'default_address' => $this->default_address,
            'device_type' => $this->device_type,
			'lang' => $this->lang,
			'status' => $this->status,
			'approved' => $this->approved,
            'availability' => $availability
        ];
    }
}
