<?php

namespace App\Http\Resources\Deliveries;

use Illuminate\Http\Resources\Json\JsonResource;
use App\Http\Resources\Cars\CarsResource;
use App\Http\Resources\UserAddresses\Delivery\UserAddressResource;

class BranchesDeliveriesResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        if(request()->has('lang') && request()->lang=='en') {
            $car_type = $this->car->name_en;
        } elseif(request()->lang=='urdu') {
            $car_type = $this->car->name_urdu;
        } else {
            $car_type = $this->car->name_ar;
        }

        //check if this delivery has on-going orders, or his availability is 0
        $delivery_recent_orders = \App\Models\Order::whereIn('id', function($query) {
            $query->select('order_id')->from('order_items')->where('delivery_id', $this->id);
        })
        ->where('status_id', 2)
        ->first();

        if($this->availability==0 || $delivery_recent_orders) {
            $availability = 0;
        } else {
            $availability = 1;
        }

        return [
            'id' => $this->id,
            'name' => $this->name,
            'car_front_image' => it()->url($this->car_front_image),
            'max_load' => $this->max_load,
            'car_type' => $car_type,
            'address' => new UserAddressResource($this->default_address),
            'availability' => $availability
        ];
    }
}
