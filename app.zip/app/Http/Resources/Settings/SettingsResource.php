<?php

namespace App\Http\Resources\Settings;

use Illuminate\Http\Resources\Json\JsonResource;
use App\Models\OrderStatus;

class SettingsResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        if(request()->has('lang') && request()->lang=='en') {
            $about = $this->user_app_about_en;
            $terms = $this->user_app_terms_en;
        } elseif(request()->lang=='ar') {
            $about = $this->user_app_about_ar;
            $terms = $this->user_app_terms_ar;
        } else {
            $about = $this->user_app_about_urdu;
            $terms = $this->user_app_terms_urdu;
        }

        if(auth()->guard('api')->user()) {
            $user_addresses = \App\Models\UserAddress::where('user_id', auth()->guard('api')->user()->id)->count();

        } else {
            $user_addresses = 0;
        }


        return [
            'about' => $about,
            'terms' => $terms,
            'address' => $this->address,
            'latitude' => $this->latitude,
            'lingitude' => $this->longitude,
            'has_address' => ($user_addresses>0) ? 1 : 0,
            'order_statuses' => OrderStatusesResource::collection($statuses),
        ];
    }
}
