<?php

namespace App\Http\Resources\Settings;

use Illuminate\Http\Resources\Json\JsonResource;

class DeliverySettingsResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        if(request()->has('lang') && request()->lang=='en') {
            $about = $this->delivery_app_about_en;
            $terms = $this->delivery_app_terms_en;
        } elseif(request()->lang=='ar') {
            $about = $this->delivery_app_about_ar;
            $terms = $this->delivery_app_terms_ar;
        } else {
            $about = $this->dapp_about_urdu;
            $terms = $this->delivery_app_terms_urdu;
        }

        return [
            'id' => $this->id,
            'about' => $about,
            'terms' => $terms,
        ];
    }
}
