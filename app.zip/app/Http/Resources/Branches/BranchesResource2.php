<?php

namespace App\Http\Resources\Branches;

use Illuminate\Http\Resources\Json\JsonResource;
use App\Http\Resources\Cities\CitiesResource;
use App\Http\Resources\Cities\AreasResource;
use App\Http\Resources\Vendors\VendorDetailsResource;

class BranchesResource2 extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            /*
            'email' => $this->email,
            'mobile' => $this->mobile,
            'latitude' => $this->latitude,
            'longitude' => $this->longitude,*/
            'city' => new CitiesResource($this->city),
            'area' => new AreasResource($this->area),
            'vendor' => new VendorDetailsResource($this->vendor),
        ];
    }
}
