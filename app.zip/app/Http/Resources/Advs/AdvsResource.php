<?php

namespace App\Http\Resources\Advs;

use Illuminate\Http\Resources\Json\JsonResource;

class AdvsResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {

        if(request()->has('lang') && request()->lang=='en') {
            $title = $this->title_en;
        } elseif(request()->lang=='urdu') {
            $title = $this->title_urdu;
        } else {
            $title = $this->title_ar;
        }
        return [
            'id' => $this->id,
            'title' => $title,
            'price' => $this->price,
            'cursor' => $this->cursor,
        ];
    }
}
