<?php

namespace App\Imports;

use App\Models\Admin;
use App\Models\Product;
use App\Models\Car;
use App\Models\ProductCarLoad;
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\Importable;
use Maatwebsite\Excel\Validators\Failure;
use Maatwebsite\Excel\Concerns\SkipsOnFailure;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithBatchInserts;
use Maatwebsite\Excel\Concerns\WithChunkReading;
use Maatwebsite\Excel\Concerns\WithValidation;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Support\Facades\Hash;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithStartRow;
use Auth;
use DB;

class ProductsImport implements ToModel, WithStartRow, ShouldQueue
{
    /**
     * @return int
     */
    public function startRow(): int
    {
        return 2;
    }

    public function model(array  $row)
    {
        //dd($row);
        $vendor = Admin::find($row[0]);
            if($vendor) {
                DB::transaction(function () use ($row) {
                    $product = Product::create([
                        'vendor_id' => $row[0],
                        'name_ar' => $row[1],
                        'price' => $row[2],
                        'unit_id' => $row[3],
                        'category_id' => $row[4],
                        'minimum_order' => $row[5],
                        'preparing_time' => $row[6],
                    ]);
                    $cars = explode(',', $row[7]);
                    $start_loads = explode(',', $row[8]);
                    $end_loads = explode(',', $row[9]);
                    foreach($cars as $key=>$car) {
                        $car = Car::find($car);
                        if($car) {
                            ProductCarLoad::create([
                                'car_id' => $car->id,
                                'from' => $start_loads[$key],
                                'to' => $end_loads[$key],
                                'product_id' => $product->id,
                            ]);
                        }
                    }
                });
            }
    }

    public function rules(): array
    {
        return [];
    }

    public function onFailure(Failure ...$failures)
    {
        // Handle the failures how you'd like.
    }

    public function batchSize(): int
    {
        return 1;
    }

    public function chunkSize(): int
    {
        return 1;
    }
}
