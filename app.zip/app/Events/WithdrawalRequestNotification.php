<?php

namespace App\Events;

use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Broadcasting\PresenceChannel;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;
use App\Models\WithdrawalRequest;

class WithdrawalRequestNotification implements ShouldBroadcast
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    /**
     * Create a new event instance.
     *
     * @return void
     */

    public $withdrawal_request;

    public function __construct(WithdrawalRequest $withdrawal_request)
    {
        $this->withdrawal_request = $withdrawal_request;
        //logger($this->withdrawalRequest);
    }

    /**
     * Get the channels the event should broadcast on.
     *
     * @return \Illuminate\Broadcasting\Channel|array
     */
    public function broadcastOn()
    {
        //return new Channel('Notify');
        return [
            new Channel('withdrawalRequests.0')
        ];
    }

    public function broadcastWith() {

        return [
            'id' => $this->withdrawal_request->id,
            'date' => $this->withdrawal_request->created_at->format('Y-m-d h:i'),
        ];
    }
}
