<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Area extends Model
{


    protected $table    = 'areas';
    protected $fillable = [
        'id',
        'name_ar',
        'name_en',
        'city_id',
        'created_at',
        'updated_at',
    ];

    protected $perPage = 10;

    /**
     * city relation method
     * @param void
     * @return object data
     */
    public function city()
    {
        return $this->belongsTo(\App\Models\City::class);
    }
    /**
     * Static Boot method to delete or update or sort Data
     * @param void
     * @return void
     */
    protected static function boot()
    {
        parent::boot();
        // if you disable constraints should by run this static method to Delete children data
        static::deleting(function ($city) {
        });
    }
}
