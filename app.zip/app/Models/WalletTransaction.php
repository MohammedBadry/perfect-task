<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WalletTransaction extends Model
{

    protected $table    = 'wallet_transactions';

    protected $fillable = [
        'id',
        'user_id',
        'type',
        'amount',
        'payment_method',
        'payment_id',
        'last_wallet_balance',
        'status',
        'created_at',
        'updated_at',
    ];

    protected $perPage = 10;

    public function user()
    {
        return $this->belongsTo(\App\Models\User::class);
    }
}
