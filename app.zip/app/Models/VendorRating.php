<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class VendorRating extends Model
{

    protected $table    = 'vendor_ratings';

    protected $fillable = [
        'id',
        'user_id',
        'vendor_id',
        'branch_id',
        'comment',
        'created_at',
        'updated_at',
    ];

    protected $perPage = 10;

    /**
     * vendor_id relation method
     * @param void
     * @return object data
     */
    public function vendor()
    {
        return $this->belongsTo(\App\Models\Admin::class);
    }

    public function branch()
    {
        return $this->belongsTo(\App\Models\User::class);
    }

    /**
     * user_id relation method
     * @param void
     * @return object data
     */
    public function user()
    {
        return $this->belongsTo(\App\Models\User::class);
    }

}
