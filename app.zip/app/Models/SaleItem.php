<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SaleItem extends Model
{

    protected $table    = 'sale_items';

    protected $fillable = [
        'id',
        'sale_id',
        'product_id',
        'price',
        'quantity',
        'total',
        'created_at',
        'updated_at',
    ];

    protected $perPage = 10;

    /**
     * sale relation method
     * @param void
     * @return object data
     */
    public function sale()
    {
        return $this->belongsTo(\App\Models\Sale::class);
    }

    /**
     * product relation method
     * @param void
     * @return object data
     */
    public function product()
    {
        return $this->belongsTo(\App\Models\Product::class);
    }
    
}
