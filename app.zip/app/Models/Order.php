<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Scopes\ShownOrderScope;

class Order extends Model
{

    protected $table    = 'orders';

    protected $fillable = [
        'id',
        'ref_no',
        'user_id',
        'sub_total',
        'tax',
        'delivery_cost',
        'final_total',
        'payed_amount',
        'rest_amount',
        'address',
        'city_id',
        'area_id',
        'district',
        'street',
        'latitude',
        'longitude',
        'vendor_id',
        'branch_id',
        'payment_method',
        'payment_id',
        'payment_status',
        'transfer_receipt_1',
        'transfer_receipt_2',
        'status_id',
        'cancel_reason',
        'comments',
        'read',
        'show',
        'created_at',
        'recieve_date',
        'updated_at',
    ];

    protected $perPage = 10;

    /**
     * Get all of the items for the Order
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function items()
    {
        return $this->hasMany(\App\Models\OrderItem::class);
    }

    public function auto_assignments()
    {
        return $this->hasMany(\App\Models\AutoAssignment::class);
    }

    /**
     * user relation method
     * @param void
     * @return object data
     */
    public function user()
    {
        return $this->belongsTo(\App\Models\User::class);
    }

    /**
     * vendor relation method
     * @param void
     * @return object data
     */
    public function vendor()
    {
        return $this->belongsTo(\App\Models\Admin::class);
    }

    public function branch()
    {
        return $this->belongsTo(\App\Models\User::class);
    }

    public function city()
    {
        return $this->belongsTo(\App\Models\City::class);
    }

    public function area()
    {
        return $this->belongsTo(\App\Models\Area::class);
    }

    /**
     * status relation method
     * @param void
     * @return object data
     */
    public function status()
    {
        return $this->belongsTo(\App\Models\OrderStatus::class, 'status_id');
    }

    public function order_total()
    {
        $total = 0;
        $total = $this->sub_total+$this->tax+$this->delivery_cost;
        return $total;
    }

    /**
     * Static Boot method to delete or update or sort Data
     * @param void
     * @return void
     */
    protected static function boot()
    {
        parent::boot();

        //static::addGlobalScope(new ShownOrderScope);

    }
}
