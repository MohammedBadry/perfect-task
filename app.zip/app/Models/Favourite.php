<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Favourite extends Model
{

    protected $table    = 'favourites';

    protected $fillable = [
        'id',
        'user_id',
        'type',
        'target_id',
        'created_at',
        'updated_at',
    ];

    protected $perPage = 10;

    /**
     * user relation method
     * @param void
     * @return object data
     */
    public function user()
    {
        return $this->belongsTo(\App\Models\User::class);
    }

    /**
     * product relation method
     * @param void
     * @return object data
     */
    public function product()
    {
        return $this->belongsTo(\App\Models\Product::class, 'target_id');
    }

    /**
     * vendor relation method
     * @param void
     * @return object data
     */
    public function branch()
    {
        return $this->belongsTo(\App\Models\User::class, 'target_id');
    }
}
