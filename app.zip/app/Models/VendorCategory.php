<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class VendorCategory extends Model
{

   protected $table    = 'vendor_categories';

   protected $fillable = [
      'id',
      'vendor_id',
      'category_id',
      'created_at',
      'updated_at',
   ];

   protected $perPage = 10;

   /**
    * vendor_id relation method
    * @param void
    * @return object data
    */
   public function vendor()
   {
      return $this->belongsTo(\App\Models\Admin::class);
   }

   public function category()
   {
      return $this->belongsTo(\App\Models\Category::class);
   }


   /**
    * Static Boot method to delete or update or sort Data
    * @param void
    * @return void
    */
   protected static function boot()
   {
      parent::boot();
      // if you disable constraints should by run this static method to Delete children data
      static::deleting(function ($category) {
      });
   }
}
