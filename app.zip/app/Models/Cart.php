<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Cart extends Model
{

    protected $table    = 'cart';

    protected $fillable = [
        'id',
        'branch_id',
        'user_id',
        'product_id',
        'quantity',
        'delivery_cost',
        'created_at',
        'updated_at',
    ];

    protected $perPage = 10;

    /**
     * user relation method
     * @param void
     * @return object data
     */
    public function user()
    {
        return $this->belongsTo(\App\Models\User::class);
    }

    public function branch()
    {
        return $this->belongsTo(\App\Models\User::class);
    }

    /**
     * product relation method
     * @param void
     * @return object data
     */
    public function product()
    {
        return $this->belongsTo(\App\Models\Product::class, 'product_id');
    }

}
