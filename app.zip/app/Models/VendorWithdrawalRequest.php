<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class VendorWithdrawalRequest extends Model
{


   protected $table    = 'vendor_withdrawal_requests';
   protected $fillable = [
      'id',
      'vendor_id',
      'amount',
      'account_name',
      'bank_name',
      'account_number',
      'iban',
      'status',
      'read',
      'created_at',
      'updated_at',
   ];

   protected $perPage = 10;

    /**
     * vendor relation method
     * @param void
     * @return object data
     */
    public function vendor()
    {
        return $this->belongsTo(\App\Models\Admin::class, 'vendor_id');
    }
}
