<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProductCarLoad extends Model
{
    use HasFactory;

    protected $fillable = [
        'id',
        'product_id',
        'car_id',
        'from',
        'to',
        'created_at',
        'updated_at',
     ];

     protected $perPage = 10;

     /**
      * product relation method
      * @param void
      * @return object data
      */
     public function product()
     {
        return $this->belongsTo(\App\Models\Product::class);
     }

     public function car()
     {
        return $this->belongsTo(\App\Models\Car::class);
     }

  }
