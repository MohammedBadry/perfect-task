<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OrderItemStatusTime extends Model
{


   protected $table    = 'order_items_status_times';
   protected $fillable = [
      'id',
      'order_item_id',
      'status_id',
      'time',
      'created_at',
      'updated_at',
   ];

   protected $perPage = 10;

    /**
     * order relation method
     * @param void
     * @return object data
     */
    public function order_item()
    {
      return $this->belongsTo(\App\Models\OrderItem::class, 'order_item_id', 'id');
   }

    /**
     * status relation method
     * @param void
     * @return object data
     */
    public function status()
    {
        return $this->belongsTo(\App\Models\OrderItemStatus::class, 'status_id', 'id');
    }

   /**
    * Static Boot method to delete or update or sort Data
    * @param void
    * @return void
    */
   protected static function boot()
   {
      parent::boot();
      // if you disable constraints should by run this static method to Delete children data
      static::deleting(function ($category) {
      });
   }
}
