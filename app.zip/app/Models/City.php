<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class City extends Model
{


    protected $table    = 'cities';
    protected $fillable = [
        'id',
        'name_ar',
        'name_en',
        'created_at',
        'updated_at',
    ];

    protected $perPage = 10;

    /**
     * Get all of the areas for the city
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function areas()
    {
        return $this->hasMany(\App\Models\Area::class);
    }
    /**
     * Static Boot method to delete or update or sort Data
     * @param void
     * @return void
     */
    protected static function boot()
    {
        parent::boot();
        // if you disable constraints should by run this static method to Delete children data
        static::deleting(function ($city) {
        });
    }
}
