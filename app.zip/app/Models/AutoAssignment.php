<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AutoAssignment extends Model
{


   protected $table    = 'auto_assignments';
   protected $fillable = [
      'id',
      'delivery_id',
      'order_item_id',
      'status',
      'created_at',
      'updated_at',
   ];

   protected $perPage = 10;

    /**
     * order relation method
     * @param void
     * @return object data
     */
    public function order_item()
    {
        return $this->belongsTo(\App\Models\OrderItem::class);
    }

    /**
     * delivery relation method
     * @param void
     * @return object data
     */
    public function delivery()
    {
        return $this->belongsTo(\App\Models\User::class, 'delivery_id');
    }
   /**
    * Static Boot method to delete or update or sort Data
    * @param void
    * @return void
    */
   protected static function boot()
   {
      parent::boot();
      // if you disable constraints should by run this static method to Delete children data
      static::deleting(function ($category) {
      });
   }
}
