<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WithdrawalRelatedOrder extends Model
{

    protected $table    = 'withdrawal_related_orders';

    protected $fillable = [
        'id',
        'withdrawal_request_id',
        'order_item_id',
        'created_at',
        'updated_at',
    ];

    protected $perPage = 10;

    public function withdrawalRequest()
    {
        return $this->belongsTo(\App\Models\WithdrawalRequest::class);
    }
    
    public function order()
    {
        return $this->belongsTo(\App\Models\OrderItem::class);
    }
    
}
