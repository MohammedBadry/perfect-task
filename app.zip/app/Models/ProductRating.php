<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProductRating extends Model
{

    protected $table    = 'product_ratings';

    protected $fillable = [
        'id',
        'user_id',
        'product_id',
        'rating',
        'created_at',
        'updated_at',
    ];

    protected $perPage = 10;

    /**
     * product_id relation method
     * @param void
     * @return object data
     */
    public function product()
    {
        return $this->belongsTo(\App\Models\Product::class);
    }

    /**
     * user_id relation method
     * @param void
     * @return object data
     */
    public function user()
    {
        return $this->belongsTo(\App\Models\User::class);
    }

}
