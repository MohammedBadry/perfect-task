<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Faq extends Model
{


   protected $table    = 'faqs';
   protected $fillable = [
      'id',
      'admin_id',
      'question_ar',
      'question_en',
      'question_urdu',
      'answer_ar',
      'answer_en',
      'answer_urdu',
      'type',
      'created_at',
      'updated_at',
   ];

   protected $perPage = 10;

   /**
    * Static Boot method to delete or update or sort Data
    * @param void
    * @return void
    */
   protected static function boot()
   {
      parent::boot();
      // if you disable constraints should by run this static method to Delete children data
      static::deleting(function ($faq) {
      });
   }
}
