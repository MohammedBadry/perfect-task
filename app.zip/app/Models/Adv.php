<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Adv extends Model
{


   protected $table    = 'advs';
   protected $fillable = [
      'id',
      'title_ar',
      'title_en',
      'title_urdu',
      'price',
      'cursor',
      'created_at',
      'updated_at',
   ];

   protected $perPage = 10;

   /**
    * Static Boot method to delete or update or sort Data
    * @param void
    * @return void
    */
   protected static function boot()
   {
      parent::boot();
      // if you disable constraints should by run this static method to Delete children data
      static::deleting(function ($banner) {
      });
   }
}
