<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OrderStatus extends Model
{


   protected $table    = 'order_statuses';
   protected $fillable = [
      'id',
      'admin_id',
      'status_ar',
      'status_en',
      'created_at',
      'updated_at',
   ];

   protected $perPage = 10;

   /**
    * Static Boot method to delete or update or sort Data
    * @param void
    * @return void
    */
   protected static function boot()
   {
      parent::boot();
      // if you disable constraints should by run this static method to Delete children data
      static::deleting(function ($category) {
      });
   }
}
