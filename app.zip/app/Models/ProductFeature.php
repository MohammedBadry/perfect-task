<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProductFeature extends Model
{
    use HasFactory;

    protected $fillable = [
        'id',
        'admin_id',
        'name_ar',
        'name_en',
        'name_urdu',
        'product_id',
        'created_at',
        'updated_at',
     ];

     protected $perPage = 10;

     /**
      * product relation method
      * @param void
      * @return object data
      */
     public function product()
     {
        return $this->belongsTo(\App\Models\Product::class);
     }
  }
