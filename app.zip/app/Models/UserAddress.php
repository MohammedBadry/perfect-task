<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserAddress extends Model
{

    protected $table    = 'user_addresses';

    protected $fillable = [
        'id',
        'user_id',
        'address',
        'description',
        'district',
        'street',
        'city_id',
        'area_id',
        'latitude',
        'longitude',
        'is_default',
        'created_at',
        'updated_at',
    ];

    protected $perPage = 10;

    /**
     * user relation method
     * @param void
     * @return object data
     */
    public function user()
    {
        return $this->belongsTo(\App\Models\User::class);
    }

    public function city()
    {
        return $this->belongsTo(\App\Models\City::class);
    }

    public function area()
    {
        return $this->belongsTo(\App\Models\Area::class);
    }

}
