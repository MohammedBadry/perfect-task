<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BranchDelivery extends Model
{

   protected $table    = 'branch_deliveries';

   protected $fillable = [
      'id',
      'vendor_id',
      'branch_id',
      'delivery_id',
      'created_at',
      'updated_at',
   ];

   protected $perPage = 10;

   /**
    * vendor_id relation method
    * @param void
    * @return object data
    */
   public function branch()
   {
      return $this->belongsTo(\App\Models\User::class);
   }

   public function vendor()
   {
      return $this->belongsTo(\App\Models\Admin::class);
   }

   public function delivery()
   {
      return $this->belongsTo(\App\Models\User::class);
   }
}
