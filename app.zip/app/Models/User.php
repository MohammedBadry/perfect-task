<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Tymon\JWTAuth\Contracts\JWTSubject;

class User extends Authenticatable implements JWTSubject
{
	use HasFactory, Notifiable;
	protected $table = 'users';
	/**
	 * The attributes that are mass assignable.
	 *
	 * @var array
	 */
	protected $fillable = [
		'type',
		'vendor_id',
		'city_id',
		'area_id',
		'name',
		'email',
		'mobile',
		'otp_code',
		'otp_trails',
		'otp_verify_trails',
		'otp_date',
		'otp_verify_date',
		'password',
		'fcm_token',
		'device_type',
		'photo_profile',
		'national_id',
        'car_id',
        'max_load',
        'plate_number',
        'car_color',
		'nid_image',
		'licence_image',
		'car_form_image',
		'car_front_image',
		'car_back_image',
		'transport_license_image',
		'address',
		'latitude',
		'longitude',
		'approved',
		'status',
		'wallet_balance',
        'payment_id',
        'partial_payment',
		'read',
		'lang'
    ];

	protected $perPage = 10;

	/**
	 * The attributes that should be hidden for arrays.
	 *
	 * @var array
	 */
	protected $hidden = [
		'password',
		'remember_token',
	];

	/**
	 * The attributes that should be cast to native types.
	 *
	 * @var array
	 */
	protected $casts = [
		'email_verified_at' => 'datetime',
	];

	/**
	 * Get the identifier that will be stored in the subject claim of the JWT.
	 *
	 * @return mixed
	 */
	public function getJWTIdentifier()
	{
		return $this->getKey();
	}

	/**
	 * Return a key value array, containing any custom claims to be added to the JWT.
	 *
	 * @return array
	 */
	public function getJWTCustomClaims()
	{
		return [];
	}

    public function branch()
    {
        return $this->hasOne(BranchDelivery::class, 'delivery_id');
    }

    public function vendor()
    {
        return $this->belongsTo(Admin::class, 'vendor_id');
    }

    public function city()
    {
        return $this->belongsTo(City::class, 'city_id');
    }

    public function area()
    {
        return $this->belongsTo(Area::class, 'area_id');
    }

    public function car()
    {
        return $this->belongsTo(Car::class, 'car_id');
    }


    /**
     * Get all of the cart for the User
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function cart()
    {
        return $this->hasMany(Cart::class);
    }

    public function bank_accounts()
    {
        return $this->hasMany(UserBankAccount::class);
    }

    /**
     * Get all of the cart for the User
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function favourite_products()
    {
        return $this->hasMany(Favourite::class)->where('type', 'product');
    }

    public function notifications()
    {
        return $this->hasMany(MobileNotification::class);
    }

    /**
     * Get all of the cart for the User
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function favourite_vendors()
    {
        return $this->hasMany(Favourite::class)->where('type', 'vendor');
    }

	/**
	 * Get the default_address associated with the User
	 *
	 * @return \Illuminate\Database\Eloquent\Relations\HasOne
	 */
	public function default_address()
	{
		return $this->hasOne(UserAddress::class)->where('is_default', 1);
	}

    public function ratings()
    {
        return $this->hasMany(\App\Models\UserRating::class, 'rated_id');
    }

    public function cartTotal() {
        $cart = Cart::where('user_id', auth()->guard('api')->user()->id)->get();
        $total = 0;
        $extras = 0;
        foreach ($cart as $c) {
            $total += (($c->product->price-$c->product->discount)*$c->quantity);
        }
        return $total;
    }

    public function cartDeliveryCost() {
        $cart = Cart::where('user_id', auth()->guard('api')->user()->id)->get();
        $total = 0;
        $extras = 0;
        foreach ($cart as $c) {
            $total += $c->delivery_cost;
        }
        return $total;
    }

    /*
    public function cartDeliveryCost() {
        $cart = Cart::where('user_id', auth()->guard('api')->user()->id)->get();
        $total = 0;
        foreach ($cart as $c) {
            $quantity = $c->quantity;
            $total_delivery = \App\Models\ProductCarLoad::where('product_id', $c->product_id)
            ->where(function ($query) use ($quantity) {
                $query->where('from', '<=', $quantity);
                $query->where('to', '>=', $quantity);
            })->first();
            $total += $total_delivery->car->delivery_cost??0;
        }
        return $total;
    }
    */
    public function total_ratings()
    {
        $total = 0;
        $rest = 0;
        $ratings_count = $this->ratings->count();
        if($ratings_count>0) {
            foreach($this->ratings as $rate) {
                $total += $rate->rating;
            }
            $rest = $total/$ratings_count;
        }
        return $rest;
    }

    public function total_less_ratings()
    {
        $total = 0;
        $rest = 0;
        $ratings_count = $this->ratings->where('rating', '<=', 2)->count();
        if($ratings_count>0) {
            return $ratings_count;
        } else {
            return '-';
        }
    }

}
