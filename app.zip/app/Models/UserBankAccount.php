<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserBankAccount extends Model
{

    protected $table    = 'user_bank_accounts';

    protected $fillable = [
        'id',
        'user_id',
        'bank_name',
        'bank_account',
        'iban'
];

    protected $perPage = 10;

    /**
     * user_id relation method
     * @param void
     * @return object data
     */
    public function user()
    {
        return $this->belongsTo(\App\Models\User::class);
    }

}
