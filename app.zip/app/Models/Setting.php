<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Setting extends Model
{
	protected $table = 'settings';
	protected $fillable = [
		'sitename_ar',
		'sitename_en',
		'sitename_fr',
		'email',
		'logo',
		'icon',
		'address',
		'latitude',
		'longitude',
		'system_status',
		'system_message',
		'theme_setting',
		'tax',
		'user_app_about_ar',
		'delivery_app_about_ar',
		'branch_app_about_ar',
		'user_app_terms_ar',
		'delivery_app_terms_ar',
		'branch_app_terms_ar',
		'user_app_about_en',
		'delivery_app_about_en',
		'branch_app_about_en',
		'user_app_terms_en',
		'delivery_app_terms_en',
		'branch_app_terms_en',
		'user_app_about_urdu',
		'delivery_app_about_urdu',
		'branch_app_about_urdu',
		'user_app_terms_urdu',
		'delivery_app_terms_urdu',
		'branch_app_terms_urdu',
		'bank_name',
		'bank_account_name',
		'bank_account_number',
		'iban',
	];
}
