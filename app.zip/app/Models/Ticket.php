<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Ticket extends Model
{


    protected $table    = 'tickets';
    protected $fillable = [
        'id',
        'subject',
        'message',
        'user_id',
        'created_at',
        'updated_at',
    ];

    protected $perPage = 10;


    /**
     * user relation method
     * @param void
     * @return object data
     */
    public function user()
    {
        return $this->belongsTo(\App\Models\User::class);
    }

}
