<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Car extends Model
{


    protected $table    = 'cars';
    protected $fillable = [
        'id',
        'name_ar',
        'name_en',
        'delivery_cost',
        'image',
        'created_at',
        'updated_at',
    ];

    protected $perPage = 10;

    /**
     * Static Boot method to delete or update or sort Data
     * @param void
     * @return void
     */
    protected static function boot()
    {
        parent::boot();
        // if you disable constraints should by run this static method to Delete children data
        static::deleting(function ($car) {
        });
    }
}
