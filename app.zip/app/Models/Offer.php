<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Offer extends Model
{


   protected $table    = 'offers';
   protected $fillable = [
      'id',
      'product_id',
      'text_ar',
      'text_en',
      'text_urdu',
      'discount_percentage',
      'created_at',
      'updated_at',
   ];

   protected $perPage = 10;

   /**
    * Get the product that owns the Offer
    *
    * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
    */
   public function product()
   {
       return $this->belongsTo(Product::class);
   }

   /**
    * Static Boot method to delete or update or sort Data
    * @param void
    * @return void
    */
   protected static function boot()
   {
      parent::boot();
      // if you disable constraints should by run this static method to Delete children data
      static::deleting(function ($banner) {
      });
   }
}
