<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Sale extends Model
{

    protected $table    = 'sales';

    protected $fillable = [
        'id',
        'user_id',
        'sub_total',
        'tax_percentage',
        'tax_value',
        'total',
        'date',
        'created_at',
        'updated_at',
    ];

    protected $perPage = 10;

    /**
     * Get all of the items for the Order
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function items()
    {
        return $this->hasMany(\App\Models\SaleItem::class);
    }

    /**
     * user relation method
     * @param void
     * @return object data
     */
    public function user()
    {
        return $this->belongsTo(\App\Models\User::class);
    }

    public function sale_total()
    {
        return $this->items->sum('total');
    }

    /**
     * Static Boot method to delete or update or sort Data
     * @param void
     * @return void
     */
    protected static function boot()
    {
        parent::boot();

        //static::addGlobalScope(new ShownOrderScope);

    }
}
