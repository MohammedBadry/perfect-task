<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{

    protected $table    = 'products';

    protected $fillable = [
        'id',
        'name_ar',
        'name_en',
        'description_ar',
        'description_en',
        'vendor_id',
        'category_id',
        'unit_id',
        'price',
        'discount',
        'minimum_order',
        'preparing_time',
        'image',
        'created_at',
        'updated_at',
    ];

    protected $perPage = 10;

    /**
     * unit_id relation method
     * @param void
     * @return object data
     */
    public function unit()
    {
        return $this->belongsTo(\App\Models\Unit::class);
    }

    /**
     * vendor_id relation method
     * @param void
     * @return object data
     */
    public function vendor()
    {
        return $this->belongsTo(\App\Models\Admin::class);
    }

    /**
     * category_id relation method
     * @param void
     * @return object data
     */
    public function category()
    {
        return $this->belongsTo(\App\Models\Category::class);
    }

    /**
     * Get all of the comments for the Product
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */

    public function images()
    {
        return $this->hasMany(\App\Models\ProductImage::class);
    }

    public function features()
    {
        return $this->hasMany(\App\Models\ProductFeature::class);
    }

    public function car_loads()
    {
        return $this->hasMany(\App\Models\ProductCarLoad::class);
    }

    public function ratings()
    {
        return $this->hasMany(\App\Models\ProductRating::class);
    }

    public function total_ratings()
    {
        $total = 0;
        $rest = 0;
        $ratings_count = $this->ratings->count();
        if($ratings_count>0) {
            foreach($this->ratings as $rate) {
                $total += $rate->rating;
            }
            $rest = $total/$ratings_count;
        }
        return $rest;
    }
    /**
     * Static Boot method to delete or update or sort Data
     * @param void
     * @return void
     */
    protected static function boot()
    {
        parent::boot();
        // if you disable constraints should by run this static method to Delete children data
        static::deleting(function ($product) {
            //$product->vendor_id()->delete();
            //$product->vendor_id()->delete();
        });
    }
}
