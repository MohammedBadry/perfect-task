<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WithdrawalRequest extends Model
{


   protected $table    = 'withdrawal_requests';
   protected $fillable = [
      'id',
      'ref_no',
      'delivery_id',
      'vendor_id',
      'amount',
      'bank_account_id',
      'status',
      'read',
      'created_at',
      'updated_at',
   ];

   protected $perPage = 10;


    /**
     * delivery relation method
     * @param void
     * @return object data
     */
    public function delivery()
    {
        return $this->belongsTo(\App\Models\User::class, 'delivery_id');
    }

    public function vendor()
    {
        return $this->belongsTo(\App\Models\Admin::class, 'vendor_id');
    }

    public function bank_account()
    {
        return $this->belongsTo(\App\Models\UserBankAccount::class, 'bank_account_id');
    }
}
