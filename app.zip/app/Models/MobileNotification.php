<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MobileNotification extends Model
{

    protected $table    = 'mobile_notitfications';

    protected $fillable = [
        'id',
        'title',
        'body',
        'type',
        'target_id',
        'user_id',
        'created_at',
        'updated_at',
    ];

    protected $perPage = 10;

    public function getCreatedAtAttribute($date)
    {
        return \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $date)->format('Y-m-d H:i:s');
    }

    public function getUpdatedAtAttribute($date)
    {
        return \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $date)->format('Y-m-d H:i:s');
    }

    /**
     * order relation method
     * @param void
     * @return object data
     */
    public function user()
    {
        return $this->belongsTo(\App\Models\User::class);
    }

    public function target()
    {
        if($this->type=='new_order' || $this->type=='order_status' ||$this->type=='accept_offer') {
            return $this->belongsTo(\App\Models\Order::class, 'target_id');
        } elseif($this->type=='new_offer') {
            return $this->belongsTo(\App\Models\OrderOffer::class, 'target_id');
        }
    }

}
