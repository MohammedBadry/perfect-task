<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class Admin extends Authenticatable
{
	use Notifiable;
	protected $table = 'admins';
	protected $fillable = [
		'name',
		'email',
		'mobile',
		'photo_profile',
		'password',
		'group_id',
		'category_id',
		'is_vendor',
		'about_company',
		'Commercial_registration_type',
		'year_founded',
		'employees_number',
		'address',
		'latitude',
		'longitude',
		'commercial_register',
		'tax_certificate',
		'tax_number',
		'status',
		'remember_token',
		'wallet_balance',
		'account_name',
		'bank_name',
		'account_number',
		'iban',
		'read',
	];

	protected $perPage = 10;

	protected $hidden = ['password'];

	public function scopeAdmins()
	{
		return $this->where('is_vendor', '0')->where('id', '!=', '1');
	}

	public function scopeVendors()
	{
		return $this->where('is_vendor', '1');
	}
	/**
	 * Get the user that owns the Admin
	 *
	 * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
	 */
	public function categories()
	{
		return $this->hasMany(\App\Models\VendorCategory::class, 'vendor_id', 'id');
	}

	public function group_id()
	{
		return $this->hasOne(\App\Models\AdminGroup::class, 'id', 'group_id');
	}

	public function branches()
	{
		return $this->hasMany(\App\Models\User::class, 'vendor_id', 'id');
	}

    public function ratings()
    {
        return $this->hasMany(\App\Models\VendorRating::class, 'vendor_id');
    }

    public function total_ratings000()
    {
        $total = 0;
        $rest = 0;
        $ratings_count = $this->ratings->count();
        if($ratings_count>0) {
            foreach($this->ratings as $rate) {
                $total += $rate->rating;
            }
            $rest = $total/$ratings_count;
        }
        return $rest;
    }

	public function role($name)
	{
		$exists_group_id = $this->getConnection()
			->getSchemaBuilder()
			->hasColumn($this->getTable(), 'group_id');
		if ($exists_group_id) {
			$explode_name = explode('_', $name);

			if (!empty($this->group_id()->first())) {
				$role = $this->group_id()->first()->role()->where('name', $explode_name[0])->first();
				if (!empty($role) && $role->{$explode_name[1]} == 'yes') {
					return true;
				} else {
					return false;
				}
			} else {
				return false;
			}
		} else {
			return false;
		}
	}
}
