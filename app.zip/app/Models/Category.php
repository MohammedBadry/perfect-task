<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Category extends Model
{


    protected $table    = 'categories';
    protected $fillable = [
        'id',
        'admin_id',
        'name_ar',
        'name_en',
        'image',
        'parent_id',
        'created_at',
        'updated_at',
    ];

    protected $perPage = 10;

    public function scopeMain($query)
    {
        $query->where('parent_id', null);
    }

    public function parent()
	{
		return $this->belongsTo(\App\Models\Category::class, 'parent_id');
	}

    /**
     * Get all of the subcategories for the Category
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function subcategories()
    {
        return $this->hasMany(Category::class, 'parent_id');
    }

    /**
     * Static Boot method to delete or update or sort Data
     * @param void
     * @return void
     */
    protected static function boot()
    {
        parent::boot();
        // if you disable constraints should by run this static method to Delete children data
        static::deleting(function ($category) {
        });
    }
}
