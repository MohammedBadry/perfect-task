<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OrderItem extends Model
{

    protected $table    = 'order_items';

    protected $fillable = [
        'id',
        'ref_no',
        'order_id',
        'product_id',
        'vendor_id',
        'delivery_id',
        'price',
        'discount',
        'quantity',
        'total',
        'delivery_cost',
        'paid_status',
        'status_id',
        'otp_code',
        'created_at',
        'updated_at',
    ];

    protected $perPage = 10;

    /**
     * order relation method
     * @param void
     * @return object data
     */
    public function order()
    {
        return $this->belongsTo(\App\Models\Order::class);
    }

    /**
     * product relation method
     * @param void
     * @return object data
     */
    public function product()
    {
        return $this->belongsTo(\App\Models\Product::class);
    }

    public function delivery()
    {
        return $this->belongsTo(\App\Models\User::class);
    }

    public function status()
    {
        return $this->belongsTo(\App\Models\OrderItemStatus::class, 'status_id', 'id');
    }

    public function status_time()
    {
        return $this->hasMany(\App\Models\OrderItemStatusTime::class);
    }    
    
}
