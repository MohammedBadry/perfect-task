<?php

namespace App\Listeners;
use App\Events\DriverDocumentsUploadEvent;
use App\Models\UserEditRequest;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use App\Traits\GeneralTrait;
use DB;

class DriverDocumentsUploadListener implements ShouldQueue
{
    use GeneralTrait;
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct(DriverDocumentsUploadEvent $event)
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  object  $event
     * @return void
     */
    public function handle(DriverDocumentsUploadEvent $event)
    {
        $user = auth()->guard('api')->user();

        $request = $event->request->except('lang');
        logger($request);

        $request['user_id'] = $user->id;

		if (request()->hasFile('photo_profile')) {
			$request['photo_profile'] = it()->upload('photo_profile', 'users');
		}
		if (request()->hasFile('car_front_image')) {
			$request['car_front_image'] = it()->upload('car_front_image', 'users');
		}

		if (request()->hasFile('car_back_image')) {
			$request['car_back_image'] = it()->upload('car_back_image', 'users');
		}

		if (request()->hasFile('licence_image')) {
			$request['licence_image'] = it()->upload('licence_image', 'users');
		}

		UserEditRequest::updateOrCreate(['user_id' => $user->id ], $request);
    }

}
