<?php

namespace App\Listeners;

use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use App\Events\SendDeliveryOtpEvent;
use App\Services\OTPService;
use App\Models\Setting;

class SendDeliveryOtpListener
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct(SendDeliveryOtpEvent $event)
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  object  $event
     * @return void
     */
    public function handle(SendDeliveryOtpEvent $event)
    {
        $settings = Setting::first();
        $item = $event->item;

        ////verification code
        $code = rand(11111, 99999);
        //create or update otp record
        $item->otp_code = $code;
        $item->save();
        
        //send the verification code
        $message = "#".$item->ref_no." ".__("Order Delivery Code is") . ": " . $code . ".";

        try {
            $otpService = new OTPService();
            $otpService->sendOTP($item->order->user, $message);

            return response()->json([
                "message" => __('OTP sent successfully'),
            ], 200);
        } catch (\Exception $ex) {
            //logger("Send OTP inssue", [$ex]);
            return response()->json([
                "message" => __('OTP failed to send to provided phone number'),
            ], 400);
        }
        
    }
}
