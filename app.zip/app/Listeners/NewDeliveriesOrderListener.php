<?php

namespace App\Listeners;
use App\Events\NewDeliveriesOrderNotification;
use App\Models\User;
use App\Models\Order;
use App\Models\AutoAssignment;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use App\Services\AutoAssignmentService;
use App\Http\Resources\OrderItems\NotificationOrderItemsResource;
use App\Traits\GeneralTrait;
use DB;

class NewDeliveriesOrderListener
{
    use GeneralTrait;
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct(NewDeliveriesOrderNotification $event)
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  object  $event
     * @return void
     */
    public function handle(NewDeliveriesOrderNotification $event)
    {
        $order = $event->order;

        $image = url('storage/'.\App\Models\Setting::first()->logo);

        $whoHasOrder = Order::whereIn('status_id', [2,3,4,5,6])->pluck('delivery_id');

        $ignoredDrivers = AutoAssignment::where([
            'order_id' => $order->id,
            'status' => 'pending'
        ])->pluck('delivery_id');

        $deliveries = DB::table("users")
        ->select("*"
            ,DB::raw("6371 * acos(cos(radians(" . $order->pickup_latitude . "))
            * cos(radians(users.latitude))
            * cos(radians(users.longitude) - radians(" . $order->pickup_longitude . "))
            + sin(radians(" .$order->pickup_latitude. ")) * sin(radians(users.latitude))) AS distance "))
            ->where(['type' => 'delivery', 'status' => 1, 'approved' => 1, 'payment_status' => 'paid'])
            ->where('package_id', '!=', null)
            ->where('latitude', '!=', null)
            ->where('latitude', '!=', null)
            ->whereNotIn('id', $whoHasOrder)
            ->whereNotIn('id', $ignoredDrivers)
            ->orderBy('distance', 'asc')
            ->limit(5)
            ->get();

        //$secondsFromNowAgo = Carbon::now()->subSeconds(setting('alertDuration', 60) * 2)->toTimeString();
        //loop through and delte the records while also sending notification to the driver

        foreach ($deliveries as $delivery) {

            //send the new order failture to driver via push notification
            /*
            $autoAssignmentSerivce = new AutoAssignmentService();
            $autoAssignmentSerivce->sendNotification($delivery, trans('auth.new_order_title'), trans('auth.new_order_details'), 'new_order', $order->id, $image );
            */
            AutoAssignment::create([
                'order_id' => $order->id,
                'delivery_id' => $delivery->id,
                'status' => 'pending'
            ]);

        }

    }

}
