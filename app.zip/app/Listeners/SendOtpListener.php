<?php

namespace App\Listeners;

use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use App\Events\SendOtpEvent;
use App\Services\OTPService;
use App\Models\Setting;

class SendOtpListener
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct(SendOtpEvent $event)
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  object  $event
     * @return void
     */
    public function handle(SendOtpEvent $event)
    {
        $settings = Setting::first();
        $user = $event->user;

        ////verification code
        $code = rand(11111, 99999);
        //create or update otp record
        $user->otp_code = $code;
        $user->save();

        
        //send the verification code
        $message = __("Verification Code") . ": " . $code . ".";

        try {
            $otpService = new OTPService();
            $otpService->sendOTP($user, $message);

            return response()->json([
                "message" => __('OTP sent successfully'),
            ], 200);
        } catch (\Exception $ex) {
            //logger("Send OTP inssue", [$ex]);
            return response()->json([
                "message" => __('OTP failed to send to provided phone number'),
            ], 400);
        }
        
    }
}
