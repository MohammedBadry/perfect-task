<?php

namespace App\Listeners;

use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use App\Events\SendInvoiceEvent;
use App\Services\OTPService;
use App\Services\ShortenUrlService;
use App\Models\Setting;

class SendInvoiceListener
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct(SendInvoiceEvent $event)
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  object  $event
     * @return void
     */
    public function handle(SendInvoiceEvent $event)
    {
        $settings = Setting::first();
        $order = $event->order;

        $link = url('/invoice/'.$order->id);

        $shortenUrl = new ShortenUrlService();
        $shortenedLink = $shortenUrl->shortenUrl($link);

        if($shortenedLink==false) {
            $shortenedLink = $link;
        }
        
        //send invoice link
        $message = __("Your order invoice link") . ": " . $shortenedLink . ".";

        logger($message);

        try {
            $otpService = new OTPService();
            $otpService->sendOTP($order->user, $message);

            return response()->json([
                "message" => __('OTP sent successfully'),
            ], 200);
        } catch (\Exception $ex) {
            //logger("Send OTP inssue", [$ex]);
            return response()->json([
                "message" => __('OTP failed to send to provided phone number'),
            ], 400);
        }
        
    }
}
