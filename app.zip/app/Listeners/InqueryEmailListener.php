<?php

namespace App\Listeners;

use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Support\Facades\Mail;
use App\Events\InqueryEmailEvent;
use App\Mail\AdminInquery as AdminInqueryEmail;

class InqueryEmailListener implements ShouldQueue
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct(InqueryEmailEvent $event)
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  object  $event
     * @return void
     */
    public function handle(InqueryEmailEvent $event)
    {
        $user = $event->user;
        $settings = $event->settings;

        if($settings->email!='') {
            $to = $settings->email;
        } else {
            $to = 'mnjz@mnjz.com';
        }
        Mail::to($to)->send(new AdminInqueryEmail($user));
        //logger($user);
    }
}
