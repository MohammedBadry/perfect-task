<?php
		return [
		"name_en"	=>		"اسم القسم إنجليزي",
		"name_ar"	=>		"اسم القسم عربي",
		"categories"	=>		"الأقسام الرئيسية",

];