@extends('admin.layouts.master')
@section('content')

                <div class="nk-content ">
                    <div class="container-fluid">
                        <div class="nk-content-inner">
                            <div class="nk-content-body">
                                <div class="components-preview wide-md mx-auto">
                                    <div class="nk-block-head nk-block-head-lg wide-sm">
                                        <div class="nk-block-head-content">
											&nbsp;
										</div>
                                    </div><!-- .nk-block-head -->
                                    <div class="nk-block nk-block-lg">
                                        <div class="nk-block-head">
                                            <div class="nk-block-head-content">
                                                <h4 class="nk-block-title">{{!empty($title)?$title:''}}</h4>
                                                @if($categories->parent_id == '' || $categories->parent->parent=='')
                                                <a href="#" data-toggle="modal" data-target="#add-sub-cat-popup-modal" class="btn btn-primary">+ إضافة قسم فرعي</a>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="card card-preview">
                                            <div class="card-inner">
                                                <div class="table-responsive">
                                                    <table class="table table-orders nowrap nk-tb-list is-separate">
                                                        <thead>
                                                            <tr>
                                                                <th>{{trans('admin.record_id')}}</th>
                                                                <th>{{trans('admin.image')}}</th>
                                                                <th>{{trans('admin.name_ar')}}</th>
                                                                <th>{{trans('admin.name_en')}}</th>
                                                                <th>{{trans('admin.created_at')}}</th>
                                                                <th>{{trans('admin.action')}}</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            @foreach(\App\Models\Category::where('parent_id', $categories->id)->get() as $category)
                                                            <tr>
                                                                <td>{{$category->id}}</td>
                                                                <td>
                                                                    @include('admin.show_image',['image'=>$category->image])
                                                                </td>
                                                                <td>{{$category->name_ar}}</td>
                                                                <td>{{$category->name_en}}</td>
                                                                <td>{{$category->created_at}}</td>
                                                                <td class="tb-odr-action">
                                                                    @include('admin.categories.buttons.actions', ['id' => $category->id])
                                                                </td>
                                                            </tr>
                                                            @endforeach
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div><!-- .card-preview -->
                                    </div> <!-- nk-block -->
                                </div><!-- .components-preview -->
                            </div>
                        </div>
                    </div>
                </div>



    <div class="modal fade" id="add-sub-cat-popup-modal" dir="rtl" style="text-align: right;">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-12">
                                <h4 style="color: rgba(96,96,96,0.68)">
                                    <i class="tio-shopping-cart-outlined"></i> إضافة قسم فرعي
                                </h4>
                                <hr>
                                    {!! Form::open(['url'=>aurl('categories'),'id'=>'categories','files'=>true,'class'=>'form-horizontal form-row-seperated']) !!}
                                        <input type="hidden" name="parent_id" value="{{$categories->id}}">
                                        <div class="preview-block">
                                            <div class="row gy-4">
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        {!! Form::label('name_ar',trans('admin.name_ar'),['class'=>' control-label']) !!}
                                                        <div class="form-control-wrap">
                                                            {!! Form::text('name_ar',old('name_ar'),['class'=>'form-control','placeholder'=>trans('admin.name_ar')]) !!}
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        {!! Form::label('name_en',trans('admin.name_en'),['class'=>' control-label']) !!}
                                                        <div class="form-control-wrap">
                                                            {!! Form::text('name_en',old('name_en'),['class'=>'form-control','placeholder'=>trans('admin.name_en')]) !!}
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row gy-4">
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <label class="form-label" for="default-06">الصورة</label>
                                                        <div class="form-control-wrap">
                                                            <div class="custom-file">
                                                                <input type="file" name="image" class="custom-file-input" id="customFile">
                                                                <label class="custom-file-label" for="customFile">اختر الصورة</label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row g-3">
                                                <div class="col-lg-7 offset-lg-5">
                                                    <div class="form-group mt-2">
                                                        <button type="submit" name="add" class="btn btn-lg btn-primary">إضافة</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        {!! Form::close() !!}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection
