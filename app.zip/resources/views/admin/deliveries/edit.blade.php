@extends('admin.layouts.master')
@section('content')

	<div class="nk-content ">
		<div class="container-fluid">
			<div class="nk-content-inner">
				<div class="nk-content-body">
					<div class="components-preview wide-md mx-auto">
						<div class="nk-block nk-block-lg">
							<div class="nk-block-head">
								<div class="nk-block-head-content">
									<h4 class="title nk-block-title">{{ !empty($title)?$title:'' }}</h4>
								</div>
							</div>
							<div class="card card-preview">

								<div class="card-inner">
                								{!! Form::open(['url'=>url(request()->segment('1').'/deliveries/'.$deliveries->id),'method'=>'put','id'=>'deliveries','files'=>true,'class'=>'form-horizontal form-row-seperated']) !!}

                                                    <div class="nk-wizard-head">
                                                        <h5>المعلومات الشخصية</h5>
                                                    </div>
                                                    <div class="nk-wizard-content">
                                                        <div class="row gy-3">
                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                    <label class="form-label" for="name">الاسم بالكامل</label>
                                                                    <div class="form-control-wrap">
                														{!! Form::text('name', $deliveries->name ,['class'=>'form-control','placeholder'=>trans('admin.name')]) !!}
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                    <label class="form-label" for="mobile">رقم الجوال</label>
                                                                    <div class="form-control-wrap">
                                                                        {!! Form::text('mobile', $deliveries->mobile ,['class'=>'form-control','placeholder'=>trans('admin.mobile')]) !!}
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="nk-wizard-content">
                                                        <div class="row gy-3">
                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                <label class="form-label" for="national_id">رقم الهوية</label>
                                                                    <div class="form-control-wrap">
                                                                    {!! Form::text('national_id', $deliveries->national_id ,['class'=>'form-control','placeholder'=>'رقم الهوية']) !!}
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                    <label class="form-label" for="password">Password</label>
                                                                    <div class="form-control-wrap">
                                                                        <input type="password" data-msg="Required" class="form-control required" id="password" name="password">
                                                                    </div>
                                                                </div>
                                                            </div><!-- .col -->
                                                        </div>
                                                    </div>
                                                    <div class="nk-wizard-content">
                                                        <div class="row gy-3">
                                                            <div class="col-md-4">
                                                                <div class="form-group">
                                                                <label class="form-label" for="car_id">نوع المركبة</label>
                                                                    <div class="form-control-wrap">
                                                                        <select class="form-control" name="car_id" id="car_id">
                                                                            <option value="" disabled>اختر نوع المركبة</option>
                                                                            @foreach(\App\Models\Car::get() as $car)
                                                                            <option value="{{$car->id}}" @if($deliveries->car_id==$car->id) selected @endif>{{$car->name_ar}}</option>
                                                                            @endforeach
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-4">
                                                                <div class="form-group">
                                                                    <label class="form-label" for="plate_number">رقم اللوحة</label>
                                                                    <div class="form-control-wrap">
                                                                    {!! Form::text('plate_number', $deliveries->plate_number ,['class'=>'form-control','placeholder'=>'رقم اللوحة']) !!}
                                                                    </div>
                                                                </div>
                                                            </div><!-- .col -->
                                                            <div class="col-md-4">
                                                                <div class="form-group">
                                                                    <label class="form-label" for="car_color">اللون</label>
                                                                    <div class="form-control-wrap">
                                                                    {!! Form::text('car_color', $deliveries->car_color ,['class'=>'form-control','placeholder'=>'اللون']) !!}
                                                                    </div>
                                                                </div>
                                                            </div><!-- .col -->
                                                        </div>
                                                    </div>
                                                    <div class="nk-wizard-content">
                                                        <div class="row gy-3">
                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                    <label for="status">{{trans('admin.otp_status')}}</label>
                                                                    <div class="form-control-wrap">
                                                                        <select class="form-control" name="status" id="status">
                                                                            <option value="" disabled>اختر الحالة</option>
                                                                            <option value="1" @if($deliveries->status=='1') selected @endif>{{trans('admin.active')}}</option>
                                                                            <option value="0" @if($deliveries->status=='0') selected @endif>{{trans('admin.in-active')}}</option>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                            </div><!-- .col -->
                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                    <label for="status">{{trans('admin.approved_status')}}</label>
                                                                    <div class="form-control-wrap">
                                                                        <select class="form-control" name="approved" id="approved">
                                                                            <option value="" disabled>اختر</option>
                                                                            <option value="1" @if($deliveries->approved=='1') selected @endif>{{trans('admin.active')}}</option>
                                                                            <option value="0" @if($deliveries->approved=='0') selected @endif>{{trans('admin.pending')}}</option>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                            </div><!-- .col -->
                                                        </div><!-- .row -->
                                                        <div class="row gy-3">
                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                    <button type="submit" class="btn btn-primary">{{ trans('admin.save') }}</button>
                                                                </div>
                                                            </div>
                                                        </div><!-- .row -->
                                                    </div>
                                                </form>
								</div>
							</div><!-- .card-preview -->
						</div><!-- .nk-block -->
					</div><!-- .components-preview -->
				</div>
			</div>
		</div>
	</div>
@endsection
