	<div class="card-inner card-inner-lg">
		<div class="nk-block-head nk-block-head-lg">
			<div class="nk-block-between">
				<div class="nk-block-head-content">
					<h4 class="nk-block-title">عميات السحب</h4>
				</div>
				<div class="nk-block-head-content align-self-start d-lg-none">
					<a href="#" class="toggle btn btn-icon btn-trigger mt-n1" data-target="userAside"><em class="icon ni ni-menu-alt-r"></em></a>
				</div>
			</div>
		</div><!-- .nk-block-head -->
		<div class="nk-block card card-bordered">
			<table class="table table-ulogs">
				<thead class="thead-light">
					<tr>
						<th class="tb-col-os"><span class="overline-title">ID</span></span></th>
						<th class="tb-col-ip"><span class="overline-title">القيمة</span></th>
						<th class="tb-col-ip"><span class="overline-title">الحالة</span></th>
						<th class="tb-col-time"><span class="overline-title">التاريخ</span></th>
					</tr>
				</thead>
				<tbody>
					@foreach($transactions as $trans)
					<tr>
						<td class="tb-col-os">{{$trans->id}}</td>
						<td class="tb-col-ip"><span class="sub-text">{{$trans->amount}}</span></td>
						<td class="tb-col-ip"><span class="sub-text">{{$trans->status}}</span></td>
						<td class="tb-col-time"><span class="sub-text">{{$trans->created_at}}</span></td>
					</tr>
					@endforeach
				</tbody>
			</table>
		</div><!-- .nk-block-head -->
	</div><!-- .card-inner -->
