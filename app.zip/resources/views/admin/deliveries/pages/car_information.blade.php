	<div class="card-inner card-inner-lg">
		<div class="nk-block-head nk-block-head-lg">
			<div class="nk-block-between">
				<div class="nk-block-head-content">
					<h4 class="nk-block-title">معلومات السيارة</h4>
				</div>
				<div class="nk-block-head-content align-self-start d-lg-none">
					<a href="#" class="toggle btn btn-icon btn-trigger mt-n1" data-target="userAside"><em class="icon ni ni-menu-alt-r"></em></a>
				</div>
			</div>
		</div><!-- .nk-block-head -->
		<div class="nk-block">
			<div class="nk-data data-list">
				<div class="data-head">
					<h6 class="overline-title">Basics</h6>
				</div>
				<div class="data-item">
					<div class="data-col">
						<span class="data-label">نوع السيارة</span>
						<span class="data-value">{{$deliveries->car->name_ar ?? ''}}</span>
					</div>
					
				</div><!-- data-item -->
				<div class="data-item">
					<div class="data-col">
						<span class="data-label">رقم اللوحة</span>
						<span class="data-value">{{$deliveries->plate_number}}</span>
					</div>
					
				</div><!-- data-item -->
				<div class="data-item">
					<div class="data-col">
						<span class="data-label">اللون</span>
						<span class="data-value">{{$deliveries->car_color}}</span>
					</div>
				</div><!-- data-item -->
			</div><!-- data-list -->
			<div class="nk-data data-list">
				<div class="data-head">
					<h6 class="overline-title">المستندات</h6>
				</div>
				<div class="data-item">
					<div class="data-col">
						<span class="data-label">صورة الرخصة</span>
						<span class="data-value">@include('admin.show_image',['image'=>$deliveries->licence_image])</span>
					</div>
				</div><!-- data-item -->
				<div class="data-item">
					<div class="data-col">
						<span class="data-label">صورة استمارة السيارة</span>
						<span class="data-value">@include('admin.show_image',['image'=>$deliveries->car_form_image])</span>
					</div>
				</div><!-- data-item -->
				<div class="data-item">
					<div class="data-col">
						<span class="data-label">صورة السيارة من الأمام</span>
						<span class="data-value">@include('admin.show_image',['image'=>$deliveries->car_front_image])</span>
					</div>
				</div><!-- data-item -->
				<div class="data-item">
					<div class="data-col">
						<span class="data-label">صورة السيارة من الخلف</span>
						<span class="data-value">@include('admin.show_image',['image'=>$deliveries->car_back_image])</span>
					</div>
				</div><!-- data-item -->
				<div class="data-item">
					<div class="data-col">
						<span class="data-label">صورة رخصة النقل</span>
						<span class="data-value">@include('admin.show_image',['image'=>$deliveries->transport_license_image])</span>
					</div>
				</div><!-- data-item -->
			</div><!-- data-list -->
		</div><!-- .nk-block -->
	</div>
