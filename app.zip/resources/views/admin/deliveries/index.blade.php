@extends('admin.layouts.master')
@section('content')

                <div class="nk-content ">
                    <div class="container-fluid">
                        <div class="nk-content-inner">
                            <div class="nk-content-body">
                                <div class="components-preview wide-md mx-auto">
                                    <div class="nk-block-head nk-block-head-lg wide-sm">
                                        <div class="nk-block-head-content">
											&nbsp;
										</div>
                                    </div><!-- .nk-block-head -->
                                    <div class="nk-block nk-block-lg">
                                        <div class="nk-block-head">
                                            <div class="nk-block-head-content">
                                                <h4 class="nk-block-title">{{!empty($title)?$title:''}}</h4>
                                            </div>
                                        </div>
                                        <div class="card card-preview">
                                            <div class="card-inner">
                                                <div class="table-responsive">
                                                    <table class="table table-orders nowrap nk-tb-list is-separate">
                                                        <thead>
                                                            <tr>
                                                                <th>{{trans('admin.record_id')}}</th>
                                                                <th>{{trans('admin.image')}}</th>
                                                                <th>{{trans('admin.name')}}</th>
                                                                <th>{{trans('admin.mobile')}}</th>
                                                                <th>الفرع</th>
                                                                <th>نوع المركبة</th>
                                                                <th>حالة ال OTP</th>
                                                                <th>{{trans('admin.approved_status')}}</th>
                                                                <th>رصيد المعاملات</th>
                                                                <th>{{trans('admin.created_at')}}</th>
                                                                <th>{{trans('admin.action')}}</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            @foreach($deliveries as $delivery)
                                                            <tr>
                                                                <td>{{$delivery->id}}</td>
                                                                <td>
                                                                    @include('admin.show_image',['image'=>$delivery->photo_profile])
                                                                </td>
                                                                <td>{{$delivery->name}}</td>
                                                                <td>{{$delivery->mobile}}</td>
                                                                <td>{{$delivery->branch->branch->name??''}}</td>
                                                                <td>{{$delivery->car->name_ar??''}}</td>
                                                                <td>
                                                                    @if($delivery->status==1)
                                                                    <span class="tb-status text-success">{{trans('admin.active')}}</span>
                                                                    @else
                                                                    <span class="tb-status text-warning">{{trans('admin.in-active')}}</span>
                                                                    @endif
                                                                </td>
                                                                <td>
                                                                    @if($delivery->approved==1)
                                                                    <span class="tb-status text-success">{{trans('admin.active')}}</span>
                                                                    @else
                                                                    <span class="tb-status text-warning">{{trans('admin.pending')}}</span>
                                                                    @endif
                                                                </td>
                                                                <td>{{ $delivery->wallet_balance?? 0 }} ريال</td>
                                                                <td>{{$delivery->created_at}}</td>
                                                                <td class="tb-odr-action">
                                                                    @include('admin.deliveries.buttons.actions', ['id' => $delivery->id])
                                                                </td>
                                                            </tr>
                                                            @endforeach
                                                        </tbody>
                                                    </table>
                                                </div>
                                                <div>{{ $deliveries->links() }}</div>
                                            </div>
                                        </div><!-- .card-preview -->
                                    </div> <!-- nk-block -->
                                </div><!-- .components-preview -->
                            </div>
                        </div>
                    </div>
                </div>

@endsection
