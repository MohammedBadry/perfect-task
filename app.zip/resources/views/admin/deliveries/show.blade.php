@extends('admin.layouts.master')
@section('content')

                <!-- content @s -->
                <div class="nk-content ">
                    <div class="container-fluid">
                        <div class="nk-content-inner">
                            <div class="nk-content-body">
                                <div class="nk-block">
                                    <div class="card card-bordered">
                                        <div class="card-aside-wrap">

                                            @if(request()->get('page') && request()->get('page')!='')
                                                @include('admin.deliveries.pages.'.request()->get('page'))
                                                <input type="hidden" name="page" value="{{request()->get('page')}}">
                                            @else
                                                @include('admin.deliveries.pages.personal_information')
                                            @endif

                                            <div class="card-aside card-aside-left user-aside toggle-slide toggle-slide-left toggle-break-lg" data-content="userAside" data-toggle-screen="lg" data-toggle-overlay="true">
                                                <div class="card-inner-group">
                                                    <div class="card-inner">
                                                        <div class="user-card">
                                                            <div class="user-avatar bg-primary">
                                                                @if($deliveries->photo_profile)
                                                                <img src="{{it()->url($deliveries->photo_profile)}}" alt="">
                                                                @else
                                                                <span>NI</span>
                                                                @endif
                                                            </div>
                                                            <div class="user-info">
                                                                <h4>{{$deliveries->name}}</h4>
                                                                <span class="sub-text">{{$deliveries->mobile}}</span>
                                                            </div>
                                                        </div><!-- .user-card -->
                                                    </div><!-- .card-inner -->
                                                    <div class="card-inner">
                                                        <div class="user-account-info py-0">
                                                            <h6 class="overline-title-alt">رصيد الحساب</h6>
                                                            <div class="user-balance">{{$deliveries->wallet_balance??0}} <small class="currency currency-btc">ريال</small></div>
                                                        </div>
                                                    </div><!-- .card-inner -->
                                                    <div class="card-inner p-0">
                                                        <ul class="link-list-menu">
                                                            <li><a href="{{url(request()->segment(1).'/deliveries/'.$deliveries->id)}}" @if(request()->get('page')=='') class="active" @endif><em class="icon ni ni-user-fill-c"></em><span>المعلومات الشخصية</span></a></li>
                                                            <li><a href="{{url(request()->segment(1).'/deliveries/'.$deliveries->id)}}/?page=car_information" @if(request()->get('page')=='car_information') class="active" @endif><em class="icon ni ni-bell-fill"></em><span>معلومات السيارة</span></a></li>
                                                            <li><a href="{{url(request()->segment(1).'/deliveries/'.$deliveries->id)}}/?page=orders" @if(request()->get('page')=='orders') class="active" @endif><em class="icon ni ni-activity-round-fill"></em><span>الطلبات</span></a></li>
                                                            <li><a href="{{url(request()->segment(1).'/deliveries/'.$deliveries->id)}}/?page=transactions" @if(request()->get('page')=='transactions') class="active" @endif><em class="icon ni ni-lock-alt-fill"></em><span>العمليات</span></a></li>
                                                        </ul>
                                                    </div><!-- .card-inner -->
                                                </div><!-- .card-inner-group -->
                                            </div><!-- card-aside -->
                                        </div><!-- card-aside-wrap -->
                                    </div><!-- .card -->
                                </div><!-- .nk-block -->
                            </div>
                        </div>
                    </div>
                </div>
                <!-- content @e -->

@endsection
