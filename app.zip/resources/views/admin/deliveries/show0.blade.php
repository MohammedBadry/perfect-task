@extends('admin.layouts.master')
@section('content')

	<div class="nk-content ">
		<div class="container-fluid">
			<div class="nk-content-inner">
				<div class="nk-content-body">
					<div class="components-preview wide-md mx-auto">
						<div class="nk-block nk-block-lg">
							<div class="nk-block-head">
								<div class="nk-block-head-content">
									<h4 class="title nk-block-title no-print">{{!empty($title)?$title:''}}</h4>
								</div>
							</div>
                                <section class="content">
                                    <div class="container-fluid">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="card card-info">
                                                    <div class="card-body">
                                                        <table class="table">
                                                            <tr>
                                                                <th style="width: 20%">ID</th>
                                                                <td>{{$deliveries->id}}</td>
                                                            </tr>
                                                            <tr>
                                                                <th style="width: 20%">الصورة الشخصية</th>
                                                                <td>
                                                                    @include('admin.show_image',['image'=>$deliveries->photo_profile])
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <th style="width: 20%">الاسم</th>
                                                                <td>{{$deliveries->name}}</td>
                                                            </tr>
                                                            <tr>
                                                                <th style="width: 20%">الجوال</th>
                                                                <td>{{$deliveries->mobile}}</td>
                                                            </tr>
                                                            <tr>
                                                                <th style="width: 20%">الرقم الوطني</th>
                                                                <td>{{$deliveries->national_id}}</td>
                                                            </tr>
                                                            <tr>
                                                                <th style="width: 20%">صورة الرقم الوطني</th>
                                                                <td>
                                                                    @include('admin.show_image',['image'=>$deliveries->nid_image])
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <th style="width: 20%">نوع السيارة</th>
                                                                <td>{{$deliveries->car->name_ar ?? ''}}</td>
                                                            </tr>
                                                            <tr>
                                                                <th style="width: 20%">رقم اللوحة</th>
                                                                <td>{{$deliveries->plate_number}}</td>
                                                            </tr>
                                                            <tr>
                                                                <th style="width: 20%">اللون</th>
                                                                <td>{{$deliveries->car_color}}</td>
                                                            </tr>
                                                            <tr>
                                                                <th style="width: 20%">صورة الرخصة</th>
                                                                <td>
                                                                    @include('admin.show_image',['image'=>$deliveries->licence_image])
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <th style="width: 20%">صورة استمارة السيارة</th>
                                                                <td>
                                                                    @include('admin.show_image',['image'=>$deliveries->car_form_image])
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <th style="width: 20%">صورة السيارة من الأمام</th>
                                                                <td>
                                                                    @include('admin.show_image',['image'=>$deliveries->car_front_image])
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <th style="width: 20%">صورة السيارة من الخلف</th>
                                                                <td>
                                                                    @include('admin.show_image',['image'=>$deliveries->car_back_image])
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <th style="width: 20%">صورة رخصة النقل</th>
                                                                <td>
                                                                    @include('admin.show_image',['image'=>$deliveries->transport_license_image])
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <th style="width: 20%">{{trans('admin.otp_status')}}</th>
                                                                <td>
                                                                    @if($deliveries->status=='1')
                                                                    <span class="tb-status text-success">{{trans('admin.active')}}</span>
                                                                    @else
                                                                    <span class="tb-status text-warning">{{trans('admin.in-active')}}</span>
                                                                     @endif
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <th style="width: 20%">{{trans('admin.approved_status')}}</th>
                                                                <td>
                                                                    @if($deliveries->approved=='1')
                                                                    <span class="tb-status text-success">{{trans('admin.active')}}</span>
                                                                    @else
                                                                    <span class="tb-status text-warning">{{trans('admin.in-active')}}</span>
                                                                     @endif
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <th style="width: 20%">الرصيد الحالي</th>
                                                                <td>{{ $deliveries->wallet_balance?? 0 }} ريال</td>
                                                            </tr>
                                                        </table>
                                                    </div>
                                                </div>
                                                <!--/.card-->
                                            </div>
                                            <!--/.col-md-12-->
                                        </div>
                                        <!-- /.row -->
                                    </div><!-- /.container-fluid -->
                                </section>

						</div><!-- .nk-block -->
					</div><!-- .components-preview -->
				</div>
			</div>
		</div>
	</div>
@endsection
