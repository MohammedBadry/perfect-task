@extends('admin.layouts.master')
@section('content')

	<div class="nk-content ">
		<div class="container-fluid">
			<div class="nk-content-inner">
				<div class="nk-content-body">
					<div class="components-preview wide-md mx-auto">
						<div class="nk-block nk-block-lg">
							<div class="nk-block-head">
								<div class="nk-block-head-content">
									<h4 class="title nk-block-title no-print">{{!empty($title)?$title:''}}</h4>
								</div>
							</div>
                                <section class="content">
                                    <div class="container-fluid">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="card card-info">
                                                    <div class="card-body">
                                                        <table class="table">
                                                            <tr>
                                                                <th style="width: 20%">ID</th>
                                                                <td>{{$tickets->id}}</td>
                                                            </tr>
                                                            <tr>
                                                                <th style="width: 20%">اسم المستخدم</th>
                                                                <td>{{$tickets->user->name??''}}</td>

                                                            </tr>
                                                            <tr>
                                                                <th style="width: 20%">الجوال</th>
                                                                <td>{{$tickets->user->mobile??''}}</td>

                                                            </tr>
                                                            <tr>
                                                                <th style="width: 20%">الإيميل</th>
                                                                <td>{{$tickets->user->email??''}}</td>

                                                            </tr>
                                                            <tr>
                                                                <th style="width: 20%">عنوان الرسالة</th>
                                                                <td dir="ltr">
                                                                    {{$tickets->subject}}
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <th style="width: 20%">التفاصيل</th>
                                                                <td dir="ltr">
                                                                    {{$tickets->message}}
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </div>
                                                </div>
                                                <!--/.card-->
                                            </div>
                                            <!--/.col-md-12-->
                                        </div>
                                        <!-- /.row -->
                                    </div><!-- /.container-fluid -->
                                </section>

						</div><!-- .nk-block -->
					</div><!-- .components-preview -->
				</div>
			</div>
		</div>
	</div>
@endsection
