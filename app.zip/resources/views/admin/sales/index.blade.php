@extends('admin.layouts.master')
@section('content')

                <div class="nk-content ">
                    <div class="container-fluid">
                        <div class="nk-content-inner">
                            <div class="nk-content-body">
                                <div class="components-preview wide-md mx-auto">
                                    <div class="nk-block-head nk-block-head-lg wide-sm">
                                        <div class="nk-block-head-content">
                                            <h4 class="nk-block-title">المبيعات</h4>
                                                <a href="#" data-toggle="modal" data-target="#importSales" class="btn btn-primary">استيراد المبيعات</a>
										</div>
                                    </div><!-- .nk-block-head -->

                                    <div class="nk-block nk-block-lg">
                                        <div class="row g-gs">
                                            <div class="col-xxl-3 col-sm-3">
                                                <div class="card">
                                                    <div class="nk-ecwg nk-ecwg6">
                                                        <div class="card-inner">
                                                            <div class="card-title-group">
                                                                <div class="card-title">
                                                                    <h6 class="title">عدد الطلبات</h6>
                                                                </div>
                                                            </div>
                                                            <div class="data">
                                                                <div class="data-group">
                                                                    <div class="amount" style="font-size: 16px">{{$salesCount}}</div>
                                                                </div>
                                                                <div class="info"><span class="change up text-danger"><em class="icon ni ni-arrow-long-up"></em>4.63%</span><span> vs. last week</span></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-xxl-3 col-sm-3">
                                                <div class="card">
                                                    <div class="nk-ecwg nk-ecwg6">
                                                        <div class="card-inner">
                                                            <div class="card-title-group">
                                                                <div class="card-title">
                                                                    <h6 class="title">المبيعات</h6>
                                                                </div>
                                                            </div>
                                                            <div class="data">
                                                                <div class="data-group">
                                                                    <div class="amount" style="font-size: 16px">{{$subTotal}} </div>
                                                                </div>
                                                                <div class="info"><span class="change up text-danger"><em class="icon ni ni-arrow-long-up"></em>4.63%</span><span> vs. last week</span></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-xxl-3 col-sm-3">
                                                <div class="card">
                                                    <div class="nk-ecwg nk-ecwg6">
                                                        <div class="card-inner">
                                                            <div class="card-title-group">
                                                                <div class="card-title">
                                                                    <h6 class="title">الضرائب</h6>
                                                                </div>
                                                            </div>
                                                            <div class="data">
                                                                <div class="data-group">
                                                                    <div class="amount" style="font-size: 16px">{{$taxes}} </div>
                                                                </div>
                                                                <div class="info"><span class="change up text-danger"><em class="icon ni ni-arrow-long-up"></em>4.63%</span><span> vs. last week</span></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-xxl-3 col-sm-3">
                                                <div class="card">
                                                    <div class="nk-ecwg nk-ecwg6">
                                                        <div class="card-inner">
                                                            <div class="card-title-group">
                                                                <div class="card-title">
                                                                    <h6 class="title">الإجمالي</h6>
                                                                </div>
                                                            </div>
                                                            <div class="data">
                                                                <div class="data-group">
                                                                    <div class="amount" style="font-size: 16px">{{$total}} </div>
                                                                </div>
                                                                <div class="info">
                                                                    
                                                                        <span class="change down text-danger"><em class="icon ni ni-arrow-long-down"></em>2.34%</span><span> vs. last week</span>
                                                                    
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="nk-block nk-block-lg">
                                        <div class="card card-preview">
                                            <div class="row">
                                                <form action="{{aurl('sales')}}" method="get">
                                                    <input type="hidden" name="due" value="{{request()->get('due')}}">
                                                    <div class="card-inner">
                                                        <div class="preview-block">
                                                            <div class="row gy-4">
                                                                <div class="col-sm-4">
                                                                    <div class="form-group mt-2">
                                                                        <div class="form-control-wrap">
                                                                            <input type="text" name="name" value="{{request()->get('name')}}" placeholder="اسم العميل" class="form-control">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-3">
                                                                    <div class="form-group mt-2">
                                                                        <div class="form-control-wrap">
                                                                            <input type="date" name="from" value="{{request()->get('from')}}" title="من" class="form-control">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-3">
                                                                    <div class="form-group mt-2">
                                                                        <div class="form-control-wrap">
                                                                            <input type="date" name="to" value="{{request()->get('to')}}" title="إلى" class="form-control">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-2">
                                                                    <div class="form-group mt-2">
                                                                        <button type="submit" class="btn btn-primary">بحث</button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                            <div class="card-inner">
                                                <div class="table-responsive">
                                                    <table class="table table-orders nowrap nk-tb-list is-separate">
                                                        <thead>
                                                            <tr>
                                                                <th>{{trans('admin.record_id')}}</th>
                                                                <th>العميل</th>
                                                                <th>الإجمالي الفرعي</th>
                                                                <th>الضريبة</th>
                                                                <th>الإجمالي</th>
                                                                <th>التاريخ</th>
                                                                <th>{{trans('admin.action')}}</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            @foreach($sales as $sale)
                                                            <tr>
                                                                <td>{{$sale->id}}</td>
                                                                <td>{{$sale->user->name}}</td>
                                                                <td>{{$sale->sub_total}}</td>
                                                                <td>{{$sale->tax_value}}</td>
                                                                <td>{{$sale->total}}</td>
                                                                <td>{{$sale->date}}</td>
                                                                <td class="tb-odr-action">
                                                                    @include('admin.sales.buttons.actions', ['id' => $sale->id])
                                                                </td>
                                                            </tr>
                                                            @endforeach
                                                        </tbody>
                                                    </table>
                                                </div>
                                                <div>{{ $sales->links() }}</div>
                                            </div>
                                        </div><!-- .card-preview -->
                                    </div> <!-- nk-block -->
                                </div><!-- .components-preview -->
                            </div>
                        </div>
                    </div>
                </div>

                    <div class="modal fade" id="importSales">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h4 class="modal-title">استيراد الفواتير</h4>
                                    <button class="close" data-dismiss="modal">x</button>
                                </div>
                                {!! Form::open(['url'=>route('admin.sales.import'),'files'=>true,'class'=>'form-horizontal form-row-seperated']) !!}
                                <div class="modal-body">
                                    <div class="preview-block">
                                        <div class="row gy-4">
                                            <div class="col-sm-12">
                                                <div class="form-group">
                                                    <label class="form-label" for="default-06">الملف</label>
                                                    <div class="form-control-wrap">
                                                        <div class="custom-file">
                                                            <input type="file" name="excel_file" class="custom-file-input" id="customFile">
                                                            <label class="custom-file-label" for="customFile">اختر الملف</label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    {!! Form::submit('إضافة', ['class' => 'btn btn-primary btn-flat']) !!}
                                    <a class="btn btn-default btn-flat" data-dismiss="modal">{{trans('admin.cancel')}}</a>
                                </div>
                                {!! Form::close() !!}
                            </div>
                        </div>
                    </div>

@endsection
