@extends('admin.layouts.master')
@section('content')

	<div class="nk-content ">
		<div class="container-fluid">
			<div class="nk-content-inner">
				<div class="nk-content-body">
					<div class="components-preview wide-md mx-auto">
						<div class="nk-block nk-block-lg">
							<div class="nk-block-head">
								<div class="nk-block-head-content">
									<h4 class="title nk-block-title">إضافة مبيعة</h4>
								</div>
							</div>
							<div class="card card-preview">

								<div class="card-inner">
                                    {!! Form::open(['url'=>aurl('sales'),'id'=>'sales','files'=>true,'class'=>'form-horizontal form-row-seperated']) !!}
									<input type="hidden" name="user_id" value="{{$user->id}}" required>
									<div class="preview-block">
										<div class="row gy-4" style="border: 0px dashed #333">
											<div class="col-sm-12">
                                                <label class="form-label" for="default-06">المنتجات</label>
                                                <button type="button" id="rowAdder" class="btn btn-primary"><em class="icon ni ni-plus-sm"></em></button>
                                            </div>
											<div id="newinput" class="col-sm-12">
												<div class="row gy-4">
													<div class="col-sm-3">
														<div class="form-group">
															<label class="form-label" for="default-06">المنتج</label>
															<div class="form-control-wrap">
																<select name="product_id[]" class="form-control" required>
																	<option value="">اختر المنتج</option>
																	@foreach(\App\Models\Product::get() as $product)
																	<option value="{{$product->id}}">{{$product->name_ar}}</option>
																	@endforeach
																</select>
															</div>
														</div>
													</div>
													<div class="col-sm-3">
														<div class="form-group">
															<label class="form-label" for="default-06">السعر</label>
															<div class="form-control-wrap">
																<input type="text" class="form-control" name="price[]" value="" required>
															</div>
														</div>
													</div>
													<div class="col-sm-3">
														<div class="form-group">
															<label class="form-label" for="default-06">الكمية</label>
															<div class="form-control-wrap">
																<input type="text" class="form-control" name="quantity[]" value="" required>
															</div>
														</div>
													</div>
												</div>
    										</div>
											<div class="row gy-4">
												<div class="col-sm-6">
													<div class="form-group">
														<label class="form-label" for="default-06">الضريبة (بالريال)</label>
														<div class="form-control-wrap">
															<input type="text" class="form-control" name="tax_value" value="0" required>
														</div>
													</div>
												</div>
												<div class="col-sm-6">
													<div class="form-group">
														<label class="form-label" for="default-06">التاريخ</label>
														<div class="form-control-wrap">
															<input type="date" class="form-control" name="date" value="" required>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="row g-3">
											<div class="col-lg-7 offset-lg-5">
												<div class="form-group mt-2">
													<button type="submit" name="add" class="btn btn-lg btn-primary">إضافة</button>
												</div>
											</div>
										</div>
									</div>
									{!! Form::close() !!}

								</div>
							</div><!-- .card-preview -->
						</div><!-- .nk-block -->
					</div><!-- .components-preview -->
				</div>
			</div>
		</div>
	</div>
@endsection

@push('js')
<script>

$(document).ready(function() {

    $("#rowAdder").click(function () {
        newRowAdd =
        '<div class="row gy-4">' +
            '<div class="col-sm-3">' +
                '<div class="form-group">' +
                    '<label class="form-label" for="default-06">المنتج</label>' +
                    '<div class="form-control-wrap">' +
						'<select name="product_id[]" class="form-control" required>'+
							'<option value="">اختر المنتج</option>'+
							<?php
							foreach(\App\Models\Product::get() as $product) {
							?>
							'<option value="<?=$product->id; ?>"><?=$product->name_ar; ?></option>'+
							<?php } ?>
						'</select>'+
                    '</div>' +
                '</div>' +
            '</div>' +
            '<div class="col-sm-3">' +
                '<div class="form-group">' +
                    '<label class="form-label" for="default-06">السعر</label>' +
                    '<div class="form-control-wrap">' +
                        '<input type="text" class="form-control" name="price[]" value="" required>' +
                    '</div>' +
                '</div>' +
            '</div>' +
            '<div class="col-sm-3">' +
                '<div class="form-group">' +
                    '<label class="form-label" for="default-06">الكمية</label>' +
                    '<div class="form-control-wrap">' +
                        '<input type="text" class="form-control" name="quantity[]" value="" required>' +
                    '</div>' +
                '</div>' +
            '</div>' +
            '<div class="col-sm-2">' +
                '<div class="form-group">' +
                    '<label class="form-label" for="default-06">&nbsp;</label>' +
                    '<div class="form-control-wrap">' +
                        '<a href="javascript:;" id="DeleteRow" class="text-danger"><em class="icon ni ni-trash-alt"></em></a>'+
                    '</div>' +
                '</div>' +
            '</div>' +
        '</div>';


        $('#newinput').append(newRowAdd);
    });

    $("body").on("click", "#DeleteRow", function () {
        $(this).parents("#row").remove();
    });
});
</script>
@endpush
