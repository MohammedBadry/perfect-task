@extends('admin.layouts.master')
@section('content')

	<div class="nk-content ">
		<div class="container-fluid">
			<div class="nk-content-inner">
				<div class="nk-content-body">
					<div class="components-preview wide-md mx-auto">
						<div class="nk-block nk-block-lg">
							<div class="nk-block-head">
								<div class="nk-block-head-content">
									<h4 class="title nk-block-title">تفاصيل المبيعة</h4>
								</div>
							</div>
                                <section class="content">
                                    <div class="container-fluid">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="card card-info">
                                                    <div class="card-body">
                                                        <table class="table">
                                                            <tr>
                                                                <th class="w-10px">ID</th>
                                                                <td>{{$sale->id}}</td>
                                                            </tr>
                                                            <tr>
                                                                <th class="w-10px">العميل</th>
                                                                <td>{{$sale->user->name}}</td>
                                                            </tr>
                                                            <tr>
                                                                <th class="w-10px">المنتجات</th>
                                                                <td>
                                                                    <div class="container-fluid row">
                                                                    @foreach ($sale->items as $item)
                                                                        <div class="  card col-md-3 col-sm-12 p-3 mb-2 bg-white rounded m-1 grow">
                                                                            <div><span class="text-bold">المنتج : </span><small>{{$item->product->name_ar }} </small></div>
                                                                            <div><span class="text-bold">السعر : </span><small>{{$item->price }} </small></div>
                                                                            <div><span class="text-bold">الكمية : </span><small>{{$item->quantity }} </small></div>
                                                                            <div><span class="text-bold">المجموع : </span><small>{{$item->total }} </small></div>
                                                                        </div>
                                                                        @endforeach
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <th class="w-10px">الإجمالي</th>
                                                                <td>{{$sale->sale_total()}}</td>
                                                            </tr>
                                                        </table>
                                                    </div>
                                                </div>
                                                <!--/.card-->
                                            </div>
                                            <!--/.col-md-12-->
                                        </div>
                                        <!-- /.row -->
                                    </div><!-- /.container-fluid -->
                                </section>

						</div><!-- .nk-block -->
					</div><!-- .components-preview -->
				</div>
			</div>
		</div>
	</div>
@endsection
