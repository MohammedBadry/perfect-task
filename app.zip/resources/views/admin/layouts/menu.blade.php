  <!-- sidebar @s -->
  <div class="nk-sidebar nk-sidebar-fixed is-light " data-content="sidebarMenu">
      <div class="nk-sidebar-element nk-sidebar-head">
          <div class="nk-sidebar-brand">
              <a href="{{url(request()->segment('1').'/dashboard')}}" class="logo-link nk-sidebar-logo">
                    <img class="logo-light logo-img" src="{{ it()->url(setting()->logo) }}" srcset="{{ it()->url(setting()->logo) }}" alt="logo">
                    <img class="logo-dark logo-img" src="{{ it()->url(setting()->logo) }}" srcset="{{ it()->url(setting()->logo) }}" alt="logo-dark">
                    <img class="logo-small logo-img logo-img-small" src="{{ it()->url(setting()->icon) }}" srcset="{{ it()->url(setting()->icon) }}" alt="logo-small">
              </a>
          </div>
          <div class="nk-menu-trigger mr-n2">
              <a href="#" class="nk-nav-toggle nk-quick-nav-icon d-xl-none" data-target="sidebarMenu"><em class="icon ni ni-arrow-left"></em></a>
              <a href="#" class="nk-nav-compact nk-quick-nav-icon d-none d-xl-inline-flex" data-target="sidebarMenu"><em class="icon ni ni-menu"></em></a>
          </div>
      </div><!-- .nk-sidebar-element -->
      <div class="nk-sidebar-element">
          <div class="nk-sidebar-content">
              <div class="nk-sidebar-menu" data-simplebar>
                  <ul class="nk-menu">
                      <li class="nk-menu-item">
                          <a href="{{url(request()->segment('1').'/dashboard')}}" class="nk-menu-link">
                              <span class="nk-menu-icon"><em class="icon ni ni-home"></em></span>
                              <span class="nk-menu-text">{{ trans('admin.dashboard') }}</span>
                          </a>
                      </li>
                      
                      @if(admin()->user()->role("banners_show"))
                      <!-- .nk-menu-item -->
                      <li class="nk-menu-item has-sub">
                          <a href="#" class="nk-menu-link nk-menu-toggle">
                              <span class="nk-menu-icon"><em class="icon ni ni-img"></em></span>
                              <span class="nk-menu-text">{{trans('admin.banners')}}</span>
                          </a>
                          <ul class="nk-menu-sub">
                              <li class="nk-menu-item">
                                  <a href="{{url(request()->segment('1').'/banners')}}" class="nk-menu-link"><span class="nk-menu-text">{{trans('admin.all')}}</span></a>
                              </li>
                              <li class="nk-menu-item">
                                  <a href="{{url(request()->segment('1').'/banners/create')}}" class="nk-menu-link"><span class="nk-menu-text">{{trans('admin.create')}}</span></a>
                              </li>
                          </ul><!-- .nk-menu-sub -->
                      </li><!-- .nk-menu-item -->
                    @endif

                    @if(admin()->user()->role("advs_show"))
                      <!-- .nk-menu-item -->
                      <li class="nk-menu-item has-sub">
                          <a href="#" class="nk-menu-link nk-menu-toggle">
                              <span class="nk-menu-icon"><em class="icon ni ni-img"></em></span>
                              <span class="nk-menu-text">شريط الأخبار</span>
                          </a>
                          <ul class="nk-menu-sub">
                              <li class="nk-menu-item">
                                  <a href="{{url(request()->segment('1').'/advs')}}" class="nk-menu-link"><span class="nk-menu-text">{{trans('admin.all')}}</span></a>
                              </li>
                              <li class="nk-menu-item">
                                  <a href="{{url(request()->segment('1').'/advs/create')}}" class="nk-menu-link"><span class="nk-menu-text">{{trans('admin.create')}}</span></a>
                              </li>
                          </ul><!-- .nk-menu-sub -->
                      </li><!-- .nk-menu-item -->
                    @endif

                      @if(admin()->user()->role("cities_show"))
                      <li class="nk-menu-item has-sub">
                          <a href="#" class="nk-menu-link nk-menu-toggle">
                              <span class="nk-menu-icon"><em class="icon ni ni-layers-fill"></em></span>
                              <span class="nk-menu-text">المدن</span>
                          </a>
                          <ul class="nk-menu-sub">
                              <li class="nk-menu-item">
                                  <a href="{{aurl('cities')}}" class="nk-menu-link"><span class="nk-menu-text">عرض الكل</span></a>
                              </li>
                              <li class="nk-menu-item">
                                  <a href="{{aurl('cities/create')}}" class="nk-menu-link"><span class="nk-menu-text">{{trans('admin.create')}}</span></a>
                              </li>
                          </ul><!-- .nk-menu-sub -->
                      </li><!-- .nk-menu-item -->
                      <li class="nk-menu-item has-sub">
                          <a href="#" class="nk-menu-link nk-menu-toggle">
                              <span class="nk-menu-icon"><em class="icon ni ni-layers-fill"></em></span>
                              <span class="nk-menu-text">المناطق</span>
                          </a>
                          <ul class="nk-menu-sub">
                              <li class="nk-menu-item">
                                  <a href="{{aurl('areas')}}" class="nk-menu-link"><span class="nk-menu-text">عرض الكل</span></a>
                              </li>
                              <li class="nk-menu-item">
                                  <a href="{{aurl('areas/create')}}" class="nk-menu-link"><span class="nk-menu-text">{{trans('admin.create')}}</span></a>
                              </li>
                          </ul><!-- .nk-menu-sub -->
                      </li><!-- .nk-menu-item -->
                    @endif

                      @if(admin()->user()->role("categories_show"))
                      <!-- .nk-menu-item -->
                      <li class="nk-menu-item has-sub">
                          <a href="#" class="nk-menu-link nk-menu-toggle">
                              <span class="nk-menu-icon"><em class="icon ni ni-layers-fill"></em></span>
                              <span class="nk-menu-text">{{trans('admin.categories')}}</span>
                          </a>
                          <ul class="nk-menu-sub">
                              <li class="nk-menu-item">
                                  <a href="{{aurl('categories')}}" class="nk-menu-link"><span class="nk-menu-text">الرئيسية</span></a>
                              </li>
                              <li class="nk-menu-item">
                                  <a href="{{aurl('categories/sub/all')}}" class="nk-menu-link"><span class="nk-menu-text">الفرعية</span></a>
                              </li>
                              <li class="nk-menu-item">
                                  <a href="{{aurl('categories/create')}}" class="nk-menu-link"><span class="nk-menu-text">{{trans('admin.create')}}</span></a>
                              </li>
                          </ul><!-- .nk-menu-sub -->
                      </li><!-- .nk-menu-item -->
                      @endif
                      <!--categories_start_route-->

                    @if(admin()->user()->role("vendors_show"))
                      <li class="nk-menu-item has-sub">
                          <a href="#" class="nk-menu-link nk-menu-toggle">
                              <span class="nk-menu-icon"><em class="icon ni ni-users-fill"></em></span>
                              <span class="nk-menu-text">{{trans('admin.vendors')}}</span>
                          </a>
                          <ul class="nk-menu-sub">
                              <li class="nk-menu-item">
                                  <a href="{{url(request()->segment('1').'/vendors')}}" class="nk-menu-link"><span class="nk-menu-text">{{trans('admin.all')}}</span></a>
                              </li>
                              <li class="nk-menu-item">
                                  <a href="{{url(request()->segment('1').'/vendors/create')}}" class="nk-menu-link"><span class="nk-menu-text">{{trans('admin.create')}}</span></a>
                              </li>
                          </ul><!-- .nk-menu-sub -->
                      </li><!-- .nk-menu-item -->
                    @endif

                    @if(admin()->user()->role("branches_show"))
                      <li class="nk-menu-item has-sub">
                          <a href="#" class="nk-menu-link nk-menu-toggle">
                              <span class="nk-menu-icon"><em class="icon ni ni-users-fill"></em></span>
                              <span class="nk-menu-text">الفروع</span>
                          </a>
                          <ul class="nk-menu-sub">
                              <li class="nk-menu-item">
                                  <a href="{{url(request()->segment('1').'/branches')}}" class="nk-menu-link"><span class="nk-menu-text">{{trans('admin.all')}}</span></a>
                              </li>
                              <li class="nk-menu-item">
                                  <a href="{{url(request()->segment('1').'/branches/create')}}" class="nk-menu-link"><span class="nk-menu-text">{{trans('admin.create')}}</span></a>
                              </li>
                          </ul><!-- .nk-menu-sub -->
                      </li><!-- .nk-menu-item -->
                    @endif

                    @if(admin()->user()->role("cars_show"))
                      <!-- .nk-menu-item -->
                      <li class="nk-menu-item has-sub">
                          <a href="#" class="nk-menu-link nk-menu-toggle">
                              <span class="nk-menu-icon"><em class="icon ni ni-truck"></em></span>
                              <span class="nk-menu-text">{{trans('admin.cars')}}</span>
                          </a>
                          <ul class="nk-menu-sub">
                              <li class="nk-menu-item">
                                  <a href="{{url(request()->segment('1').'/cars')}}" class="nk-menu-link"><span class="nk-menu-text">{{trans('admin.all')}}</span></a>
                              </li>
                              <li class="nk-menu-item">
                                  <a href="{{url(request()->segment('1').'/cars/create')}}" class="nk-menu-link"><span class="nk-menu-text">{{trans('admin.create')}}</span></a>
                              </li>
                          </ul><!-- .nk-menu-sub -->
                      </li><!-- .nk-menu-item -->
                    @endif

                    @if(admin()->user()->role("units_show"))
                      <!-- .nk-menu-item -->
                      <li class="nk-menu-item has-sub">
                          <a href="#" class="nk-menu-link nk-menu-toggle">
                              <span class="nk-menu-icon"><em class="icon ni ni-light-fill"></em></span>
                              <span class="nk-menu-text">{{trans('admin.units')}}</span>
                          </a>
                          <ul class="nk-menu-sub">
                              <li class="nk-menu-item">
                                  <a href="{{url(request()->segment('1').'/units')}}" class="nk-menu-link"><span class="nk-menu-text">{{trans('admin.all')}}</span></a>
                              </li>
                              <li class="nk-menu-item">
                                  <a href="{{url(request()->segment('1').'/units/create')}}" class="nk-menu-link"><span class="nk-menu-text">{{trans('admin.create')}}</span></a>
                              </li>
                          </ul><!-- .nk-menu-sub -->
                      </li><!-- .nk-menu-item -->
                    @endif

                    <!--products_start_route-->
                    @if(admin()->user()->role("products_show"))
                      <!-- .nk-menu-item -->
                      <li class="nk-menu-item has-sub">
                          <a href="#" class="nk-menu-link nk-menu-toggle">
                              <span class="nk-menu-icon"><em class="icon ni ni-card-view"></em></span>
                              <span class="nk-menu-text">{{trans('admin.products')}}</span>
                          </a>
                          <ul class="nk-menu-sub">
                              <li class="nk-menu-item">
                                  <a href="{{url(request()->segment('1').'/products')}}" class="nk-menu-link"><span class="nk-menu-text">{{trans('admin.all')}}</span></a>
                              </li>
                              <li class="nk-menu-item">
                                  <a href="{{url(request()->segment('1').'/products/create')}}" class="nk-menu-link"><span class="nk-menu-text">{{trans('admin.create')}}</span></a>
                              </li>
                          </ul><!-- .nk-menu-sub -->
                      </li><!-- .nk-menu-item -->
                    @endif
                    <!--products_end_route-->
                    
                    <li class="nk-menu-item has-sub">
                        <a href="#" class="nk-menu-link nk-menu-toggle">
                            <span class="nk-menu-icon"><em class="icon ni ni-layers-fill"></em></span>
                            <span class="nk-menu-text">{{trans('admin.orders')}}</span>
                        </a>
                        @php
                            $all_ords = \App\Models\Order::count();
                            $pend_ords = \App\Models\Order::where('payment_status', 'pending')->count();
                        @endphp
                        <ul class="nk-menu-sub">
                            <li class="nk-menu-item">
                                <a href="{{url(request()->segment('1').'/orders')}}?payment_status=pending" class="nk-menu-link">
                                    <span class="nk-menu-text">قيد المرجعة </span>
                                    <span style="color: red;">( {{$pend_ords}} )</span>                                
                                </a>
                            </li>
                            <li class="nk-menu-item">
                                <a href="{{url(request()->segment('1').'/orders')}}" class="nk-menu-link">
                                    <span class="nk-menu-text">{{trans('admin.all')}}</span>
                                    <span style="color: lime;">( {{$all_ords}} )</span>
                                </a>
                            </li>
                        </ul><!-- .nk-menu-sub -->
                    </li><!-- .nk-menu-item -->

                      <li class="nk-menu-item">
                          <a href="{{aurl('sales')}}" class="nk-menu-link">
                              <span class="nk-menu-icon"><em class="icon ni ni-layers-fill"></em></span>
                              <span class="nk-menu-text">المبيعات</span>
                          </a>
                      </li>


                      @if(admin()->user()->role("users_show"))
                      <li class="nk-menu-item">
                          <a href="{{url(request()->segment('1').'/users')}}" class="nk-menu-link">
                              <span class="nk-menu-icon"><em class="icon ni ni-users-fill"></em></span>
                              <span class="nk-menu-text">المستخدمين</span>
                          </a>
                      </li>
                      @endif

                    <!--admins_start_route-->
                    @if(admin()->user()->role("deliveries_show"))
                      <!-- .nk-menu-item -->
                      <li class="nk-menu-item">
                          <a href="{{url(request()->segment('1').'/deliveries')}}" class="nk-menu-link">
                              <span class="nk-menu-icon"><em class="icon ni ni-users-fill"></em></span>
                              <span class="nk-menu-text">السائقين</span>
                          </a>
                      </li>
                    @endif
                    <!--admins_end_route-->

                    <!--admins_start_route-->
                    @if(admin()->user()->role("withdrawalrequests_show"))
                      <!-- .nk-menu-item -->
                      <li class="nk-menu-item has-sub">
                          <a href="#" class="nk-menu-link nk-menu-toggle">
                              <span class="nk-menu-icon"><em class="icon ni ni-light-fill"></em></span>
                              <span class="nk-menu-text">طلبات السحب</span>
                          </a>
                          <ul class="nk-menu-sub">
                              <li class="nk-menu-item">
                                  <a href="{{url(request()->segment('1').'/withdrawal-requests')}}?status=pending" class="nk-menu-link"><span class="nk-menu-text">قيد الفحص</span></a>
                                  <a href="{{url(request()->segment('1').'/withdrawal-requests')}}?status=completed" class="nk-menu-link"><span class="nk-menu-text">المكتملة</span></a>
                                  <!--a href="{{aurl('withdrawal-requests')}}?status=cancelled" class="nk-menu-link"><span class="nk-menu-text">ملغاة</span></a-->
                              </li>
                          </ul><!-- .nk-menu-sub -->
                      </li><!-- .nk-menu-item -->
                    @endif
                    <!--admins_end_route-->

                    <!--faqs_start_route-->
                    @if(admin()->user()->role("faqs_show"))
                      <!-- .nk-menu-item -->
                      <li class="nk-menu-item has-sub">
                          <a href="#" class="nk-menu-link nk-menu-toggle">
                              <span class="nk-menu-icon"><em class="icon ni ni-question"></em></span>
                              <span class="nk-menu-text">{{trans('admin.faqs')}}</span>
                          </a>
                          <ul class="nk-menu-sub">
                              <li class="nk-menu-item">
                                  <a href="{{aurl('faqs')}}/?type=users" class="nk-menu-link"><span class="nk-menu-text">لتطبيق المستخدم</span></a>
                              </li>
                              <li class="nk-menu-item">
                                  <a href="{{aurl('faqs')}}/?type=branches" class="nk-menu-link"><span class="nk-menu-text">لتطبيق الفروع</span></a>
                              </li>
                              <li class="nk-menu-item">
                                <a href="{{aurl('faqs')}}/?type=deliveries" class="nk-menu-link"><span class="nk-menu-text">لتطبيق الديلفري</span></a>
                            </li>
                        </ul><!-- .nk-menu-sub -->
                      </li><!-- .nk-menu-item -->
                    @endif
                    <!--faqs_end_route-->

                    <!--admins_start_route-->
                    @if(admin()->user()->role("tickets_show") && admin()->user()->is_vendor==0)
                      <!-- .nk-menu-item -->
                      <li class="nk-menu-item">
                          <a href="{{url(request()->segment('1').'/tickets')}}" class="nk-menu-link">
                              <span class="nk-menu-icon"><em class="icon ni ni-inbox"></em></span>
                              <span class="nk-menu-text">الرسائل الواردة</span>
                          </a>
                      </li>
                    @endif
                    <!--admins_end_route-->

                    <!--settings_start_route-->
                    @if(admin()->user()->role("settings_show"))
                      <!-- .nk-menu-item -->
                        <li class="nk-menu-item">
                            <a href="{{aurl('settings')}}" class="nk-menu-link">
                                <span class="nk-menu-icon"><em class="icon ni ni-puzzle-fill"></em></span>
                                <span class="nk-menu-text">{{trans('admin.settings')}}</span>
                            </a>
                        </li>
                    @endif

                  </ul><!-- .nk-menu -->
              </div><!-- .nk-sidebar-menu -->
          </div><!-- .nk-sidebar-content -->
      </div><!-- .nk-sidebar-element -->
  </div>
  <!-- sidebar @e -->
