@extends('admin.layouts.master')
@section('content')

	<div class="nk-content ">
		<div class="container-fluid">
			<div class="nk-content-inner">
				<div class="nk-content-body">
					<div class="components-preview wide-md mx-auto">
						<div class="nk-block nk-block-lg">
							<div class="nk-block-head">
								<div class="nk-block-head-content">
									<h4 class="title nk-block-title">{{ !empty($title)?$title:'' }}</h4>
								</div>
							</div>
							<div class="card card-preview">

								<div class="card-inner">
								{!! Form::open(['url'=>aurl('areas'),'id'=>'areas','files'=>true,'class'=>'form-horizontal form-row-seperated']) !!}
									<div class="preview-block">
										<div class="row gy-4">
											<div class="col-sm-6">
												<div class="form-group">
													{!! Form::label('name_ar',"الاسم عربي",['class'=>' control-label']) !!}
													<div class="form-control-wrap">
														{!! Form::text('name_ar',old('name_ar'),['class'=>'form-control','placeholder'=>"الاسم عربي"]) !!}
													</div>
												</div>
											</div>
											<div class="col-sm-6">
												<div class="form-group">
													{!! Form::label('name_en',"الاسم إنجليزي",['class'=>' control-label']) !!}
													<div class="form-control-wrap">
														{!! Form::text('name_en',old('name_en'),['class'=>'form-control','placeholder'=>"الاسم إنجليزي"]) !!}
													</div>
												</div>
											</div>
										</div>
										<div class="row gy-4">
											<div class="col-sm-6">
												<div class="form-group">
													{!! Form::label('name_urdu',"الاسم بالأوردو",['class'=>' control-label']) !!}
													<div class="form-control-wrap">
														{!! Form::text('name_urdu',old('name_urdu'),['class'=>'form-control','placeholder'=>"الاسم بالأوردو"]) !!}
													</div>
												</div>
											</div>
											<div class="col-md-6">
												<div class="form-group">
												<label class="form-label" for="city_id">المدينة</label>
													<div class="form-control-wrap">
														<select class="form-control required" data-msg="Required" id="city_id" name="city_id" required>
															<option value="" selected>اختر المدينة</option>
															@foreach(\App\Models\City::get() as $city)
															<option value="{{$city->id}}">{{$city->name_ar}}</option>
															@endforeach
														</select>
													</div>
												</div>
											</div>
										</div>
										<div class="row g-3">
											<div class="col-lg-7 offset-lg-5">
												<div class="form-group mt-2">
													<button type="submit" name="add" class="btn btn-lg btn-primary">إضافة</button>
												</div>
											</div>
										</div>
									</div>
									{!! Form::close() !!}

								</div>

							</div><!-- .card-preview -->
						</div><!-- .nk-block -->
					</div><!-- .components-preview -->
				</div>
			</div>
		</div>
	</div>
@endsection
