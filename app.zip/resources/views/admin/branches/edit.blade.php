@extends('admin.layouts.master')
@section('content')

	<div class="nk-content ">
		<div class="container-fluid">
			<div class="nk-content-inner">
				<div class="nk-content-body">
					<div class="components-preview wide-md mx-auto">
						<div class="nk-block nk-block-lg">
							<div class="nk-block-head">
								<div class="nk-block-head-content">
									<h4 class="title nk-block-title">{{ !empty($title)?$title:'' }}</h4>
								</div>
							</div>
							<div class="card card-preview">

								<div class="card-inner">
                								{!! Form::open(['url'=>url(request()->segment('1').'/branches/'.$branches->id),'method'=>'put','id'=>'branches','files'=>true,'class'=>'form-horizontal form-row-seperated']) !!}
                                                    <input type="hidden" name="city_id" value="{{$branches->city_id}}">
                                                    <div class="nk-wizard-content">
                                                        <div class="row gy-3">
                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                    <label class="form-label" for="name">اسم الفرع</label>
                                                                    <div class="form-control-wrap">
                														{!! Form::text('name', $branches->name ,['class'=>'form-control','placeholder'=>trans('admin.name')]) !!}
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                <label class="form-label" for="location">الموقع</label>
                                                                    <div class="form-control-wrap">
                                                                        <input type="text" id="searchTextField" class="form-control" value="$branches->address" required>
                                                                        <input type="hidden" class="form-control" id="address" name="address" value="{{$branches->address}}">
                                                                        <input type="hidden" class="form-control" id="latitude" name="latitude" value="{{$branches->latitude}}">
                                                                        <input type="hidden" class="form-control" id="longitude" name="longitude" value="{{$branches->longitude}}">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="nk-wizard-content">
                                                        <div class="row gy-3">
                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                    <label class="form-label" for="mobile">الجوال</label>
                                                                    <div class="form-control-wrap">
                                                                        {!! Form::text('mobile', $branches->mobile ,['class'=>'form-control','placeholder'=>trans('admin.mobile')]) !!}
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                    <label class="form-label" for="password">Password</label>
                                                                    <div class="form-control-wrap">
                                                                        <input type="password" data-msg="Required" class="form-control required" id="password" name="password">
                                                                    </div>
                                                                </div>
                                                            </div><!-- .col -->
                                                        </div>
                                                        <div class="row gy-3">
                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                    <button type="submit" class="btn btn-primary">{{ trans('admin.save') }}</button>
                                                                </div>
                                                            </div>
                                                        </div><!-- .row -->
                                                    </div>
                                                </form>
								</div>
							</div><!-- .card-preview -->
						</div><!-- .nk-block -->
					</div><!-- .components-preview -->
				</div>
			</div>
		</div>
	</div>
	
    <script src="https://maps.googleapis.com/maps/api/js?libraries=places&key=AIzaSyCII75uUvnbkKy7MccwRLhTlBch6VHklpo" type="text/javascript"></script>
    <script>
        function initialize() {
            var input = document.getElementById('searchTextField');
            var autocomplete = new google.maps.places.Autocomplete(input);
            google.maps.event.addListener(autocomplete, 'place_changed', function () {
                var place = autocomplete.getPlace();
                document.getElementById('address').value = place.name;
                document.getElementById('latitude').value = place.geometry.location.lat();
                document.getElementById('longitude').value = place.geometry.location.lng();
                //alert("This function is working!");
                //alert(place.name);
            // alert(place.address_components[0].long_name);

            });
        }
        google.maps.event.addDomListener(window, 'load', initialize);

        function get_sub_category(category_id) {
            $.get("{{url('get-sub-categories/')}}/"+category_id, function(response) {
                $("#category_id").html(response);
            });
        }

    </script>
	
@endsection
