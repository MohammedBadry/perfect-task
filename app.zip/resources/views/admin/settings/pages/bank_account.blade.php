        <div class="nk-block-head nk-block-head-lg">
            <div class="nk-block-between">
                <div class="nk-block-head-content">
                    <h6 class="nk-block-title">بيانات الحساب البنكي</h6>
                </div>
                <div class="nk-block-head-content align-self-start d-lg-none">
                    <a href="#" class="toggle btn btn-icon btn-trigger mt-n1" data-target="userAside"><em class="icon ni ni-menu-alt-r"></em></a>
                </div>
            </div>
        </div><!-- .nk-block-head -->
        <div class="nk-block">

            <div class="row gy-4">
                <div class="col-sm-6">
                    <div class="form-group">
                        {!! Form::label('bank_name', 'اسم البنك',['class'=>'control-label']) !!}
                        <div class="form-control-wrap">
                        {!! Form::text('bank_name',setting()->bank_name,['class'=>'form-control','placeholder'=> 'اسم البنك']) !!}
                        </div>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        {!! Form::label('bank_account_name', 'اسم الحساب',['class'=>'control-label']) !!}
                        <div class="form-control-wrap">
                        {!! Form::text('bank_account_name',setting()->bank_account_name,['class'=>'form-control','placeholder'=> 'اسم الحساب']) !!}
                        </div>
                    </div>
                </div>
            </div>

            <div class="row gy-4">
                <div class="col-sm-6">
                    <div class="form-group">
                        {!! Form::label('bank_account_number', 'رقم الحساب',['class'=>'control-label']) !!}
                        <div class="form-control-wrap">
                        {!! Form::text('bank_account_number',setting()->bank_account_number,['class'=>'form-control','placeholder'=> 'رقم الحساب']) !!}
                        </div>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        {!! Form::label('iban', 'آيبان',['class'=>'control-label']) !!}
                        <div class="form-control-wrap">
                        {!! Form::text('iban',setting()->iban,['class'=>'form-control','placeholder'=> 'آيبان']) !!}
                        </div>
                    </div>
                </div>
            </div>

        
        </div>