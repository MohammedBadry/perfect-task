        <div class="nk-block-head nk-block-head-lg">
            <div class="nk-block-between">
                <div class="nk-block-head-content">
                    <h6 class="nk-block-title">سياسة الاستخدام</h6>
                </div>
                <div class="nk-block-head-content align-self-start d-lg-none">
                    <a href="#" class="toggle btn btn-icon btn-trigger mt-n1" data-target="userAside"><em class="icon ni ni-menu-alt-r"></em></a>
                </div>
            </div>
        </div><!-- .nk-block-head -->
        <div class="nk-block">
            
										<div class="row gy-4">
                                            <div class="form-group col-md-12">
                                                {!! Form::label('user_app_terms',"لتطبيق العميل",['class'=>'control-label']) !!}
                                                {!! Form::textarea('user_app_terms',setting()->user_app_terms,['class'=>'form-control','placeholder'=> "لتطبيق العميل"]) !!}
                                            </div>
                                            <div class="form-group col-md-12">
                                                {!! Form::label('branch_app_terms',"لتطبيق الفرع",['class'=>'control-label']) !!}
                                                {!! Form::textarea('branch_app_terms',setting()->branch_app_terms,['class'=>'form-control','placeholder'=> "لتطبيق الفرع"]) !!}
                                            </div>
                                            <div class="form-group col-md-12">
                                                {!! Form::label('delivery_app_terms',"لتطبيق السائق",['class'=>'control-label']) !!}
                                                {!! Form::textarea('delivery_app_terms',setting()->delivery_app_terms,['class'=>'form-control','placeholder'=> "لتطبيق السائق"]) !!}
                                            </div>
										</div>

        
        </div>
