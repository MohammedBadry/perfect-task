        <div class="nk-block-head nk-block-head-lg">
            <div class="nk-block-between">
                <div class="nk-block-head-content">
                    <h6 class="nk-block-title"> عن تطبيق السائقين</h6>
                </div>
                <div class="nk-block-head-content align-self-start d-lg-none">
                    <a href="#" class="toggle btn btn-icon btn-trigger mt-n1" data-target="userAside"><em class="icon ni ni-menu-alt-r"></em></a>
                </div>
            </div>
        </div><!-- .nk-block-head -->
        <div class="nk-block">

                <div class="row gy-4">
                    <div class="form-group col-md-12">
                        {!! Form::label('delivery_app_about_ar',"عربي",['class'=>'control-label']) !!}
                        {!! Form::textarea('delivery_app_about_ar',setting()->delivery_app_about_ar,['class'=>'form-control','placeholder'=> "عربي"]) !!}
                    </div>
                    <div class="form-group col-md-12">
                        {!! Form::label('delivery_app_about_en',"إنجليزي",['class'=>'control-label']) !!}
                        {!! Form::textarea('delivery_app_about_en',setting()->delivery_app_about_en,['class'=>'form-control','placeholder'=> "إنجليزي"]) !!}
                    </div>
                    <div class="form-group col-md-12">
                        {!! Form::label('delivery_app_about_urdu',"أوردو",['class'=>'control-label']) !!}
                        {!! Form::textarea('delivery_app_about_urdu',setting()->delivery_app_about_urdu,['class'=>'form-control','placeholder'=> "أوردو"]) !!}
                    </div>
                </div>

        </div>
