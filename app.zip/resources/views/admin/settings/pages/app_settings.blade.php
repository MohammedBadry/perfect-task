        <div class="nk-block-head nk-block-head-lg">
            <div class="nk-block-between">
                <div class="nk-block-head-content">
                    <h6 class="nk-block-title">الإعدادات المالية</h6>
                </div>
                <div class="nk-block-head-content align-self-start d-lg-none">
                    <a href="#" class="toggle btn btn-icon btn-trigger mt-n1" data-target="userAside"><em class="icon ni ni-menu-alt-r"></em></a>
                </div>
            </div>
        </div><!-- .nk-block-head -->
        <div class="nk-block">

										<div class="row gy-4">
											<div class="col-sm-12">
												<div class="form-group">
									                {!! Form::label('tax', 'ضريبة القيمة المضافة %',['class'=>'control-label']) !!}
													<div class="form-control-wrap">
									                {!! Form::text('tax',setting()->tax,['class'=>'form-control','placeholder'=> 'ضريبة القيمة المضافة %']) !!}
													</div>
												</div>
											</div>
										</div>

        
        </div>