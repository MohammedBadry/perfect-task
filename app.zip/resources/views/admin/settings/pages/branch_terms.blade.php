        <div class="nk-block-head nk-block-head-lg">
            <div class="nk-block-between">
                <div class="nk-block-head-content">
                    <h6 class="nk-block-title">سياسة استخدام تطبيق الفروع</h6>
                </div>
                <div class="nk-block-head-content align-self-start d-lg-none">
                    <a href="#" class="toggle btn btn-icon btn-trigger mt-n1" data-target="userAside"><em class="icon ni ni-menu-alt-r"></em></a>
                </div>
            </div>
        </div><!-- .nk-block-head -->
        <div class="nk-block">

                <div class="row gy-4">
                    <div class="form-group col-md-12">
                        {!! Form::label('branch_app_terms_ar',"عربي",['class'=>'control-label']) !!}
                        {!! Form::textarea('branch_app_terms_ar',setting()->branch_app_terms_ar,['class'=>'form-control','placeholder'=> "عربي"]) !!}
                    </div>
                    <div class="form-group col-md-12">
                        {!! Form::label('branch_app_terms_en',"إنجليزي",['class'=>'control-label']) !!}
                        {!! Form::textarea('branch_app_terms_en',setting()->branch_app_terms_en,['class'=>'form-control','placeholder'=> "إنجليزي"]) !!}
                    </div>
                    <div class="form-group col-md-12">
                        {!! Form::label('branch_app_terms_urdu',"أوردو",['class'=>'control-label']) !!}
                        {!! Form::textarea('branch_app_terms_urdu',setting()->branch_app_terms_urdu,['class'=>'form-control','placeholder'=> "أوردو"]) !!}
                    </div>
                </div>

        </div>
