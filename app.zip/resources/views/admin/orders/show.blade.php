@extends('admin.layouts.master')
@section('content')

	<div class="nk-content ">
		<div class="container-fluid">
			<div class="nk-content-inner">
				<div class="nk-content-body">
					<div class="components-preview wide-md mx-auto">
						<div class="nk-block nk-block-lg">
							<div class="nk-block-head">
								<div class="nk-block-head-content">
									<h4 class="title nk-block-title no-print">{{!empty($title)?$title:''}}</h4>
									<h4 class="title nk-block-title print" style="display: none">فاتورة رقم {{$orders->id}}</h4>
                                    <button type="button" class="btn btn-primary no-print" onclick="window.print();"><em class="icon ni ni-printer-fill"></em></button>
								</div>
							</div>
                                <section class="content">
                                    <div class="container-fluid">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="card card-info">
                                                    <div class="card-body">
                                                        <table class="table">
                                                            <tr>
                                                                <th style="width: 20%">ID</th>
                                                                <td>{{$orders->id}}</td>
                                                            </tr>
                                                            @if(admin()->user()->is_vendor==0)
                                                            <tr>
                                                                <th style="width: 20%">المصنع</th>
                                                                <td dir="ltr">
                                                                    {{$orders->vendor->name??''}}
                                                                </td>
                                                            </tr>
                                                            @endif
                                                            <tr>
                                                                <th style="width: 20%">الفرع</th>
                                                                <td dir="ltr">
                                                                    {{$orders->branch->name??''}}
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <th style="width: 20%">اسم المستخدم</th>
                                                                <td>{{$orders->user->name}}</td>

                                                            </tr>
                                                            <tr>
                                                                <th style="width: 20%">الإيميل</th>
                                                                <td>{{$orders->user->email}}</td>

                                                            </tr>
                                                            <tr>
                                                                <th style="width: 20%">الجوال</th>
                                                                <td>{{$orders->user->mobile}}</td>

                                                            </tr>
                                                            <tr>
                                                                <th style="width: 20%">العنوان</th>
                                                                <td dir="ltr">
                                                                    {{$orders->address}}
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <th style="width: 20%">المدينة</th>
                                                                <td dir="ltr">
                                                                    {{$orders->city->name_ar??''}}
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <th style="width: 20%">المنطقة</th>
                                                                <td dir="ltr">
                                                                    {{$orders->area->name_ar??''}}
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <th style="width: 20%">الشارع</th>
                                                                <td dir="ltr">
                                                                    {{$orders->street??''}}
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <th style="width: 20%">الموقع</th>
                                                                <td dir="ltr">
                                                                    <a style="float: " class="no-print" href="{{route(request()->segment(1).'.orders.location-preview')}}?latitude={{$orders->latitude}}&longitude={{$orders->longitude}}" target="_blank" title="معاينة">
                                                                        <!--em class="icon ni ni-location"></em-->
                                                                        <em class="icon ni ni-map-pin-fill"></em>
                                                                    </a>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <th style="width: 20%">تاريخ الطلب</th>
                                                                <td>{{$orders->created_at->format('Y-m-d H:i')}}</td>

                                                            </tr>
                                                            <tr>
                                                                <th style="width: 20%">تفاصيل الطلب</th>
                                                                <td>
                                                                    <div class="container-fluid row">
                                                                        @php
                                                                            $total = 0;
                                                                        @endphp
                                                                        @foreach ($orders->items as $item)
                                                                            @php
                                                                                $total += $subtotal = $item->total;
                                                                            @endphp
                                                                            <div class="  card col-md-3 col-sm-12 p-3 mb-2 rounded m-1 grow" style="background-color: #f5f6fa">
                                                                                <div>
                                                                                    <span class="text-bold">المنتج : </span>
                                                                                    <a href="{{ url(request()->segment(1).'/products/'.$item->product_id) }}" class="no-print" target="_blank" title="عرض" >
                                                                                        {{$item->product->name_ar }}
                                                                                    </a>
                                                                                    <span class="print" style="display:  none">
                                                                                        {{$item->product->name_ar }}
                                                                                    </span>
                                                                                </div>
                                                                                <div><span class="text-bold">الكمية : </span>{{$item->quantity }} </div>
                                                                                <div><span class="text-bold">السعر : </span>{{$item->product->price }} ريال</div>

                                                                                <div><span class="text-bold">الفرعي الإجمالي : </span>{{$subtotal }} ريال</div>
                                                                            </div>
                                                                        @endforeach
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <th style="width: 20%">السائق</th>
                                                                <td>
                                                                    @if($orders->delivery_id!='')
                                                                    <a target="_blank" href="{{route(request()->segment(1).'.deliveries.show', $orders->delivery->id)}}">
                                                                        {{$orders->delivery->name}}
                                                                    </a>
                                                                    @else
                                                                    لم يتم تعيين سائق
                                                                    @endif
                                                                </td>

                                                            </tr>
                                                            <tr>
                                                                <th style="width: 20%">تكلفة التوصيل</th>
                                                                <td>
                                                                    {{$orders->delivery_cost}} ريال
                                                                </td>

                                                            </tr>
                                                            <tr>
                                                                <th style="width: 20%">الضريبة</th>
                                                                <td>
                                                                    {{$orders->tax}} ريال
                                                                </td>

                                                            </tr>
                                                            <tr>
                                                                <th style="width: 20%">الإجمالي النهائي</th>
                                                                <td id='amount'>{{$orders->final_total}} ريال</td>
                                                            </tr>
                                                            @if($orders->delivery_id)
                                                            @endif
                                                            <tr>
                                                                <th style="width: 20%">حالة الطلب</th>
                                                                <td>{{$orders->status->status_ar}}</td>
                                                            </tr>
                                                            <tr>
                                                                <th style="width: 20%">طريقة الدفع</th>
                                                                <td>{{$orders->payment_method}}</td>
                                                            </tr>
                                                            <tr>
                                                                <th style="width: 20%">حالة الدفع</th>
                                                                <td>
                                                                    @if($orders->payment_status=='pending')                                                                        
                                                                        <span style="color: red">قيد المراجعة</span>
                                                                    @elseif($orders->payment_status=='partially_paid')                                                                        
                                                                        <span style="color:burlywood">مدفوع جزئيا</span>
                                                                    @elseif($orders->payment_status=='totally_paid')
                                                                    <span style="color: lime">مدفوع كليا</span>                                                                        
                                                                    @endif
                                                                </td>
                                                            </tr>
                                                            @if(admin()->user()->is_vendor==0)
                                                            <tr>
                                                                <th style="width: 20%">إيصالات التحويل</th>
                                                                <td>
                                                                    <a href="{{it()->url($orders->transfer_receipt_1)}}" target="_blank"><img src="{{it()->url($orders->transfer_receipt_1)}}" width="200"></a>
                                                                    <a href="{{it()->url($orders->transfer_receipt_2)}}" target="_blank"><img src="{{it()->url($orders->transfer_receipt_2)}}" width="200"></a>
                                                                </td>
                                                            </tr>
                                                            @if($orders->payment_status=='pending' || $orders->payment_status=='partially_paid')
                                                            <tr>
                                                                <th style="width: 20%">الإجراء</th>
                                                                <td>
                                                                    <a href="#" data-toggle="modal" data-target="#assign_as_paid" class="btn btn-success">تعيين كمدفوع</a>
                                                                </td>
                                                            </tr>
                                                            @endif
                                                            @endif
                                                        </table>
                                                    </div>
                                                </div>
                                                <!--/.card-->
                                            </div>
                                            <!--/.col-md-12-->
                                        </div>
                                        <!-- /.row -->
                                    </div><!-- /.container-fluid -->
                                </section>

						</div><!-- .nk-block -->
					</div><!-- .components-preview -->
				</div>
			</div>
		</div>
	</div>

@if(admin()->user()->is_vendor==0)
<div class="modal fade" id="assign_as_paid">
	<div class="modal-dialog">
		<div class="modal-content">
            {!! Form::open([
            'method' => 'PUT',
            'route' => ['admin.orders.assign_as_paid', $orders->id]
            ]) !!}
			<div class="modal-header">
				<h4 class="modal-title">تعيين كمدفوع</h4>
				<button class="close" data-dismiss="modal">x</button>
			</div>
			<div class="modal-body">
                <select name="payment_status" class="form-control" required>
                    <option value="">اختر حالة الدفع</option>
                    <option value="partially_paid" @if($orders->payment_status == 'partially_paid') selected @endif>مدفوع جزئيا</option>
                    <option value="totally_paid" @if($orders->payment_status == 'totally_paid') selected @endif>مدفوع كليا</option>
                </select>
			</div>
			<div class="modal-footer">
				{!! Form::submit(trans('admin.approval'), ['class' => 'btn btn-success btn-flat']) !!}
				<a class="btn btn-default btn-flat" data-dismiss="modal">{{trans('admin.cancel')}}</a>
			</div>
            {!! Form::close() !!}
		</div>
	</div>
</div>    
@endif

@endsection
