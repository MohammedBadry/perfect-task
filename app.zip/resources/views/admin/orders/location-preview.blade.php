@extends('admin.layouts.master')
@section('content')

                <div class="nk-content ">
                    <div class="container-fluid">
                        <div class="nk-content-inner">
                            <div class="nk-content-body">
                                <div class="components-preview wide-md mx-auto">
                                    <div class="nk-block-head nk-block-head-lg wide-sm">
                                        <div class="nk-block-head-content">
											&nbsp;
										</div>
                                    </div><!-- .nk-block-head -->
                                    <div class="nk-block nk-block-lg">
                                        <div class="nk-block-head">
                                            <div class="nk-block-head-content">
                                                <h4 class="nk-block-title">{{!empty($title)?$title:''}}</h4>
                                            </div>
                                        </div>
                                        <div class="card card-preview">
                                            <div class="card-inner">
                                                <div id="map_canvas" style="width:100%;height:400px;"></div>
                                            </div>
                                        </div><!-- .card-preview -->
                                    </div> <!-- nk-block -->
                                </div><!-- .components-preview -->
                            </div>
                        </div>
                    </div>
                </div>
@push('js')
  <script src="https://maps.googleapis.com/maps/api/js?libraries=places&key=AIzaSyBe8IAal1JXrrqB8kYCbLLbvPVMfCu-Pjw"></script>
  <script>
      $('document').ready(function() {
       var x = {{$latitude}};
       var y = {{$longitude}};
       var myOptions = {
        center: new google.maps.LatLng(x, y),
        zoom: 12,
        mapTypeId: google.maps.MapTypeId.ROADMAP
       };
       var map = new google.maps.Map(document.getElementById("map_canvas"), myOptions);
       var pinkParksStyles =  [ {featureType: "all", stylers: [{ hue: "#22FFAF" }, { saturation: 1 }]},{featureType: "poi.park", stylers: [ { hue: "#ff0023" },{ saturation: 40 }]},{featureType: "water", stylers: [ { hue: "#00AAFF"}]},{featureType: "road.highway", stylers: [ { hue: "#000000"}]},{featureType: "road.local", stylers: [ { hue: "#0FF000"}]}];
       map.setOptions({styles: pinkParksStyles});
       var myLatlng = new google.maps.LatLng(x,y);
       var marker = new google.maps.Marker({ position: myLatlng, map: map, title: "Here you are."});
	  });
    </script>

@endpush

@endsection
