@extends('admin.layouts.master')
@section('content')

                <div class="nk-content ">
                    <div class="container-fluid">
                        <div class="nk-content-inner">
                            <div class="nk-content-body">
                                <div class="components-preview wide-md mx-auto">
                                    <div class="nk-block-head nk-block-head-lg wide-sm">
                                        <div class="nk-block-head-content">
											&nbsp;
										</div>
                                    </div><!-- .nk-block-head -->
                                    <div class="nk-block nk-block-lg">
                                        <div class="nk-block-head">
                                            <div class="nk-block-head-content">
                                                <h4 class="nk-block-title">{{!empty($title)?$title:''}}</h4>
                                            </div>
                                        </div>
                                        <div class="card card-preview">
                                            <div class="card-inner">
                                                <div class="table-responsive">
                                                    <table class="table table-orders nowrap nk-tb-list is-separate">
                                                        <thead>
                                                            <tr>
                                                                <th>{{trans('admin.record_id')}}</th>
                                                                <th>{{trans('admin.user')}}</th>
                                                                <th>الفرع</th>
                                                                <th>{{trans('admin.vendor')}}</th>
                                                                <th>{{trans('admin.total')}}</th>
                                                                <th>حالة الدفع</th>
                                                                <th>حالة الطلب</th>
                                                                <th>{{trans('admin.created_at')}}</th>
                                                                <th>{{trans('admin.action')}}</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            @foreach($orders as $order)
                                                            <tr>
                                                                <td>{{$order->id}}</td>
                                                                <td>{{$order->user->name}}</td>
                                                                <td>{{$order->branch->name ?? ''}}</td>
                                                                <td>{{$order->vendor->name ?? ''}}</td>
                                                                <td>{{$order->final_total}} ريال</td>
                                                                <td>
                                                                    @if($order->payment_status=='pending')                                                                        
                                                                        <span style="color: red">قيد المراجعة</span>
                                                                    @elseif($order->payment_status=='partially_paid')                                                                        
                                                                        <span style="color:burlywood">مدفوع جزئيا</span>
                                                                    @elseif($order->payment_status=='totally_paid')
                                                                    <span style="color: lime">مدفوع كليا</span>                                                                        
                                                                    @endif
                                                                </td>
                                                                <td>{{$order->status->status_ar}}</td>
                                                                <td>{{$order->created_at}}</td>
                                                                <td class="tb-odr-action">
                                                                    @include('admin.orders.buttons.actions', ['id' => $order->id])
                                                                </td>
                                                            </tr>
                                                            @endforeach
                                                        </tbody>
                                                    </table>
                                                </div>
                                                <div>{{ $orders->links() }}</div>
                                            </div>
                                        </div><!-- .card-preview -->
                                    </div> <!-- nk-block -->
                                </div><!-- .components-preview -->
                            </div>
                        </div>
                    </div>
                </div>

@endsection
