@extends('admin.layouts.master')
@section('content')

	<div class="nk-content ">
		<div class="container-fluid">
			<div class="nk-content-inner">
				<div class="nk-content-body">
					<div class="components-preview wide-md mx-auto">
						<div class="nk-block nk-block-lg">
							<div class="nk-block-head">
								<div class="nk-block-head-content">
									<h4 class="title nk-block-title">{{ !empty($title)?$title:'' }}</h4>
								</div>
							</div>
							<div class="card card-preview">

								<div class="card-inner">
                                    {!! Form::open(['url'=>url(request()->segment('1').'/products'),'id'=>'products','files'=>true,'class'=>'form-horizontal form-row-seperated']) !!}
									<div class="preview-block">
										<div class="row gy-4">
											<div class="col-sm-4">
												<div class="form-group">
													{!! Form::label('name_ar',trans('admin.name_ar'),['class'=>' control-label']) !!}
													<div class="form-control-wrap">
														{!! Form::text('name_ar',old('name_ar'),['class'=>'form-control','placeholder'=>trans('admin.name_ar')]) !!}
													</div>
												</div>
											</div>
											<div class="col-sm-4">
												<div class="form-group">
													{!! Form::label('name_en',trans('admin.name_en'),['class'=>' control-label']) !!}
													<div class="form-control-wrap">
														{!! Form::text('name_en',old('name_en'),['class'=>'form-control','placeholder'=>trans('admin.name_en')]) !!}
													</div>
												</div>
											</div>
											<div class="col-sm-4">
												<div class="form-group">
													{!! Form::label('name_urdu',trans('admin.name_urdu'),['class'=>' control-label']) !!}
													<div class="form-control-wrap">
														{!! Form::text('name_urdu',old('name_urdu'),['class'=>'form-control','placeholder'=>trans('admin.name_urdu')]) !!}
													</div>
												</div>
											</div>
										</div>
										<div class="row gy-4">
											<div class="col-sm-12">
												<div class="form-group">
                                                    {!! Form::label('description_ar',trans('admin.description_ar'),['class'=>' control-label']) !!}
													<div class="form-control-wrap">
                                                        {!! Form::textarea('description_ar',old('description_ar'),['class'=>'form-control tinymce-toolbar','placeholder'=>trans('admin.description_ar')]) !!}
													</div>
												</div>
											</div>
										</div>
										<div class="row gy-4">
											<div class="col-sm-12">
												<div class="form-group">
                                                    {!! Form::label('description_en',trans('admin.description_en'),['class'=>' control-label']) !!}
													<div class="form-control-wrap">
                                                        {!! Form::textarea('description_en',old('description_en'),['class'=>'form-control tinymce-toolbar','placeholder'=>trans('admin.description_en')]) !!}
													</div>
												</div>
											</div>
										</div>
										<div class="row gy-4">
											<div class="col-sm-12">
												<div class="form-group">
                                                    {!! Form::label('description_urdu',trans('admin.description_urdu'),['class'=>' control-label']) !!}
													<div class="form-control-wrap">
                                                        {!! Form::textarea('description_urdu',old('description_urdu'),['class'=>'form-control tinymce-toolbar','placeholder'=>trans('admin.description_urdu')]) !!}
													</div>
												</div>
											</div>
										</div>
										<div class="row gy-4" style="border: 0px dashed #333">
											<div class="col-sm-12">
                                                <label class="form-label" for="default-06">ميزات إضافية</label>
                                                <button type="button" id="rowAdder" class="btn btn-primary"><em class="icon ni ni-plus-sm"></em></button>
                                            </div>
											<div id="newinput" class="col-sm-12">
    										</div>
										</div>
										<div class="row gy-4">
											<div class="col-sm-6">
												<div class="form-group">
                                                    {!! Form::label('discount',trans('admin.unit'),['class'=>' control-label']) !!}
													<div class="form-control-wrap">
														<select name="unit_id" id="unit_id" class="form-control">
															<option value="">اختر الوحدة</option>
															@foreach(App\Models\Unit::get() as $unit)
															<option value="{{$unit->id}}" @if($unit->id==old('unit_id')) selected @endif>{{$unit->name_ar}}</option>
															@endforeach
														</select>
													</div>
												</div>
											</div>
											<div class="col-sm-6">
												<div class="form-group">
                                                    {!! Form::label('price',trans('admin.price'),['class'=>' control-label']) !!}
													<div class="form-control-wrap">
                                                        {!! Form::text('price',old('price'),['class'=>'form-control','placeholder'=>trans('admin.price')]) !!}
													</div>
												</div>
											</div>
										</div>
										<div class="row gy-4">
											@if(admin()->user()->is_vendor==0)
											<div class="col-sm-4">
												<div class="form-group">
                                                    {!! Form::label('vendor_id',trans('admin.vendor_id'),['class'=>' control-label']) !!}
													<div class="form-control-wrap">
                                    					{!! Form::select('vendor_id',App\Models\Admin::vendors()->pluck('name','id'),old('vendor_id'),['class'=>'form-control select2','placeholder'=>trans('admin.choose'), 'required' => 'required']) !!}
													</div>
												</div>
											</div>
											@else
												<input type="hidden" class="form-control" name="vendor_id" value="{{admin()->user()->id}}">
											@endif
											<div class="col-sm-4">
												<div class="form-group">
                                                    {!! Form::label('main_cat', 'القسم الرئيسي',['class'=>' control-label']) !!}
													<div class="form-control-wrap">
														<select class="form-control select2" id="main_cat" onchange="getSub($(this).val())">
															<option value="">اختر القسم</option>
															@foreach(App\Models\Category::where('parent_id', Null)->get() as $category)
																<option value="{{$category->id}}" >{{$category->name_ar}}</option>
															@endforeach
														</select>
													</div>
												</div>
											</div>
											<div class="col-sm-4">
												<div class="form-group">
                                                    {!! Form::label('category_id', 'القسم الفرعي',['class'=>' control-label']) !!}
													<div class="form-control-wrap">
														<select name="category_id" id="category_id" class="form-control select2">
															<option value="">اختر القسم الفرعي</option>
														</select>
													</div>
												</div>
											</div>
										</div>
										<div class="row gy-4">
											<div class="col-sm-6">
												<div class="form-group">
                                                    {!! Form::label('minimum_order',trans('admin.minimum_order'),['class'=>' control-label']) !!}
													<div class="form-control-wrap">
														{!! Form::text('minimum_order',old('minimum_order'),['class'=>'form-control','placeholder'=>trans('admin.minimum_order')]) !!}
													</div>
												</div>
											</div>
											<div class="col-sm-6">
												<div class="form-group">
                                                    {!! Form::label('preparing_time',trans('admin.preparing_time'),['class'=>' control-label']) !!}
													<div class="form-control-wrap">
														{!! Form::text('preparing_time',old('preparing_time'),['class'=>'form-control','placeholder'=>trans('admin.preparing_time')]) !!}
													</div>
												</div>
											</div>
										</div>
										<div class="row gy-4">
											<div class="col-sm-12">
                                                <label class="form-label" for="default-06">الصورة الأساسية</label>
                                            </div>
											<div id="newimage" class="col-sm-12">
                                                <div class="row gy-4" id="row">
                                                    <div class="col-sm-6">
                                                        <div class="form-group">
                                                            <label class="form-label" for="customFile">اختر الصورة</label>
                                                            <div class="form-control-wrap">
                                                                <input type="file" name="image" class="form-control"  required>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
    										</div>
										</div>
										<div class="row gy-4">
											<div class="col-sm-12">
                                                <label class="form-label" for="default-06">الصور الإضافية</label>
                                                &nbsp;&nbsp;&nbsp;&nbsp;
                                                <button type="button" id="rowImage" class="btn btn-primary"><em class="icon ni ni-plus-sm"></em></button>
                                            </div>
											<div id="newimage" class="col-sm-12">
                                                <div class="row gy-4" id="row">
                                                </div>
    										</div>
										</div>
										@forelse($cars as $car)
										<div class="row gy-4">
											<div class="col-sm-4">
												<div class="form-group">
                                                    {!! Form::label('car_id', 'السيارة',['class'=>' control-label']) !!}
													<div class="form-control-wrap">
														<input type="text" class="form-control" value="{{$car->name_ar}}" readonly>
														<input type="hidden" name="car_id[]" id="car_id[]" class="form-control" value="{{$car->id}}" required>
													</div>
												</div>
											</div>
											<div class="col-sm-4">
												<div class="form-group">
                                                    {!! Form::label("from['{{$car->id}}']", ' من (الحمولة تكون بنفس وحدة المنتج المختارة)',['class'=>' control-label']) !!}
													<div class="form-control-wrap">
														<input type="text" name="from[]" id="from[]" class="form-control" required>
													</div>
												</div>
											</div>
											<div class="col-sm-4">
												<div class="form-group">
                                                    {!! Form::label("to['{{$car->id}}']", ' إلى (الحمولة تكون بنفس وحدة المنتج المختارة)',['class'=>' control-label']) !!}
													<div class="form-control-wrap">
														<input type="text" name="to[]" id="to[]" class="form-control" required>
													</div>
												</div>
											</div>
										</div>
										@empty
											<span style="color: red">يجب إضافة السيارات أولا لإضافة حمولة المنتج لكل سيارة</span>
										@endforelse
										<div class="row g-3">
											<div class="col-lg-7 offset-lg-5">
												<div class="form-group mt-2">
													<button type="submit" name="add" class="btn btn-lg btn-primary">إضافة</button>
												</div>
											</div>
										</div>
									</div>
									{!! Form::close() !!}

								</div>
							</div><!-- .card-preview -->
						</div><!-- .nk-block -->
					</div><!-- .components-preview -->
				</div>
			</div>
		</div>
	</div>
@endsection

@push('js')
<script>

function getSub(category_id) {
	$.get('{{url(request()->segment(1)."/categories/getsub/")}}/'+category_id, function(res) {
		$('#category_id').html(res);
	});
}

$(document).ready(function() {

    $("#rowAdder").click(function () {
        newRowAdd =
        '<div class="row gy-4" id="row">' +
            '<div class="col-sm-3">' +
                '<div class="form-group">' +
                    '<label class="form-label" for="default-06">الميزة عربي</label>' +
                    '<div class="form-control-wrap">' +
                        '<input type="text" class="form-control" name="feature_name_ar[]" value="" required>' +
                    '</div>' +
                '</div>' +
            '</div>' +
            '<div class="col-sm-3">' +
                '<div class="form-group">' +
                    '<label class="form-label" for="default-06">الميزة إنجليزي</label>' +
                    '<div class="form-control-wrap">' +
                        '<input type="text" class="form-control" name="feature_name_en[]" value="" required>' +
                    '</div>' +
                '</div>' +
            '</div>' +
            '<div class="col-sm-3">' +
                '<div class="form-group">' +
                    '<label class="form-label" for="default-06">الميزة أوردو</label>' +
                    '<div class="form-control-wrap">' +
                        '<input type="text" class="form-control" name="feature_name_urdu[]" value="">' +
                    '</div>' +
                '</div>' +
            '</div>' +
            '<div class="col-sm-2">' +
                '<div class="form-group">' +
                    '<label class="form-label" for="default-06">&nbsp;</label>' +
                    '<div class="form-control-wrap">' +
                        '<a href="javascript:;" id="DeleteRow" class="text-danger"><em class="icon ni ni-trash-alt"></em></a>'+
                    '</div>' +
                '</div>' +
            '</div>' +
        '</div>';


        $('#newinput').append(newRowAdd);
    });

    $("#rowImage").click(function () {
        newImageAdd =
        '<div class="row gy-4" id="row">' +
            '<div class="col-sm-6">' +
                '<div class="form-group">' +
                    '<label class="form-label" for="customFile">اختر الصورة</label>' +
                    '<div class="form-control-wrap">' +
                        '<input type="file" name="images[]" class="form-control" >' +
                    '</div>' +
                '</div>' +
            '</div>' +
        '</div>';


        $('#newimage').append(newImageAdd);
    });

    $("body").on("click", "#DeleteRow", function () {
        $(this).parents("#row").remove();
    });
});
</script>
@endpush
