@extends('admin.layouts.master')
@section('content')

                <div class="nk-content ">
                    <div class="container-fluid">
                        <div class="nk-content-inner">
                            <div class="nk-content-body">
                                <div class="components-preview wide-md mx-auto">
                                    <div class="nk-block-head nk-block-head-lg wide-sm">
                                        <div class="nk-block-head-content">
											&nbsp;
										</div>
                                    </div><!-- .nk-block-head -->
                                    <div class="nk-block nk-block-lg">
                                        <div class="nk-block-head">
                                            <div class="nk-block-head-content">
                                                <h4 class="nk-block-title">{{!empty($title)?$title:''}}</h4>
                                            </div>
                                        </div>
                                        <div class="card card-preview">
                                            <div class="card-inner">
                                                <div class="table-responsive">
                                                    <table class="table table-orders nowrap nk-tb-list is-separate">
                                                        <thead>
                                                            <tr>
                                                                <th>{{trans('admin.record_id')}}</th>
                                                                <th>السائق</th>
                                                                @if(admin()->user()->is_vendor==0)
                                                                <th>المصنع</th>
                                                                @endif
                                                                <th>الفرع</th>
                                                                <th>القيمة</th>
                                                                <th>اسم البنك</th>
                                                                <th>رقم الحساب</th>
                                                                <th>رقم الآيبان</th>
                                                                <th>الحالة</th>
                                                                <th>{{trans('admin.action')}}</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            @foreach($withdrawal_requests as $request)
                                                            <tr>
                                                                <td>{{$request->id}}</td>
                                                                <td>
                                                                    <a target="_blank" href="{{ url(request()->segment('1').'/deliveries/'.$request->delivery->id)}}" class="text-primary"><em class="icon ni ni-eye-fill"></em> {{ $request->delivery->name }}</a>
                                                                </td>
                                                                @if(admin()->user()->is_vendor==0)
                                                                <td></td>
                                                                @endif
                                                                <td></td>
                                                                <td>{{$request->amount}} ريال</td>
                                                                <td>{{$request->bank_account->bank_name}}</td>
                                                                <td>{{$request->bank_account->bank_account}}</td>
                                                                <td>{{$request->bank_account->iban}}</td>
                                                                <td>@if($request->status=='pending') قيد الفحص @elseif($request->status=='completed') تم @elseif($request->status=='cancelled') ألغيت  @endif</td>
                                                                <td>{{$request->created_at}}</td>
                                                                <td class="tb-odr-action">
                                                                    @include('admin.withdrawal_requests.buttons.actions', ['id' => $request->id])
                                                                </td>
                                                            </tr>
                                                            @endforeach
                                                        </tbody>
                                                    </table>
                                                </div>
                                                <div>{{ $withdrawal_requests->links() }}</div>
                                            </div>
                                        </div><!-- .card-preview -->
                                    </div> <!-- nk-block -->
                                </div><!-- .components-preview -->
                            </div>
                        </div>
                    </div>
                </div>
@endsection
