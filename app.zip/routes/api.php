<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\V1\Auth\AuthAndLogin;
use App\Http\Controllers\Api\V1\Auth\DeliveryAuthAndLogin;
use App\Http\Controllers\Api\V1\Auth\BranchAuthAndLogin;
use App\Http\Controllers\Api\V1\UserAddressApi;
use App\Http\Controllers\Api\V1\BannersApi;
use App\Http\Controllers\Api\V1\AdvsApi;
use App\Http\Controllers\Api\V1\OffersApi;
use App\Http\Controllers\Api\V1\CategoriesApi;
use App\Http\Controllers\Api\V1\VendorsApi;
use App\Http\Controllers\Api\V1\CitiesApi;
use App\Http\Controllers\Api\V1\ProductsApi;
use App\Http\Controllers\Api\V1\OrdersApi;
use App\Http\Controllers\Api\V1\BranchOrdersApi;
use App\Http\Controllers\Api\V1\DeliveryOrdersApi;
use App\Http\Controllers\Api\V1\FaqsApi;
use App\Http\Controllers\Api\V1\ContactApi;
use App\Http\Controllers\Api\V1\UserBankAccounts;
use App\Http\Controllers\Api\V1\WithdrawalRequests;
use App\Http\Controllers\Api\V1\SettingsApi;
use App\Http\Controllers\Api\V1\DeliverySettingsApi;
use App\Http\Controllers\Api\V1\BranchSettingsApi;


/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
 */
// your api is integerated but if you want reintegrate no problem
// to configure jwt-auth visit this link https://jwt-auth.readthedocs.io/en/docs/

Route::group(["middleware" => ["ApiLang", "cors"], "prefix" => "v1", "namespace" => "Api\V1", "as" => "api."], function () {

	// Guest Api Start //
	Route::group(['middleware' => 'guest'], function () {
		Route::post("check-email", [AuthAndLogin::class, 'checkEmail']);
		Route::post("check-mobile", [AuthAndLogin::class, 'checkMobile']);
		Route::post("verify-account", [AuthAndLogin::class, 'verifyAccount']);
		Route::post("register", [AuthAndLogin::class, 'register']);//->middleware('throttle:global');
		Route::post("login", [AuthAndLogin::class, 'login']);//->middleware('throttle:global');
        Route::post("add-verify-trail", [AuthAndLogin::class, 'addVerifyTrail']);
        Route::get("get-verify-trail", [AuthAndLogin::class, 'getVerifyTrail']);
        Route::post("forget-password", [AuthAndLogin::class, 'forgetPassword']);
        Route::post("restet-password", [AuthAndLogin::class, 'restetPassword']);

    	Route::group(['prefix' => 'delivery'], function () {
			Route::post("check-email", [DeliveryAuthAndLogin::class, 'checkEmail']);
			Route::post("check-mobile", [DeliveryAuthAndLogin::class, 'checkMobile']);
			Route::post("verify-account", [DeliveryAuthAndLogin::class, 'verifyAccount']);
			Route::post("register", [DeliveryAuthAndLogin::class, 'register']);//->middleware('throttle:global');
			Route::post("login", [DeliveryAuthAndLogin::class, 'login']);//->middleware('throttle:global');
			Route::post("add-verify-trail", [DeliveryAuthAndLogin::class, 'addVerifyTrail']);
			Route::get("get-verify-trail", [DeliveryAuthAndLogin::class, 'getVerifyTrail']);
			Route::post("forget-password", [DeliveryAuthAndLogin::class, 'forgetPassword']);
			Route::post("restet-password", [DeliveryAuthAndLogin::class, 'restetPassword']);
		});

    	Route::group(['prefix' => 'branch'], function () {
			Route::post("login", [BranchAuthAndLogin::class, 'login']);//->middleware('throttle:global');
			Route::post("add-verify-trail", [BranchAuthAndLogin::class, 'addVerifyTrail']);
			Route::get("get-verify-trail", [BranchAuthAndLogin::class, 'getVerifyTrail']);
			Route::post("forget-password", [BranchAuthAndLogin::class, 'forgetPassword']);
			Route::post("restet-password", [BranchAuthAndLogin::class, 'restetPassword']);
		});

	});
	// Guest Api End //

    // Un-authenticated Api's Start //
    Route::get("customer-faqs", [FaqsApi::class, 'userFaqs']);
    Route::get("/branch/branch-faqs", [FaqsApi::class, 'branchFaqs']);
    Route::get("delivery/deliveries-faqs", [FaqsApi::class, 'deliveryFaqs']);
    // Authenticated Api's End //

	// Authenticated Api's Start //
		Route::group(['middleware' => 'jwt.verify'], function () {
			//customer auth routes
			Route::group(['middleware' => 'customer'], function () {
				Route::post("change-lang", [AuthAndLogin::class, 'changeLang']);
				Route::get("account", [AuthAndLogin::class, 'account']);
				Route::get("notifications", [AuthAndLogin::class, 'notifications']);
				Route::post("update-profile", [AuthAndLogin::class, 'updateProfile']);
				Route::post("charge-wallet", [AuthAndLogin::class, 'chargeWallet']);
				Route::post("transfer-balance", [AuthAndLogin::class, 'transferBalance']);
				Route::get("wallet-transactions", [AuthAndLogin::class, 'walletTransactions']);
				Route::post('change-password', [AuthAndLogin::class, 'change_password']);
				Route::delete("delete-account", [AuthAndLogin::class, 'deleteAccount']);
				Route::post("logout", [AuthAndLogin::class, 'logout']);
	
				Route::get("customer-settings", [SettingsApi::class, 'index']);
				Route::get("banners", [BannersApi::class, 'index']);
				Route::get("advs", [AdvsApi::class, 'index']);
				Route::get("offers", [OffersApi::class, 'index']);
				Route::get("cities", [CitiesApi::class, 'index']);
				Route::get("areas/{city}", [CitiesApi::class, 'areas']);
				Route::get("categories", [CategoriesApi::class, 'index']);
				Route::get("categories/{category}/sub", [CategoriesApi::class, 'sub']);
				Route::get("vendors/{id}", [VendorsApi::class, 'show']);
				Route::get("category/{category}/vendors", [VendorsApi::class, 'categoryVendors']);
				//Route::get("subcategories/{category}/vendors", [VendorsApi::class, 'subcategoriesVendors']);
				Route::get("products", [ProductsApi::class, 'index']);
				Route::get("products/{id}", [ProductsApi::class, 'show']);
						
				Route::get("vendor-products/{id}", [ProductsApi::class, 'vendorProducts']);
	
				Route::get("orders", [OrdersApi::class, 'index']);
				Route::get("order-details/{id}", [OrdersApi::class, 'show']);
				Route::post("place-order", [OrdersApi::class, 'store']);
				Route::get("cancel-order/{id}", [OrdersApi::class, 'cancelOrder']);
				Route::post("complete-order-payment/{id}", [OrdersApi::class, 'completeOrderPayment']);
	
				Route::get("my-addresses", [UserAddressApi::class, 'index']);
				Route::post("add-address", [UserAddressApi::class, 'store']);
				Route::post("update-address/{id}", [UserAddressApi::class, 'update']);
				Route::delete("delete-address/{id}", [UserAddressApi::class, 'destroy']);
				Route::post("make-default/{id}", [UserAddressApi::class, 'makeDefault']);
	
				Route::apiResource("favourites","FavouritesApi");
				Route::apiResource("cart","CartApi");
	
				Route::post("products/{id}/rate", [ProductsApi::class, 'rateProduct']);
				Route::post("vendors/{id}/rate", [VendorsApi::class, 'rateVendor']);
				Route::post("rate-user/{id}", [RatingApi::class, 'rateUser']);
	
				Route::get("payment-methods", [PaymentApi::class, 'paymentMethods']);
				Route::post("contact-us", [ContactApi::class, 'send']);
			});
	
	    	Route::group(['prefix' => 'delivery', 'middleware' => 'delivery'], function () {
				Route::post("change-lang", [DeliveryAuthAndLogin::class, 'changeLang']);
				Route::get("account", [DeliveryAuthAndLogin::class, 'account']);
				Route::get("report", [DeliveryAuthAndLogin::class, 'report']);
				Route::get("notifications", [DeliveryAuthAndLogin::class, 'notifications']);
				Route::post("update-profile", [DeliveryAuthAndLogin::class, 'updateProfile']);
				Route::post('change-password', [DeliveryAuthAndLogin::class, 'change_password']);
				Route::delete("delete-account", [DeliveryAuthAndLogin::class, 'deleteAccount']);
				Route::post("logout", [DeliveryAuthAndLogin::class, 'logout']);

				Route::post("contact-us", [ContactApi::class, 'send']);
				Route::get("orders", [DeliveryOrdersApi::class, 'index']);
				Route::get("order-details/{id}", [DeliveryOrdersApi::class, 'show']);
				Route::post("accept-order-item/{id}", [DeliveryOrdersApi::class, 'acceptOrderItem']);
				//Route::delete("delete-suggested/{id}", [DeliveryOrdersApi::class, 'destroySuggestedOrder']);
				Route::post("update-item-status/{id}", [DeliveryOrdersApi::class, 'updateOrderItemStatus']);

				Route::get("bank-accounts", [UserBankAccounts::class, 'index']);
				Route::post("bank-accounts/store", [UserBankAccounts::class, 'store']);
				Route::delete("bank-accounts/{id}", [UserBankAccounts::class, 'destroy']);

				Route::get("withdraw-requests", [WithdrawalRequests::class, 'index']);
				Route::post("withdraw-requests", [WithdrawalRequests::class, 'store']);
				Route::delete("withdraw-requests/{id}", [WithdrawalRequests::class, 'destroy']);

				Route::get("delivery-settings", [DeliverySettingsApi::class, 'index']);
			});

	    	Route::group(['prefix' => 'branch', 'middleware' => 'branch'], function () {
				Route::post("change-lang", [BranchAuthAndLogin::class, 'changeLang']);
				Route::get("account", [BranchAuthAndLogin::class, 'account']);
				Route::get("notifications", [BranchAuthAndLogin::class, 'notifications']);
				Route::post("update-profile", [BranchAuthAndLogin::class, 'updateProfile']);
				Route::post('change-password', [BranchAuthAndLogin::class, 'change_password']);
				Route::post("logout", [BranchAuthAndLogin::class, 'logout']);

				Route::post('deliveries', [BranchAuthAndLogin::class, 'addDelivery']);
				Route::get('deliveries', [BranchAuthAndLogin::class, 'deliveries']);
				Route::get('deliveries/{id}', [BranchAuthAndLogin::class, 'deliveryDetails']);

				Route::get("orders", [BranchOrdersApi::class, 'index']);
				Route::post("accept-order/{id}", [BranchOrdersApi::class, 'acceptOrder']);
				Route::get("reject-reasons", [BranchOrdersApi::class, 'rejectReasons']);
				Route::post("reject-order/{id}", [BranchOrdersApi::class, 'rejectOrder']);
				Route::get("order-details/{id}", [BranchOrdersApi::class, 'show']);
				Route::post("assign-order-as-paid/{id}", [BranchOrdersApi::class, 'assignOrderAsPaid']);
				Route::post("update-order/{id}", [BranchOrdersApi::class, 'updateOrderStatus']);
				Route::post('send-order-item-request', [BranchOrdersApi::class, 'sendOrderItemRequest']);

				Route::get("branch-settings", [BranchSettingsApi::class, 'index']);
			});
		});
		//Route::get("pay/{id}", [PaymentApi::class, 'executePayment']);
		// Authenticated Api's End //
	
});
